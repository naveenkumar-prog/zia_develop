// console.log("gg");
var liveDashboard = localStorage.getItem("liveDashboard");

console.log("liveDashboard",liveDashboard);

fetchData();

// var speed = 100;
function fetchData() {
    var counterElements = document.getElementsByClassName("counter");
    [...counterElements].forEach(element => {
        element.setAttribute("data-count", 0);
    })
    // document.getElementsByClassName("counter")[0].setAttribute("data-count", 0);
    // document.getElementsByClassName("counter")[1].setAttribute("data-count", 0);

    var requestOptions = {
        method: 'GET',
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";

    fetch(liveDashboard, requestOptions)
            .then(response => response.json())
            .then(result => {
                // console.log(result);
                if (result.status == 200) {
                    [...counterElements].forEach(element => {
                        element.innerHTML = 0;
                    })
                    document.getElementsByClassName("counter")[0].setAttribute("data-count", result.data.users);
                    document.getElementsByClassName("counter")[1].setAttribute("data-count", result.data.sales);
                    document.getElementsByClassName("counter")[2].setAttribute("data-count", result.data.user_last_24_hour);
                    document.getElementsByClassName("counter")[3].setAttribute("data-count", result.data.total_sale_24_hour);
                    // document.getElementById("users").innerHTML = result.data.users;
                    // document.getElementById("sales").innerHTML = result.data.sales;
                    // var num;
                    // for(i=0; i<document.getElementsByClassName('counter').length; i++){
                    //     if(i==0)
                    //     num = +result.data.users;
                    //     else
                    //     num = +result.data.sales;
                    //     countUp(i, num);
                    // }
                    $('.counter').each(function () {
                        var $this = $(this),
                                countTo = $this.attr('data-count');

                        $({countNum: $this.text()}).animate({
                            countNum: countTo
                        },
                                {

                                    duration: 3000,
                                    easing: 'linear',
                                    step: function () {
                                        $this.text(Math.floor(this.countNum));
                                    },
                                    complete: function () {
                                        $this.text(this.countNum);
                                        // alert('finished');
                                    }

                                });


                    });
                }
                setTimeout(fetchData, 20000);
            })
            .catch(error => console.log('error', error));


}

// function countUp(i, num){
//     // console.log("xx")
//     var counter = document.getElementsByClassName('counter')[i];
//     var count = +counter.innerHTML;
//     console.log(count)
//     var inc = num/speed;
//     // console.log(inc);
//     if(count<num){
//         counter.innerHTML = count+inc;
//         setTimeout(countUp(i,num), 500);
//     }else{
//         counter.innerHTML = num;
//     }

// }



// Run the animation on all elements with a class of ‘countup’

