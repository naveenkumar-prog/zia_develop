// const proxyurl = "https://cors-anywhere.herokuapp.com/";
var getSalesData = localStorage.getItem("getSalesData");

console.log("GetSaleData:",getSalesData);

if (sessionStorage.getItem("user_type") == "4" || sessionStorage.getItem("user_type") == "0") {

    getSalesData()

    function getSalesData() {
        var myHeaders = new Headers();
        myHeaders.append("userid", "1784");
        myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
        myHeaders.append("languagetype", "1");
        myHeaders.append("usertype", "0");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(getSalesData+"page=0", requestOptions)
                .then(response => response.json())
                .then(result => {
                    //console.log(result)
                    document.getElementById('cod').innerHTML = result.sale_data.cash_sale;
                    document.getElementById('online').innerHTML = result.sale_data.online_sale;
                    document.getElementById('total').innerHTML = result.sale_data.total_sale;
                })
                .catch(error => {
                    console.log('error', error)
                });
    }
}
