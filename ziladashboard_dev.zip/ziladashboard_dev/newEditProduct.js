// $(document).ready(function(){
//     if(fileAlreadyLoaded()){
//         return;
//     }
// })

var products = [];
console.log("x");
var myHeaders = new Headers();
myHeaders.append("userid", "3513");
myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");

myHeaders.append("usertype", "2");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");


var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

// var proxyurl = "https://cors-anywhere.herokuapp.com/";
var uploadProduct = localStorage.getItem("uploadproduct");
var getProductUrl = localStorage.getItem("newproductget");
var updateProductUrl = localStorage.getItem("updateproduct");
var getimage = localStorage.getItem("getimage");
var postimage = localStorage.getItem("postimage");

var state = {
    'querySet': products,

    'page': 1,

    //number of table rows per page
    'rows': 10,

    //number of page number buttons at the bottom
    'window': 5,
}

buildTable();

function pagination(querySet, page, rows) {

    // var trimStart = (page - 1) * rows
    // var trimEnd = trimStart + rows

    // var trimmedData = querySet.slice(trimStart, trimEnd)

    var pages = Math.ceil(querySet.length / rows);

    return {
        'querySet': querySet,
        'pages': pages,
    }
}

function pageButtons(pages) {
    var wrapper = document.getElementById('pagination-wrapper')

    wrapper.innerHTML = ``
    //console.log('Pages:', pages)

    var maxLeft = (state.page - Math.floor(state.window / 2))
    var maxRight = (state.page + Math.floor(state.window / 2))

    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = state.window
    }

    if (maxRight > pages) {
        maxLeft = pages - (state.window - 1)

        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = pages
    }

    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += `<button value=${page} class="page btn btn-sm btn-info">${page}</button>`
    }

    if (state.page != 1) {
        wrapper.innerHTML = `<button value=${1} class="page btn btn-sm btn-info">&#171; First</button>` + wrapper.innerHTML
    }

    if (state.page != pages) {
        wrapper.innerHTML += `<button value=${pages} class="page btn btn-sm btn-info">Last &#187;</button>`
    }

    $('.page').on('click', function () {
        $('#table-body').empty()

        state.page = Number($(this).val())

        buildTable()
    })
}

//display table based on search results
$('#search-input').on('keyup', function () {
    var value = $(this).val()
    var data = searchTable(value, products)
    state.querySet = data
    console.log(data)
    buildSearchTable()
})

//search table 
function searchTable(value, data) {
    var filteredData = []

    for (var i = 0; i < data.length; i++) {
        value = value.toLowerCase()
        var query = data[i].name.toLowerCase()

        if (data[i].name.toLowerCase().includes(value)) {
            filteredData.push(data[i])
        } else if (data[i].description.toLowerCase().includes(value)) {
            filteredData.push(data[i])
        } else if (data[i].product_id.toString().toLowerCase().includes(value)) {
            filteredData.push(data[i])
        } else if (data[i].size.toLowerCase().includes(value)) {
            filteredData.push(data[i])
        } else if (data[i].color.toLowerCase().includes(value)) {
            filteredData.push(data[i])
        } else if (data[i].brand.toLowerCase().includes(value)) {
            filteredData.push(data[i])
        } else if (data[i].fabric.toLowerCase().includes(value)) {
            filteredData.push(data[i])
        } else if (data[i].hashtag.toLowerCase().includes(value)) {
            filteredData.push(data[i])
        } else if (data[i].transfer_amt.toLowerCase().includes(value)) {
            filteredData.push(data[i])
        }
    }
    return filteredData
}

function buildSearchTable() {
    var table = document.getElementById("myTable")
    table.innerHTML = ''

    var lang = document.getElementById("selectLang").value;
    var name1 = '';
    var desc = '';
    var color = '';

    var res = pagination(state.querySet, state.page, state.rows)
    var myList = res.querySet

    for (var i = 0; i < myList.length; i++)
    {

        name1 = myList[i].name;
        desc = myList[i].description;
        color = myList[i].color;


        var row = "<tr class='del' id=" + myList[i].product_id + ">" +
                "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                "<td contenteditable='false'>" + myList[i].product_id + "</td>" +
                "<td>" +
                "<img id='displayImg" + myList[i].product_id + "' src=" + myList[i].image + " class='product_image'>" +
                "<label id='editLabel" + myList[i].product_id + "' for='editImg" + myList[i].product_id + "' class='fa fa-edit' style='font-size:24px; display:none; cursor:pointer'></label>" +
                "<input type='file' onchange='showPreview(event," + myList[i].product_id + ")' id='editImg" + myList[i].product_id + "' accept='image/*' style='display:none'>" +
                "<button style='margin-top:5px;' type='button' id='multiImagesBtn" + myList[i].product_id + "' class='btn btn-success' data-toggle='modal' onclick='multiImages(this.id)'>View more images</button>" +
                "</td>" +
                "<td contenteditable='false'>" + name1 + "</td>" +
                "<td><p contenteditable='false' id='descriptionDiv" + myList[i].product_id + "' style='width:150px; white-space: pre-wrap;'>" + desc + "</p><textarea style='display: none' rows='4' cols='50' id='description" + myList[i].product_id + "' >" + desc + "</textarea></td>" +
                "<td contenteditable='false' class='actualAmount'>" + myList[i].actual_amount + "</td>" +
                "<td contenteditable='false' class='discount'>" + myList[i].discount + "</td>" +
                "<td contenteditable='false'>" + myList[i].final_amount + "</td>" +
                "<td contenteditable='false'>" + myList[i].category_id + "</td>" +
                "<td contenteditable='false'>" + myList[i].sub_category_id + "</td>" +
                "<td contenteditable='false'>" + myList[i].seller_id + "</td>" +
                "<td contenteditable='false'>" + myList[i].old_discount + "</td>" +
                "<td contenteditable='false'>" + myList[i].product_count + "</td>" +
                "<td contenteditable='false'>" + myList[i].size + "</td>" +
                "<td contenteditable='false'>" + color + "</td>" +
                "<td contenteditable='false'>" + myList[i].brand + "</td>" +
                "<td contenteditable='false'>" + myList[i].brand_id + "</td>" +
                "<td contenteditable='false'>" + myList[i].fabric + "</td>" +
                "<td contenteditable='false'>" + myList[i].returnable + "</td>" +
                "<td contenteditable='false'>" + myList[i].max_day_return + "</td>" +
                "<td contenteditable='false'>" + myList[i].hashtag + "</td>" +
                "<td contenteditable='false' style='display:none'>" + myList[i].vendor_id + "</td>" +
                "<td contenteditable='false'>" + myList[i].transfer_amt + "</td>" +
                "</tr>";

        table.innerHTML += row;
        //mainContainer.appendChild(row);
    }

    //when edit button is clicked
    $('.editbtn').click(function () {
        var $this = $(this);
        //get the row element of the edit button
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);
        var imgLabel = document.getElementById("editLabel" + trId);
        imgLabel.style.display = "block";
        var desc = document.getElementById("descriptionDiv" + trId);
        var descTA = document.getElementById("description" + trId);

        //get the <td> elements of the selected row
        var tds = $this.closest('tr').find('td').filter(function () {
            return $(this).find('.editbtn').length === 0;
        });

        //if the button displays 'edit'
        if ($this.html() === 'Edit') {
            //change text displayed in button to 'save' 
            $this.html('Save');
            //make <td> elements of that row editable
            tds.prop('contenteditable', true);
            //add class to apply css
            currentRow.classList.add('currRowEdit');
            desc.style.display = 'none';
            descTA.style.display = 'block';
        } else {
            $this.html('Edit');
            //make <td> elements of that row uneditable
            tds.prop('contenteditable', false);
            //remove css of that row
            currentRow.classList.remove('currRowEdit');
            desc.style.display = 'block';
            desc.innerHTML = descTA.value;
            descTA.style.display = 'none';
            //get the values stored in the discount and actual amount fields and update them
            // var discount = currentRow.cells.item(6).innerHTML;
            // var actualAmount = currentRow.cells.item(5).innerHTML;
            // console.log("amt: ", actualAmount, "dis ", discount, "id",trId);
            var lang = document.getElementById("selectLang").value;
            var name1, desc1, color1, hindi_name1, hindi_color1, hindi_desc1, tamil_name1, tamil_color1, tamil_desc1;
            if (lang == "english") {
                name1 = currentRow.cells.item(3).innerHTML;
                desc1 = descTA.value;
                color1 = currentRow.cells.item(14).innerHTML;
                hindi_name1 = currentRow.cells.item(24).innerHTML;
                hindi_desc1 = currentRow.cells.item(25).innerHTML;
                hindi_color1 = currentRow.cells.item(26).innerHTML;
                tamil_name1 = currentRow.cells.item(27).innerHTML;
                tamil_desc1 = currentRow.cells.item(28).innerHTML;
                tamil_color1 = currentRow.cells.item(29).innerHTML;
            } else if (lang == "hindi") {
                name1 = currentRow.cells.item(21).innerHTML;
                desc1 = currentRow.cells.item(22).innerHTML;
                color1 = currentRow.cells.item(23).innerHTML;
                hindi_name1 = currentRow.cells.item(3).innerHTML;
                hindi_desc1 = descTA.value;
                hindi_color1 = currentRow.cells.item(14).innerHTML;
                tamil_name1 = currentRow.cells.item(27).innerHTML;
                tamil_desc1 = currentRow.cells.item(28).innerHTML;
                tamil_color1 = currentRow.cells.item(29).innerHTML;
            } else if (lang == "tamil") {
                name1 = currentRow.cells.item(21).innerHTML;
                desc1 = currentRow.cells.item(22).innerHTML;
                color1 = currentRow.cells.item(23).innerHTML;
                hindi_name1 = currentRow.cells.item(24).innerHTML;
                hindi_desc1 = currentRow.cells.item(25).innerHTML;
                hindi_color1 = currentRow.cells.item(26).innerHTML;
                tamil_name1 = currentRow.cells.item(3).innerHTML;
                tamil_desc1 = descTA.value;
                tamil_color1 = currentRow.cells.item(14).innerHTML;
            }

            var formdata = {
                discount: currentRow.cells.item(6).innerHTML,
                amount: currentRow.cells.item(5).innerHTML,
                product_id: trId,
                name: name1,
                hindi_name: hindi_name1,
                tamil_name: tamil_name1,
                description: desc1,
                hindi_desc: hindi_desc1,
                tamil_desc: tamil_desc1,
                category_id: currentRow.cells.item(8).innerHTML,
                sub_category_id: currentRow.cells.item(9).innerHTML,
                old_discount: currentRow.cells.item(11).innerHTML,
                product_count: currentRow.cells.item(12).innerHTML,
                size: currentRow.cells.item(13).innerHTML,
                color: currentRow.cells.item(14).innerHTML,
                hindi_color: hindi_color1,
                tamil_color: tamil_color1,
                brand: currentRow.cells.item(15).innerHTML,
                brand_id: currentRow.cells.item(16).innerHTML,
                fabric: currentRow.cells.item(17).innerHTML,
                returnable: currentRow.cells.item(18).innerHTML,
                max_day_return: currentRow.cells.item(19).innerHTML,
                hashtag: currentRow.cells.item(20).innerHTML,
                vendor_id: currentRow.cells.item(30).innerHTML,
                transfer_amt: currentRow.cells.item(31).innerHtml,
            }
            console.log(formdata);
            updateProduct(formdata);
        }
    });

    //when delete button is clicked
    $('.delbtn').click(function () {
        var $this = $(this);
        //get the row element of the delete button
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);
        console.log(trId);

        var tds = $this.closest('tr').find('td').filter(function () {
            return $(this).find('.editbtn').length == 0;
        });

        var retVal = confirm("Do you want to continue ?");
        //if 'ok' is clicked on the alert box
        if (retVal == true) {
            deleteProduct(trId)
            alert("product deleted");
            currentRow.style.display = 'none';
        }
    });
    pageButtons(res.pages)

    checkEditAccess();
}

var flag = 0;

function showPreview(event, id) {
    // console.log(id);
    if (event.target.files.length > 0) {
        document.getElementById("displayImg" + id).src = URL.createObjectURL(event.target.files[0]);
        flag = 1;
    }
}

function buildTable() {
    var map = {
        english: 2,
        hindi: 1,
        tamil: 3
    }

    myHeaders.append("languagetype", map[document.getElementById("selectLang").value]);

    fetch(getProductUrl+"category_id=0&page=" + state.page, requestOptions)
            .then(response => response.json())
            .then(result => {

                products = result.data;
                state.querySet = products;
                console.log(getProductUrl+"category_id=0&page=" + state.page);
                console.log(map[document.getElementById("selectLang").value])
                state.querySet = products;
                var table = document.getElementById("myTable")
                table.innerHTML = ''

                var lang = document.getElementById("selectLang").value;
                var name1 = '';
                var desc = '';
                var color = '';

                var res = pagination(state.querySet, state.page, state.rows)
                var myList = res.querySet

                for (var i = 0; i < myList.length; i++)
                {
                    // console.log(myList[i].vendor_id)
                    name1 = myList[i].name;
                    desc = myList[i].description;
                    color = myList[i].color;

                    var row = "<tr class='del' id=" + myList[i].product_id + ">" +
                            "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                            "<td contenteditable='false'>" + myList[i].product_id + "</td>" +
                            "<td>" +
                            "<img id='displayImg" + myList[i].product_id + "' src=" + myList[i].image + " class='product_image'>" +
                            "<label id='editLabel" + myList[i].product_id + "' for='editImg" + myList[i].product_id + "' class='fa fa-edit' style='font-size:24px; display:none; cursor:pointer'></label>" +
                            "<input type='file' onchange='showPreview(event," + myList[i].product_id + ")' id='editImg" + myList[i].product_id + "' accept='image/*' style='display:none'>" +
                            "<button style='margin-top:5px;' type='button' id='multiImagesBtn" + myList[i].product_id + "' class='btn btn-success' data-toggle='modal' onclick='multiImages(this.id)'>View more images</button>" +
                            "</td>" +
                            "<td contenteditable='false'>" + name1 + "</td>" +
                            "<td><p id='descriptionDiv" + myList[i].product_id + "' style='width:150px; white-space: pre-wrap;'>" + desc + "</p><textarea style='display: none' rows='4' cols='50' id='description" + myList[i].product_id + "' >" + desc + "</textarea></td>" + "<td contenteditable='false' class='actualAmount'>" + myList[i].actual_amount + "</td>" +
                            "<td contenteditable='false' class='discount'>" + myList[i].discount + "</td>" +
                            "<td contenteditable='false'>" + myList[i].final_amount + "</td>" +
                            "<td contenteditable='false'>" + myList[i].category_id + "</td>" +
                            "<td contenteditable='false'>" + myList[i].sub_category_id + "</td>" +
                            "<td contenteditable='false'>" + myList[i].seller_id + "</td>" +
                            "<td contenteditable='false'>" + myList[i].old_discount + "</td>" +
                            "<td contenteditable='false'>" + myList[i].product_count + "</td>" +
                            "<td contenteditable='false'>" + myList[i].size + "</td>" +
                            "<td contenteditable='false'>" + color + "</td>" +
                            "<td contenteditable='false'>" + myList[i].brand + "</td>" +
                            "<td contenteditable='false'>" + myList[i].brand_id + "</td>" +
                            "<td contenteditable='false'>" + myList[i].fabric + "</td>" +
                            "<td contenteditable='false'>" + myList[i].returnable + "</td>" +
                            "<td contenteditable='false'>" + myList[i].max_day_return + "</td>" +
                            "<td contenteditable='false'>" + myList[i].hashtag + "</td>" +
                            "<td contenteditable='false' style='display:none'>" + myList[i].vendor_id + "</td>" +
                            "<td contenteditable='false'>" + myList[i].transfer_amt + "</td>" +
                            "</tr>";

                    table.innerHTML += row;
                    //mainContainer.appendChild(row);
                }

                //when edit button is clicked
                $('.editbtn').click(function () {
                    var $this = $(this);
                    //get the row element of the edit button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    var imgLabel = document.getElementById("editLabel" + trId);
                    imgLabel.style.display = "block";
                    var desc = document.getElementById("descriptionDiv" + trId);
                    var descTA = document.getElementById("description" + trId);
                    var multiImagesBtn = document.getElementById("multiImagesBtn" + trId);

                    //get the <td> elements of the selected row
                    var tds = $this.closest('tr').find('td').filter(function () {
                        return $(this).find('.editbtn').length === 0;
                    });

                    //if the button displays 'edit'
                    if ($this.html() === 'Edit') {
                        //change text displayed in button to 'save' 
                        $this.html('Save');
                        //make <td> elements of that row editable
                        tds.prop('contenteditable', true);
                        //add class to apply css
                        currentRow.classList.add('currRowEdit');
                        desc.style.display = 'none';
                        descTA.style.display = 'block';
                        multiImagesBtn.style.display = 'none';

                    } else {
                        $this.html('Edit');
                        //make <td> elements of that row uneditable
                        tds.prop('contenteditable', false);
                        //remove css of that row
                        currentRow.classList.remove('currRowEdit');

                        //get the values stored in the discount and actual amount fields and update them
                        // var discount = currentRow.cells.item(6).innerHTML;
                        // var actualAmount = currentRow.cells.item(5).innerHTML;
                        // console.log("amt: ", actualAmount, "dis ", discount, "id",trId);
                        var lang = document.getElementById("selectLang").value;
                        var name1, desc1, color1, hindi_name1, hindi_color1, hindi_desc1, tamil_name1, tamil_color1, tamil_desc1;
                        if (lang == "english") {
                            name1 = currentRow.cells.item(3).innerHTML;
                            desc1 = descTA.value;
                            color1 = currentRow.cells.item(14).innerHTML;
                            hindi_name1 = currentRow.cells.item(24).innerHTML;
                            hindi_desc1 = currentRow.cells.item(25).innerHTML;
                            hindi_color1 = currentRow.cells.item(26).innerHTML;
                            tamil_name1 = currentRow.cells.item(27).innerHTML;
                            tamil_desc1 = currentRow.cells.item(28).innerHTML;
                            tamil_color1 = currentRow.cells.item(29).innerHTML;
                        } else if (lang == "hindi") {
                            name1 = currentRow.cells.item(21).innerHTML;
                            desc1 = currentRow.cells.item(22).innerHTML;
                            color1 = currentRow.cells.item(23).innerHTML;
                            hindi_name1 = currentRow.cells.item(3).innerHTML;
                            hindi_desc1 = descTA.value;
                            hindi_color1 = currentRow.cells.item(14).innerHTML;
                            tamil_name1 = currentRow.cells.item(27).innerHTML;
                            tamil_desc1 = currentRow.cells.item(28).innerHTML;
                            tamil_color1 = currentRow.cells.item(29).innerHTML;
                        } else if (lang == "tamil") {
                            name1 = currentRow.cells.item(21).innerHTML;
                            desc1 = currentRow.cells.item(22).innerHTML;
                            color1 = currentRow.cells.item(23).innerHTML;
                            hindi_name1 = currentRow.cells.item(24).innerHTML;
                            hindi_desc1 = currentRow.cells.item(25).innerHTML;
                            hindi_color1 = currentRow.cells.item(26).innerHTML;
                            tamil_name1 = currentRow.cells.item(3).innerHTML;
                            tamil_desc1 = descTA.value;
                            tamil_color1 = currentRow.cells.item(14).innerHTML;
                        }

                        var formdata = {
                            discount: currentRow.cells.item(6).innerHTML,
                            amount: currentRow.cells.item(5).innerHTML,
                            product_id: trId,
                            name: name1,
                            hindi_name: hindi_name1,
                            tamil_name: tamil_name1,
                            description: desc1,
                            hindi_desc: hindi_desc1,
                            tamil_desc: tamil_desc1,
                            category_id: currentRow.cells.item(8).innerHTML,
                            sub_category_id: currentRow.cells.item(9).innerHTML,
                            old_discount: currentRow.cells.item(11).innerHTML,
                            product_count: currentRow.cells.item(12).innerHTML,
                            size: currentRow.cells.item(13).innerHTML,
                            color: currentRow.cells.item(14).innerHTML,
                            hindi_color: hindi_color1,
                            tamil_color: tamil_color1,
                            brand: currentRow.cells.item(15).innerHTML,
                            brand_id: currentRow.cells.item(16).innerHTML,
                            fabric: currentRow.cells.item(17).innerHTML,
                            returnable: currentRow.cells.item(18).innerHTML,
                            max_day_return: currentRow.cells.item(19).innerHTML,
                            hashtag: currentRow.cells.item(20).innerHTML,
                            vendor_id: currentRow.cells.item(30).innerHTML,
                            transfer_amt: currentRow.cells.item(31).innerHTML,
                        }
                        console.log(formdata);
                        updateProduct(formdata);
                        multiImagesBtn.style.display = 'block';
                    }
                });

                //when delete button is clicked
                $('.delbtn').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    console.log(trId);

                    var tds = $this.closest('tr').find('td').filter(function () {
                        return $(this).find('.editbtn').length == 0;
                    });

                    var retVal = confirm("Do you want to continue ?");
                    //if 'ok' is clicked on the alert box
                    if (retVal == true) {
                        deleteProduct(trId)
                        alert("product deleted");
                        currentRow.style.display = 'none';
                    }
                });

                pageButtons(res.pages)

                checkEditAccess();

            })
        //    .catch(error => console.log('error', error));

}

//update products after changing value and clicking on 'save'
function updateProduct(formdata)
{
    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem("userId"));
    myHeaders.append("sessionkey", sessionStorage.getItem("sessionKey"));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", sessionStorage.getItem("user_type"));
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    // var urlencoded = new URLSearchParams();
    // urlencoded.append("discount", discount);
    // urlencoded.append("amount", amt);
    // urlencoded.append("product_id", id);
    var formData = new FormData();
    formData.append("discount", formdata.discount);
    formData.append("amount", formdata.amount);
    formData.append("product_id", formdata.product_id);
    formData.append("name", formdata.name);
    formData.append("hindi_name", formdata.hindi_name);
    formData.append("tamil_name", formdata.tamil_name);
    formData.append("description", formdata.description);
    formData.append("hindi_desc", formdata.hindi_desc);
    formData.append("tamil_desc", formdata.tamil_desc);
    formData.append("category_id", formdata.category_id);
    formData.append("sub_category_id", formdata.sub_category_id);
    formData.append("old_discount", formdata.old_discount);
    formData.append("product_count", formdata.product_count);
    formData.append("size", formdata.size);
    formData.append("color", formdata.color);
    formData.append("hindi_color", formdata.hindi_color);
    formData.append("tamil_color", formdata.tamil_color);
    formData.append("brand", formdata.brand);
    formData.append("brand_id", formdata.brand_id);
    formData.append("fabric", formdata.fabric);
    formData.append("returnable", formdata.returnable);
    formData.append("max_day_return", formdata.max_day_return);
    formData.append("hashtag", formdata.hashtag);
    formData.append("vendor_id", formdata.vendor_id);
    formdata.append("transfer_amt", formdata.transfer_amt);
    if (flag) {
        formData.append("image", document.getElementById('editImg' + formdata.product_id).files[0]);
    }

    var updateOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formData,
        redirect: 'follow'
    }
    // console.log("Func amt: "+ amt+ "dis "+ discount+ "id",id);

    fetch(updateProductUrl, updateOptions)
            .then(response => response.text())
            .then(result => {
                alert("Successfully updated product details");
                window.location.reload();
            })
            .catch(error => {
                console.log("error", error);
                alert("Error updating product details");
            });

    //document.location.reload();
}

//delete function to delete a product
function deleteProduct(id)
{
    var deleteProductHeaders = new Headers();
    deleteProductHeaders.append("userid", "1784");
    deleteProductHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    deleteProductHeaders.append("languagetype", "1");
    deleteProductHeaders.append("usertype", "0");
    deleteProductHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    deleteProductHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var deleteUrlencoded = new URLSearchParams();
    deleteUrlencoded.append("product_id", id);

    var deleteOptions = {
        method: 'POST',
        headers: deleteProductHeaders,
        body: deleteUrlencoded,
        redirect: 'follow'
    }

    fetch(updateProductUrl, deleteOptions)
            .then(response => response.text())
            .then(result => {
                console.log(result)
                alert("Successfully deleted product details")
            })
            .catch(error => {
                console.log('error', error)
                alert("Error deleting product details")
            })
}

//prevent f12 click action to open page source
$(document).keydown(function (e) {
    if (e.which === 123) {
        return false;
    }
});

function checkEditAccess() {

    var userId = localStorage.getItem("userId");
    // console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(14);//.orderByKey();

    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);
        var tble = document.getElementById("table-1");
        var row = tble.rows;

        if ((!snapshot.val().edit) && (!snapshot.val().delete)) {

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(0);
            }

        }
        if (!snapshot.val().edit) {
            $(".editBtn").remove();
        }
        if (!snapshot.val().delete) {
            $(".delBtn").remove();
        }
    })
}

function multiImages(btnid) {
    var id = btnid.split('n', 2)[1];
    getImage(id);
}

function getImage(id) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "3513");
    myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(getimage+"product_id=" + id, requestOptions)
            .then(response => response.json())
            .then(result => {
                // console.log(result);
                document.getElementById("idInModal").innerHTML = id;
                var modalBody = document.getElementById("multiImageModalBody");
                modalBody.innerHTML = "";
                for (i = 0; i < result.data.length; i++) {
                    // console.log(i)
                    var img = "<img src=" + result.data[i].image + " style='width:150px; height:150px; padding:3px; margin:3px;'>";
                    modalBody.innerHTML += img;
                }
                $('#imgs').val('');
                imgsUpload();
                $('#multiImageModal').modal('show');
            })
            .catch(error => console.log('error', error));
}



function imgsUpload() {
    // console.log("images")
    var imgsUploadBtn = document.getElementById('imgsUploadBtn');
    if (document.getElementById('imgs').files.length > 0) {
        imgsUploadBtn.disabled = false;
    } else {
        imgsUploadBtn.disabled = true;
    }
}

function imgsUploadBtn() {
    var prod_id = document.getElementById('idInModal').innerHTML;
    document.getElementById("overlay").style.display = "block";
    // return;
    for (i = 0; i < document.getElementById('imgs').files.length; i++) {
        imgsUploadAPI(i, prod_id, document.getElementById('imgs').files.length);
    }
}

function imgsUploadAPI(i, prod_id, l) {
    console.log(i, prod_id, l);
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    console.log(i);

    var formdata = new FormData();

    formdata.append("image", document.getElementById('imgs').files[i]);
    formdata.append("product_id", prod_id);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    //   const proxyurl = "https://cors-anywhere.herokuapp.com/";
    //const url = "http://api.myzila.com/PostImage";



    fetch(postimage, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                if (i == (l - 1)) {
                    document.getElementById("overlay").style.display = "none";
                    alert("Image(s) Added Successfully");
                }
            })
            .catch(error => console.log('error', error));
}