var getdetailsbyId = localStorage.getItem("getdetailsbyId"); 
var updateStatus = localStorage.getItem("updateStatus");
var getOrderlist = localStorage.getItem("getOrderlist");

console.log("getOrderlist2:",getOrderlist);


var productId;
var prod = [];
var orders = [];
var date_g = 0, status_g = -1, payment_g = 0;
var totalPages;
$(document).ready(function () {
    $("#datepicker").datepicker({dateFormat: 'yy-mm-dd'});
    $("#datepicker").on("change", function () {
        date = $(this).val();
        if (date == "")
        {
            console.log(date);
            buildTable();
        } else
        {
            buildTable(date, -1, 0)
        }
    });
});

///




// To get details from api

function getdetails(x)
{
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(getdetailsbyId+"product_id=" + x, requestOptions)
            .then(response => response.json())
            .then(result => {
                prod = result.data;
                //localStorage.setItem('data', prod);
                //console.log(prod[0].name)
                displayDetails(prod)
            })
            .catch(error => console.log('error', error));
}

// To display detaisl that we fetched

function displayDetails(product)
{
    document.getElementById('popup').style.display = 'block';
    //var elem = document.getElementById('data');

    var imgProd = "<img src='" + prod[0].image + "' class='product_image'><br>"
    var tr = "<b>Product Id:</b>  " + prod[0].product_id + "<br>" +
            "<b>Name:</b>  " + prod[0].name + "<br>" +
            "<b>Hindi name:</b>  " + prod[0].hindi_name + "<br>" +
            "<b>Tamil name:</b>  " + prod[0].tamil_name + "<br>" +
            "<b>Description:</b>  " + prod[0].description + "<br>" +
            "<b>Hindi desc:</b>  " + prod[0].hindi_desc + "<br>" +
            "<b>Tamil desc:</b>  " + prod[0].tamil_desc + "<br>" +
            "<b>Actual amount:</b>  " + prod[0].actual_amount + "<br>" +
            "<b>Discount:</b>  " + prod[0].discount + "<br>" +
            "<b>Final amount:</b>  " + prod[0].final_amount + "<br>" +
            "<b>Video link:</b>  " + prod[0].video_link + "<br>" +
            "<b>Category:</b>  " + prod[0].category_id + "<br>" +
            "<b>Sub-category:</b>  " + prod[0].sub_category_id + "<br>" +
            "<b>Seller-id:</b>  " + prod[0].seller_id + "<br>" +
            "<b>Old discount:</b>  " + prod[0].old_discount + "<br>" +
            "<b>Product count:</b>  " + prod[0].product_count + "<br>" +
            "<b>Size:</b>  " + prod[0].size + "<br>" +
            "<b>Color:</b>  " + prod[0].color + "<br>" +
            "<b>Hindi color:</b>  " + prod[0].hindi_color + "<br>" +
            "<b>Tamil color:</b>  " + prod[0].tamil_color + "<br>" +
            "<b>Brand:</b>  " + prod[0].brand + "<br>" +
            "<b>Brand Id:</b>  " + prod[0].brand_id + "<br>" +
            "<b>Fabric:</b>  " + prod[0].fabric + "<br>" +
            "<b>Returnable:</b>  " + prod[0].returnable + "<br>" +
            "<b>Max day return:</b>  " + prod[0].max_day_return + "<br>" +
            "<b>Hashtag:</b>  " + prod[0].hashtag;

    var div = document.getElementById("prodImage");
    var tab = document.getElementById("prodInfo");

    document.getElementById('popup').classList.add('stick');

    div.innerHTML = imgProd;
    tab.innerHTML = tr;
}

function changeDisplay() {
    document.getElementById('popup').classList.remove('stick');
    document.getElementById('popup').style.display = 'none';
}

// To Change Current Status

function changeStatus(x, y)
{
    var result = confirm("Change status?");

    if (result == true)
    {
        var myHeaders = new Headers();
        myHeaders.append("userid", "1784");
        myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
        myHeaders.append("languagetype", "1");
        myHeaders.append("usertype", "0");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
        myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

        var urlencoded = new URLSearchParams();
        urlencoded.append("orderId", y);
        urlencoded.append("orderStatus", x);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: urlencoded,
            redirect: 'follow'
        };

       // const updateUrl = "http://api.myzila.com/UpdateStatus";

        fetch(updateStatus, requestOptions)
                .then(response => response.text())
                .then(result => {
                    //location.reload();
                    //console.log(result)  
                    var newStatus;

                    switch (parseInt(x))
                    {
                        case 0 :
                            newStatus = "Not Known";
                            break;
                        case 1 :
                            newStatus = "Placed";
                            break;
                        case 2 :
                            newStatus = "Shipped";
                            break;
                        case 3 :
                            newStatus = "Delivered";
                            break;
                        case 4 :
                            newStatus = "Cancelled";
                            break;
                        case 5 :
                            newStatus = "Request to return";
                            break;
                        case 6 :
                            newStatus = "Returned";
                            break;
                        case 7 :
                            newStatus = "Return request rejected";
                            break;
                        case 8 :
                            newStatus = "Approve";
                            break;
                        case 9 :
                            newStatus = "Returned";
                            break;
                        case 10 :
                            newStatus = "No return";
                            break;
                    }

                    // Update the Status column

                    document.getElementById("orderStatusLabel" + y).innerHTML = "<b>" + newStatus + "</b>";
                })
                .catch(error => console.log('error', error));
    }
    //document.getElementById("showData").innerHTML = x + " is your number " + y ;
}

// the json data. (you can change the values for output.)
var myHeaders = new Headers();
myHeaders.append("userid", "1784");
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("languagetype", "1");
myHeaders.append("usertype", "0");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

var pageNum = 0;
// const proxyurl = "https://cors-anywhere.herokuapp.com/";
const url = getOrderlist+"seller_id=0&page="

buildTable()

function buildTable(date = 0, status = - 1, payment = 0)
{

    document.getElementById("from").value="1";
    document.getElementById("to").value="1";
    document.getElementById("overlay").style.display = "block";
    var numberOfOrders;
    var tableBody = document.getElementById("tableBody");
    var displayUrl = url + pageNum;
    if (status != -1) {
        if (status == 11) {
            buildTable();
            return;
        }
        displayUrl += "&status=" + status;
        status_g = status;
        console.log(displayUrl);
        tableBody.innerHTML = "";
        date = 0;
        payment_g = 0;
        date_g = 0;
    }
    if (date != 0) {
        displayUrl += "&date=" + date;
        date_g = date;
        console.log(displayUrl);
        tableBody.innerHTML = "";
        payment_g = 0;
        status_g = -1;
    }
    if (payment != 0) {
        displayUrl += "&payment=" + payment;
        payment_g = payment;
        console.log(displayUrl);
        tableBody.innerHTML = "";
        status_g = -1;
        date_g = 0;
    }

    if (date == "") {
        // console.log("sajndkjn");
        tableBody.innerHTML = "";
    }
    // console.log(displayUrl);
    fetch(displayUrl, requestOptions)
            .then(response => {
                return response.json()
            })
            console.log("buildTable with date enters");
            .then(data => {
                // Work with JSON data here
                orders = data.data;
                console.log(orders);
                numberOfOrders = data.totalordertozila;
                if (orders.length == 0) {
                    tableBody.innerHTML = "--- No results to display ---"
                }
                for (var i = 0; i < data.data.length; i++) {
                    var obj = data.data[i];
                    var status = "";

                    switch (data.data[i].status)
                    {
                        case 0 :
                            status = "Not Known";
                            break;
                        case 1 :
                            status = "Placed";
                            break;
                        case 2 :
                            status = "Shipped";
                            break;
                        case 3 :
                            status = "Delivered";
                            break;
                        case 4 :
                            status = "Cancelled";
                            break;
                        case 5 :
                            status = "Request to return";
                            break;
                        case 6 :
                            status = "Returned";
                            break;
                        case 7 :
                            status = "Return request rejected";
                            break;
                        case 8 :
                            status = "Approve";
                            break;
                        case 9 :
                            status = "Returned";
                            break;
                        case 10 :
                            status = "No return";
                            break;
                    }

                    var st = " <div><select id=" + data.data[i].sold_product_id + " onchange=\"changeStatus(this.value,this.id)\"  > <option value=" + 0 + ">Not Known</option> <option value=" + 1 + ">Placed</option> <option value=" + 2 + ">Shipped</option> <option value=" + 3 + ">Delivered</option> <option value=" + 4 + ">Cancelled</option> <option value=" + 5 + ">Request to return</option> <option value=" + 6 + ">Returned</option> <option value=" + 7 + ">Return request rejected</option> <option value=" + 8 + ">Approve</option> <option value=" + 9 + ">Retunred</option> <option value=" + 10 + ">No return</option> <option selected value=" + 11 + ">--Select--</option> </select> </div>  ";
                    var status = "<label id='orderStatusLabel" + data.data[i].sold_product_id + "'> " + status + "  <label>";

                    productId = obj.product_id;

                    var $tr = $("<tr>");

                    var $SNO = $("<td>");
                    var $NAME = $("<td>");
                    var $IMAGE = $("<td>");
                    var $ProdDetails = $("<td>");
                    var $PRICE = $("<td>");
                    var $APRICE = $("<td>");
                    var $COLOR = $("<td>");
                    var $QUANTITY = $("<td>");
                    var FROM = $("<td>");
                    var $CreatedOn = $("<td>");
                    var $UpdatedOn = $("<td>");
                    var $ORDERID = $("<td>");
                    var $SHIP = $("<td>");
                    var $StatusString = $("<td>");
                    var $STATUS = $("<td>");
                    var $FPRICE = $("<td>");
                    var $FPRICEA = $("<td>");
                    var $TPRICE = $("<td>");
                    var $TTPRICE = $("<td>");
                    var $STRCOM = $("<td>");
                    var $VNAME = $("<td>");
                    var $BNAME = $("<td>");
                    var $GST = $("<td>");
                    var $SPRD_ID = $("<td>");
                    var $WAYBILL = $("<td>");
                    var $PAYSLIP = $("<td>");

                    var image = "<img src='" + obj.image + "' width='100' height='100'>"
                    /*
                     var dispProd = "prod";
                     var dispShip = "ship";
                     */
                    var prodDetailsButton = "<button class='viewDetails' onclick='getdetails(" + productId + ")'><span>View</span></button>";
                    /*
                     var shipDetailsButton = "<button onclick='getdetails("+ productId + "," + dispShip +")'>Click to view</button>";
                     */

                    // var famt = fprice.toFixed(2);
                    // var qty = obj.quantity;
                    // var finalamt = parseInt(famt * qty);

                    var payMethod = 'Online'
                    if (obj.payment_method == 1)
                        payMethod = 'Cash'

                    var shipDetails = "<b>Address:</b> " + obj.address + "<br>" + "<b>Username:</b> " + obj.user_name + "<br>" + "<b>Payment method:</b> " + payMethod;
                    var strcom = (parseFloat(obj.store_partner_com) * 1);
                    var ttprice = (parseFloat(obj.trans_amt) * parseFloat(obj.quantity));
                    var aprice = ((100 - parseFloat(obj.offer_amount, 10)) / 100) * parseFloat(obj.actual_amount, 10);
                    var fprice = ((100 - parseFloat(obj.offer_amount, 10)) / 100) * parseFloat(obj.actual_amount, 10) * parseFloat(obj.quantity);
                    var fpricea = (parsedatepickerFloat(obj.quantity) * parseFloat(obj.actual_amount));
                    // console.log(fprice)
                    var download = "<button class='downloadBtn' id='" + obj.waybill + "' onclick='getDelhivery(this.id)'>Download</button>";
                    var download1 = "Not generated";
                    if(obj.fromApp=="1"){

                        var from_app = "Zila App"

                    }else if(obj.fromApp=="2"){
                        var from_app = "Zila Website"

                    }else if(obj.fromApp=="3"){
                        var from_app = "ZCL App"
                    }else{
                        var from_app = "Not mentioned"
                    }
                    $SNO.append(i + 1);
                    $NAME.append(obj.name);
                    $IMAGE.append(image);
                    $ProdDetails.append("<br>" + prodDetailsButton);
                    $PRICE.append(obj.actual_amount.toFixed(2));
                    $APRICE.append(aprice.toFixed(2));
                    $COLOR.append(obj.color);
                    $QUANTITY.append(obj.quantity);
                    $FROM.append(from_app);
                    //$SHIP.append("<br>"+shipDetailsButton);
                    $CreatedOn.append(obj.created_on);
                    $UpdatedOn.append(obj.updated_on);
                    $ORDERID.append(obj.order_id);
                    $SHIP.append(shipDetails);
                    $StatusString.append(status);
                    $STATUS.append(st);
                    $FPRICE.append(fpricea.toFixed(2));
                    $FPRICEA.append(fprice.toFixed(2));
                    $TPRICE.append(parseFloat(obj.trans_amt, 10).toFixed(2));
                    $TTPRICE.append(ttprice.toFixed(2));
                    $STRCOM.append(strcom.toFixed(2));
                    $BNAME.append(obj.business_name);
                    $VNAME.append(obj.vendor_name);
                    $GST.append(parseFloat(obj.gst_amt, 10).toFixed(2));
                    $SPRD_ID.append(obj.sold_product_id);
                    $WAYBILL.append(obj.waybill);
                    if (obj.waybill == '0')
                    {
                        $PAYSLIP.append(download1);
                    } else {
                        $PAYSLIP.append(download);
                    }

                    $tr.append($SNO);
                    $tr.append($NAME);
                    $tr.append($IMAGE);
                    $tr.append($ProdDetails);
                    $tr.append($PRICE);
                    $tr.append($APRICE);
                    $tr.append($COLOR);
                    $tr.append($QUANTITY);
                    $tr.append($FROM);
                    $tr.append($CreatedOn);
                    $tr.append($UpdatedOn);
                    $tr.append($ORDERID);
                    $tr.append($SHIP);
                    $tr.append($StatusString);
                    $tr.append($STATUS);
                    $tr.append($FPRICE);
                    $tr.append($FPRICEA);
                    $tr.append($TPRICE);
                    $tr.append($TTPRICE);
                    $tr.append($STRCOM);
                    $tr.append($BNAME);
                    $tr.append($VNAME);
                    $tr.append($GST);
                    $tr.append($SPRD_ID);
                    $tr.append($WAYBILL);
                    $tr.append($PAYSLIP);

                    $('#tableBody').append($tr);
                }
                console.log("data " + data)
                pageButtons(numberOfOrders)
                document.getElementById("overlay").style.display = "none";

                checkEditAccess();

            })
            .catch(err => {
                // Do something for an error here
            })
}

// To display page buttons in footer

function pageButtons(numOrders) {
    var wrapper = document.getElementById('pagination-wrapper')

    wrapper.innerHTML = ''
    //console.log('Pages:', pages)

    //var maxLeft = (state.page - Math.floor(state.window / 2))
    //var maxRight = (state.page + Math.floor(state.window / 2))

    var maxLeft = (pageNum - 2)
    var maxRight = (pageNum + 2)

    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = 5
    }

    var numberOfPages = Math.ceil(numOrders / 10);
    totalPages = numberOfPages;
    if (maxRight > numberOfPages) {
        maxLeft = numberOfPages - 5

        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = numberOfPages
    }

    var wrapper = document.getElementById("pagination-wrapper");
    //var page = pageNum + 1;
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += "<button value='" + page + "' class='page btn btn-sm btn-info'>" + page + "</button>"
    }

    if (pageNum != 1) {
        wrapper.innerHTML = "<button value='1' class='page btn btn-sm btn-info'>&#171; First</button>" + wrapper.innerHTML
    }

    if (pageNum != numberOfPages) {
        wrapper.innerHTML += "<button value='" + numberOfPages + "' class='page btn btn-sm btn-info'>Last &#187;</button>"
    }

    $('.page').on('click', function () {
        $('#tableBody').empty()

        pageNum = Number($(this).val()) - 1;
         $(this).addClass("activePage");
       console.log("After buildtable this :",this);

        buildTable(date_g, status_g, payment_g);
    })
}

var searchPageNum = 0;
var value;
//display table based on search results
$('#searchfunc').click(function () {
    value = document.getElementById("search-input").value;
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
        searchPageNum = 0;
    }
    buildSearchTable(value)
})
//display search results in table 
function buildSearchTable(value) {
    document.getElementById("overlay").style.display = "block";
    var displayUrl = getOrderlist+"searchkey=" + value + "&page=" + searchPageNum;
    fetch(displayUrl, requestOptions)
            .then(response => {
                return response.json()
            })
            .then(data => {
                // Work with JSON data here
                // console.log(data);
                document.getElementById("tableBody").innerHTML = '';
                for (var i = 0; i < data.data.length; i++) {
                    var obj = data.data[i];
                    var status = "";

                    switch (data.data[i].status)
                    {
                        case 0 :
                            status = "Not Known";
                            break;
                        case 1 :
                            status = "Placed";
                            break;
                        case 2 :
                            status = "Shipped";
                            break;
                        case 3 :
                            status = "Delivered";
                            break;
                        case 4 :
                            status = "Cancelled";
                            break;
                        case 5 :
                            status = "Request to return";
                            break;
                        case 6 :
                            status = "Returned";
                            break;
                        case 7 :
                            status = "Return request rejected";
                            break;
                        case 8 :
                            status = "Approve";
                            break;
                        case 9 :
                            status = "Returned";
                            break;
                        case 10 :
                            status = "No return";
                            break;
                    }

                    var st = " <div><select id=" + data.data[i].sold_product_id + " onchange=\"changeStatus(this.value,this.id)\"  > <option value=" + 0 + ">Not Known</option> <option value=" + 1 + ">Placed</option> <option value=" + 2 + ">Shipped</option> <option value=" + 3 + ">Delivered</option> <option value=" + 4 + ">Cancelled</option> <option value=" + 5 + ">Request to return</option> <option value=" + 6 + ">Returned</option> <option value=" + 7 + ">Return request rejected</option> <option value=" + 8 + ">Approve</option> <option value=" + 9 + ">Retunred</option> <option value=" + 10 + ">No return</option> <option selected value=" + 11 + ">--Select--</option> </select> </div>  ";
                    var status = "<label> " + status + "  <label>";

                    productId = obj.product_id;

                    var $tr = $("<tr>");

                    var $SNO = $("<td>");
                    var $NAME = $("<td>");
                    var $IMAGE = $("<td>");
                    var $ProdDetails = $("<td>");
                    var $PRICE = $("<td>");
                    var $APRICE = $("<td>");
                    var $COLOR = $("<td>");
                    var $QUANTITY = $("<td>");
                    var $FROM = $("<td>");
                    var $CreatedOn = $("<td>");
                    var $UpdatedOn = $("<td>");
                    var $ORDERID = $("<td>");
                    var $SHIP = $("<td>");
                    var $StatusString = $("<td>");
                    var $STATUS = $("<td>");
                    var $FPRICE = $("<td>");
                    var $FPRICEA = $("<td>");
                    var $TPRICE = $("<td>");
                    var $TTPRICE = $("<td>");
                    var $STRCOM = $("<td>");
                    var $BNAME = $("<td>");
                    var $VNAME = $("<td>");
                    var $GST = $("<td>");
                    var $SPRD_ID = $("<td>");
                    var $WAYBILL = $("<td>");
                    var $PAYSLIP = $("<td>");

                    var image = "<img src='" + obj.image + "' width='100' height='100'>"

                    var prodDetailsButton = "<button onclick='getdetails(" + productId + ")'>Click to view</button>";


                    // var famt = fprice.toFixed(2);
                    // var qty = obj.quantity;
                    // var finalamt = parseInt(famt * qty);

                    var payMethod = 'Online'
                    if (obj.payment_method == 1)
                        payMethod = 'Cash'

                    var strcom = (parseFloat(obj.store_partner_com) * 1);
                    var ttprice = (parseFloat(obj.trans_amt) * parseFloat(obj.quantity));
                    var aprice = ((100 - parseFloat(obj.offer_amount, 10)) / 100) * parseFloat(obj.actual_amount, 10);
                    var download = "<button class='downloadBtn' id='" + obj.waybill + "' onclick='getDelhivery(this.id)'>Download</button>";
                    var download1 = "Not generated";
                    if(obj.fromApp=="1"){

                        var from_app = "Zila App"

                    }else if(obj.fromApp=="2"){
                        var from_app = "Zila Website"

                    }else if(obj.fromApp=="3"){
                        var from_app = "ZCL App"
                    }else{
                        var from_app = "Not mentioned"
                    }
                    var fprice = ((100 - parseFloat(obj.offer_amount, 10)) / 100) * parseFloat(obj.actual_amount, 10) * parseFloat(obj.quantity);
                    var fpricea = (parseFloat(obj.quantity) * parseFloat(obj.actual_amount));
                    var shipDetails = "<b>Address:</b> " + obj.address + "<br>" + "<b>Username:</b> " + obj.user_name + "<br>" + "<b>Payment method:</b> " + payMethod;
                    $SNO.append(i + 1);
                    $NAME.append(obj.name);
                    $IMAGE.append(image);
                    $ProdDetails.append("<br>" + prodDetailsButton);
                    $PRICE.append(obj.actual_amount.toFixed(2));
                    $APRICE.append(aprice.toFixed(2));
                    $COLOR.append(obj.color);
                    $QUANTITY.append(obj.quantity);
                    $FROM.append(from_app);
                    //$SHIP.append("<br>"+shipDetailsButton);
                    $CreatedOn.append(obj.created_on);
                    $UpdatedOn.append(obj.updated_on);
                    $ORDERID.append(obj.order_id);
                    $SHIP.append(shipDetails);
                    $StatusString.append(status);
                    $STATUS.append(st);
                    $FPRICE.append(fpricea.toFixed(2));
                    $FPRICEA.append(fprice.toFixed(2));
                    $TPRICE.append(parseFloat(obj.trans_amt, 10).toFixed(2));
                    $TTPRICE.append(ttprice.toFixed(2));
                    $STRCOM.append(strcom.toFixed(2));
                    $BNAME.append(obj.business_name);
                    $VNAME.append(obj.vendor_name);
                    $GST.append(parseFloat(obj.gst_amt, 10).toFixed(2));
                    $SPRD_ID.append(obj.sold_product_id);
                    $WAYBILL.append(obj.waybill);
                    if (obj.waybill == "0")
                    {
                        $PAYSLIP.append(download1);
                    } else {
                        $PAYSLIP.append(download);
                    }

                    $tr.append($SNO);
                    $tr.append($NAME);
                    $tr.append($IMAGE);
                    $tr.append($ProdDetails);
                    $tr.append($PRICE);
                    $tr.append($APRICE);
                    $tr.append($COLOR);
                    $tr.append($QUANTITY);
                    $tr.append($FROM);
                    $tr.append($CreatedOn);
                    $tr.append($UpdatedOn);
                    $tr.append($ORDERID);
                    $tr.append($SHIP);
                    $tr.append($StatusString);
                    $tr.append($STATUS);
                    $tr.append($FPRICE);
                    $tr.append($FPRICEA);
                    $tr.append($TPRICE);
                    $tr.append($TTPRICE);
                    $tr.append($STRCOM);
                    $tr.append($BNAME);
                    $tr.append($VNAME);
                    $tr.append($GST);
                    $tr.append($SPRD_ID);
                    $tr.append($WAYBILL);
                    $tr.append($PAYSLIP);

                    $('#tableBody').append($tr);
                }
                //console.log(data)
                searchPageButtons()
                document.getElementById("overlay").style.display = "none";
                checkEditAccess();
            })
            .catch(error => {
                // Do something for an error here
                console.log("error", error)
            })
}

// Page Buttons to display on footer

function searchPageButtons() {
    var wrapper = document.getElementById('pagination-wrapper')

    wrapper.innerHTML = ''
    //console.log('Pages:', pages)

    //var maxLeft = (state.page - Math.floor(state.window / 2))
    //var maxRight = (state.page + Math.floor(state.window / 2))

    var maxLeft = (pageNum - 2)
    var maxRight = (pageNum + 2)

    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = 5
    }
    var numberOfPages = 6
    //var numberOfPages = Math.ceil(numOrders/10);
    if (maxRight > numberOfPages) {
        maxLeft = numberOfPages - 5

        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = numberOfPages
    }

    var wrapper = document.getElementById("pagination-wrapper");
    //var page = pageNum + 1;
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += "<button value='" + page + "' class='page btn btn-sm btn-info'>" + page + "</button>"
    }

    if (searchPageNum != 1) {
        wrapper.innerHTML = "<button value='1' class='page btn btn-sm btn-info'>&#171; First</button>" + wrapper.innerHTML
    }

    if (searchPageNum != numberOfPages) {
        wrapper.innerHTML += "<button value='" + numberOfPages + "' class='page btn btn-sm btn-info'>Last &#187;</button>"
    }

    $('.page').on('click', function () {
        $('#tableBody').empty()

        searchPageNum = Number($(this).val()) - 1

        buildSearchTable(value)
    })
}
$('#').keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
        alert('You pressed a "enter" key in textbox');
    }
});

function checkEditAccess() {
    /*
     var config = {
     apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
     authDomain: "zila-dashboard-access.firebaseapp.com",
     databaseURL: "https://zila-dashboard-access.firebaseio.com",
     storageBucket: "zila-dashboard-access.appspot.com",
     };
     
     firebase.initializeApp(config);
     */
    var userId = localStorage.getItem("userId");
    console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(12);//.orderByKey();


    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);
        var tble = document.getElementById("table");
        var row = tble.rows;

        if (!snapshot.val().edit) {

            for (var j = 0; j < row.length; j++) {

                // Deleting the "change-status" cell of each row. 
                row[j].deleteCell(12);
            }
        }
    })
}