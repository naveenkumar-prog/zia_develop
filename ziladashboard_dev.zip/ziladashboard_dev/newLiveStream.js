var liveStreamCon = firebase.initializeApp({
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-influencerlive.firebaseapp.com",
    databaseURL: "https://zila-android-influencerlive.firebaseio.com",
    //projectId: "zila-android",
    storageBucket: "zila-android-influencerlive.appspot.com",
    //messagingSenderId: "628597092757",
    //appId: "1:628597092757:android:8b4de02ddb17655c8d869c",
}, 'liveStream');

const divObj = document.getElementById("myTable");
/*
 const dbRefObj = firebase.database().ref();//.child('361');
 const dbRefList = dbRefObj.child('name');
 
 dbRefObj.on('value', snap => {
 //var obj =  JSON.parse(JSON.stringify(snap.val()));   
 console.log(snap.val());
 divObj.innerText = JSON.stringify(snap.val(), null, 3);
 });
 /*
 dbRefList.on('value', snap => {
 console.log(snap.val());
 list.innerText = JSON.stringify(snap.val(), null, 3);
 })
 */

var userDataRef = liveStreamCon.database().ref().child("NewRequest");//.orderByKey();
var count = 0;
userDataRef.on("value", function (snapshot) {
    divObj.innerHTML = ''
    count = 0
    snapshot.forEach(function (childSnapshot) {
        var rootKey = childSnapshot.key;
        console.log(rootKey);
        var childData = childSnapshot.val();

        var key = Object.keys(childSnapshot.val());
        for (i in key) {

            count++;
            var sno = count
            var allotTime = childData[key[i]].allot_time;
            var description = childData[key[i]].description;
            var msg = childData[key[i]].message;
            var name = childData[key[i]].name;
            var sellerId = childData[key[i]].seller_id;
            var status = childData[key[i]].status;
            if (status == 0)
                status = "Pending"
            else if (status == 1)
                status = "Approved"
            else
                status = "Rejected"
            var thumbnail = "<img src='" + childData[key[i]].thumbnail + "' class='thumbnail'>";
            var time = childData[key[i]].timestamp;
            var title = childData[key[i]].title;

            var prodId = []
            var length = 0;
            for (j in childData[key[i]].product_id) {
                length++;
                prodId.push(childData[key[i]].product_id[j]);
            }

            var listProd = "<div id='listOfProducts" + key[i] + "'><b>Product Ids: </b>" + prodId + "</div>"
            var prodInput = "<input placeholder='Enter product id' class='prodInputBox'/><br><input class='addbtn' type='button' value='Add product'/> <input type='button' class='donebtn' value='Done'/>";

            var change = "<select id='" + key[i] + "' onchange='changeStatus(this.id, " + rootKey + ", this.value)'>" +
                    "<option> --Select-- </option>" +
                    "<option value='0'> Pending</option>" +
                    "<option value='1'> Approve</option>" +
                    "<option value='2'> Reject</option>" +
                    "</select>";

            var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                    "<td>" + sno + "</td>" +
                    "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                    "<td>" + thumbnail + "</td>" +
                    "<td>" + name + "</td>" +
                    "<td>" + sellerId + "</td>" +
                    "<td class='canEdit'>" + allotTime + "</td>" +
                    "<td>" + listProd + prodInput + "</td>" +
                    "<td>" + status + "</td>" +
                    "<td>" + change + "</td>" +
                    "<td>" + title + "</td>" +
                    "<td>" + description + "</td>" +
                    "<td>" + msg + "</td>" +
                    "<td>" + time + "</td>" +
                    "</tr>";

            divObj.innerHTML += row;
        }

        $('.editbtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            //get the <td> elements of the selected row that can be edited
            var tds = $this.closest('tr').find('.canEdit').filter(function () {
                return $(this).find('.editbtn').length === 0;
            });

            if ($this.html() === 'Edit') {
                $this.html('Save');
                //make <td> elements of that row editable
                tds.prop('contenteditable', true);
                currentRow.classList.add('currRowEdit');
            } else {
                $this.html('Edit');
                tds.prop('contenteditable', false);
                currentRow.classList.remove('currRowEdit');
                var allotTime = currentRow.cells.item(5).textContent
                updateLiveStream(trId, currentRow.className, allotTime)
            }
        });

        $('.delbtn').click(function () {
            var $this = $(this);
            //get the row element of the delete button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var retVal = confirm("Do you want to remove this video?");
            //if 'ok' is clicked on the alert box
            if (retVal == true) {
                deleteVideo(trId, currentRow.className)
                currentRow.style.display = 'none';
            }
        });

        $('.addbtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var inputElem = $(currentRow).find("input")[0];
            var inputVal = inputElem.value;
            var divId = "listOfProducts" + trId;
            // var divElem = document.getElementById(divId);
            inputElem.value = ''
            addProduct(inputVal, divId);
        });

        $('.donebtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);
            var userId = currentRow.className;
            var divId = "listOfProducts" + trId;
            var divElem = document.getElementById(divId);
            var res = divElem.innerText.split(" ");
            var productIds = res[2].split(",");
            // console.log(res, productIds)
            updateProductList(trId, currentRow.className, productIds);
        });
    });
    checkEditAccess();
});

function checkEditAccess() {

    var userId = localStorage.getItem("userId");
    // console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(13);//.orderByKey();

    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);

        if ((!snapshot.val().edit) && (!snapshot.val().delete)) {

            var tble = document.getElementById("table");
            var row = tble.rows;

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(1);
            }

        }
        if (!snapshot.val().edit) {

            $(".editBtn").remove();
            $(".prodInputBox").remove();
            $(".doneBtn").remove();
            $(".addBtn").remove();

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(8);
            }
        }
        if (!snapshot.val().delete) {
            $(".delBtn").remove();
        }
    })
}

function changeStatus(key, userId, newStatus) {
    var ref = userDataRef.child(userId).child(key);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        // var oldStatus = childData.status;
        //console.log(rootKey) //same as timestamp
        var obj = {"status": newStatus};
        ref.update(obj);
    })
}

function updateLiveStream(key, userId, newAllotTime) {
    var ref = userDataRef.child(userId).child(key);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        //console.log(rootKey) //same as timestamp
        var obj = {"allot_time": newAllotTime};
        ref.update(obj);
        //console.log(childData.allot_time);
    })
}

function addProduct(productId, divId) {
    var divElem = document.getElementById(divId);
    divElem.innerHTML += productId + ',';
}

function updateProductList(key, userId, productIdList) {
    var ref = userDataRef.child(userId).child(key);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        //console.log(rootKey) //same as timestamp
        var childRef = ref.child("product_id");
        childRef.once("value", function (childSnapshot) {
            console.log(productIdList);
            var numberOfProducts = productIdList.length - 1;
            for (var i = 1; i < numberOfProducts + 1; i++) {
                var product = "product" + i;
                var j;
                if (productIdList[0] == "") {
                    j = i;
                } else {
                    j = i - 1;
                }
                var prod = {[product]: productIdList[j]};
                childRef.update(prod);
            }
        })
        alert("Product list updated");
        /*
         functions.childRef.onUpdate(event => {
         console.log("Added product list");
         console.log(event.data.val());
         })
         */
    })
}

function deleteVideo(timeStamp, userId) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.remove();
    alert("Video deleted");
}