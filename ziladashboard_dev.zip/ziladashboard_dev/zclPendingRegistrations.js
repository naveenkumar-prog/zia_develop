var zclPending = firebase.initializeApp({
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zcl-pending-resgistration.firebaseapp.com",
    databaseURL: "https://zcl-pending-resgistration.firebaseio.com/",
    //projectId: "zila-android",
    storageBucket: "zcl-pending-resgistration.appspot.com"
});

const dbref = zclPending.database().ref().child('PendingUser');
dbref.on('value', function (snapshot) {
    let tBody = document.getElementById("tableBody");
    // console.log(snapshot.val());
    let sno = 1;
    
    snapshot.forEach(function (snap) {
        if(snap.val().timestamp == undefined){
        var tim = 'Not Available'
    }
    else{
        var tim = snap.val().timestamp;
    }
        if(snap.val().timestamp != undefined){
         console.log("ssnap",snap.val().timestamp);
        }
        let row = "<tr>" +
                "<td>" + sno + "</td>" +
                "<td>" + snap.val().mobile + "</td>" +
                "<td>" + tim  + "</td>" +
                "</td>"
        tBody.innerHTML += row;
        sno++;
    })
})