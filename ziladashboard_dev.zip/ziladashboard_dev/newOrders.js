var createOrder = localStorage.getItem("createOrder");

console.log("createOrder:",createOrder);

var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
today = yyyy + '-' + mm + '-' + dd;

console.log("ff")
$(document).ready(function () {
    console.log('cc');
    document.getElementById('datePicker').value = today;
    $("#datePicker").datepicker({
        dateFormat: 'yy-mm-dd'
    });
    $("#payment").on("change", function () {
        getOrders(document.getElementById('datePicker').value, $(this).val());
    });
    $("#datePicker").on("change", function () {
        date = $(this).val()
        // console.log(date);  
        getOrders($(this).val(), document.getElementById('payment').value);
    });
    $("#submitBtn").on("click", function () {
        console.log(document.getElementById('payment').value)
        console.log(document.getElementById('datePicker').value)
        submitOrders();
    });
    $("#allOrders").on("change", function () {
        getOrders(document.getElementById('datePicker').value, document.getElementById('payment').value);
    });

});



getOrders(today, 1);


function getOrders(date, payment) {
    document.getElementById("submitBtn").disabled = false;
    // console.log(date, payment);
    var type = 1;
    if (document.getElementById('allOrders').checked == true) {
        type = 3;
    }
    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem('userId'));
    myHeaders.append("sessionkey", sessionStorage.getItem('sessionKey'));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", sessionStorage.getItem("user_type"));
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(createOrder+"type=" + type + "&date=" + date + "&payment_method=" + payment, requestOptions)
            .then(response => response.json())
            .then(result => {
                // console.log(result);
                var tableBody = document.getElementById('tableBody');
                tableBody.innerHTML = "";
                if (result.data.length == 0) {
                    document.getElementById("submitBtn").disabled = true;
                    document.getElementById("noOrders").style.display = 'block'
                } else {
                    document.getElementById("submitBtn").disabled = false;
                    document.getElementById("noOrders").style.display = 'none'
                }
                for (i = 0; i < result.data.length; i++) {
                    var sno = i + 1;
                    var row = "<tr class='row12'>" +
                            "<td>" + sno + "</td>" +
                            "<td>" + result.data[i].address + "</td>" +
                            "<td>" + result.data[i].city + "</td>" +
                            "<td>" + result.data[i].name + "</td>" +
                            "<td>" + result.data[i].phone + "</td>" +
                            "<td>" + result.data[i].pincode + "</td>" +
                            "<td>" + result.data[i].prod_name + "</td>" +
                            "<td>" + result.data[i].sold_product_id + "</td>" +
                            "<td>" + result.data[i].amt + "</td>" +
                            "<td>" + result.data[i].state + "</td>" +
                            "<td>" + result.data[i].user_name + "</td>" +
                            "<td>" + result.data[i].user_add + "</td>" +
                            "<td>" + result.data[i].user_id + "</td>" +
                            "<td>" + result.data[i].user_order_id + "</td>" +
                            "<td>" + result.data[i].user_phone + "</td>" +
                            "<td>" + result.data[i].user_pin + "</td>" +
                            "</tr>";
                    tableBody.innerHTML += row;
                }
                if (type == 3) {
                    document.getElementById("submitBtn").disabled = true;
                }
            })
            .catch(error => console.log('error', error));
}

function submitOrders() {
    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem('userId'));
    myHeaders.append("sessionkey", sessionStorage.getItem('sessionKey'));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", sessionStorage.getItem("user_type"));
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        redirect: 'follow'
    };

    var date = document.getElementById('datePicker').value;
    var payment = document.getElementById('payment').value;

    fetch(createOrder+"type=2&date=" + date + "&payment_method=" + payment, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                if (result.status == 200) {
                    alert("Success!");
                } else {
                    alert("Error");
                }
            })
            .catch(error => console.log('error', error));
}