// const proxyurl = "https://cors-anywhere.herokuapp.com/";
var vendorData = localStorage.getItem("vendorData");


console.log("VendorData:",vendorData);

getNumberOfProducts();
function getNumberOfProducts() {
    document.getElementById("numOrders").innerHTML = "";
    document.getElementById("sale").innerHTML = "";
    document.getElementById("profit").innerHTML = "";
    var myHeaders = new Headers();
    myHeaders.append("userid", "3513");
    myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(vendorData+"user_id=" + localStorage.getItem("userId") + "&order_status=" + document.getElementById('status').value, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(vendorData+"user_id=" + localStorage.getItem("userId") + "&order_status=" + document.getElementById('status').value);
                console.log()
                document.getElementById("numVendorProducts").innerHTML = result.data.total_product;
                document.getElementById("numVendorOrders").innerHTML = result.data.total_order;
                document.getElementById("numOrdersFulfilled").innerHTML = result.data.total_order_fulfilled;
                // var sale = result.sale;
                // console.log(sale.total_Order)
                if (result.sale.total_Order > 0) {
                    document.getElementById("numOrders").innerHTML = result.sale.total_Order;
                    document.getElementById("sale").innerHTML = "₹" + result.sale.sale;
                    document.getElementById("profit").innerHTML = "₹" + result.sale.profit;
                } else {
                    document.getElementById("numOrders").innerHTML = "--";
                    document.getElementById("sale").innerHTML = "--";
                    document.getElementById("profit").innerHTML = "--";
                }
            })
            .catch(error => console.log('error', error));
} 