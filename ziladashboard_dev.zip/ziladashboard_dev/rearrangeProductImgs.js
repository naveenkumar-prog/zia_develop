var postimage = localStorage.getItem("postimage");
var updateimageRank = localStorage.getItem("updateimageRank");

console.log("updateimageRank",updateimageRank);
console.log("postimage",postimage);

function dragStart(e) {
    this.style.opacity = '0.4';
    dragSrcEl = this;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/html', this.innerHTML);
}
;

function dragEnter(e) {
    this.classList.add('over');
}

function dragLeave(e) {
    e.stopPropagation();
    this.classList.remove('over');
    this.style.opacity = '1';
}

function dragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    this.style.opacity = '1';
    return false;
}

function dragDrop(e) {
    if (dragSrcEl != this) {
        dragSrcEl.innerHTML = this.innerHTML;
        this.innerHTML = e.dataTransfer.getData('text/html');
        this.style.opacity = '1';
    }
    return false;
}

function dragEnd(e) {
    var listItens = document.querySelectorAll('.draggable');
    [].forEach.call(listItens, function (item) {
        item.classList.remove('over');
    });
    this.style.opacity = '1';
}

function addEventsDragAndDrop(el) {
    el.addEventListener('dragstart', dragStart, false);
    el.addEventListener('dragenter', dragEnter, false);
    el.addEventListener('dragover', dragOver, false);
    el.addEventListener('dragleave', dragLeave, false);
    el.addEventListener('drop', dragDrop, false);
    el.addEventListener('dragend', dragEnd, false);
}

function removeImage(id) {
    var imgId = id.split('age', 3)[1];
    console.log(imgId)
    var conf = confirm("Are you sure you want to delete the selected image?");
    if (conf) {
        document.getElementById("loaderV").style.display = "block";
        var myHeaders = new Headers();
        myHeaders.append("userid", "3513");
        myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
        myHeaders.append("languagetype", "1");
        myHeaders.append("usertype", "2");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

        var formdata = new FormData();
        formdata.append("image_id", imgId);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };

        fetch(postimage, requestOptions)
                .then(response => response.json())
                .then(result => {
                    document.getElementById("loaderV").style.display = "none";
                    if (result.status == 200) {
                        document.getElementById('ImgDiv' + imgId).style.display = 'none';
                        $('#multiImageModal').modal('hide');
                        alert("Image deleted successfully!");
                    } else {
                        alert("Could not delete image. Try again later");
                    }
                })
                .catch(error => console.log('error', error));
    }
}

function rearrange() {
    if (document.getElementById('rearrangeEditBtn').innerHTML == 'Save Order') {
        saveOrder();
        return;
    }
    console.log('vv')
    document.getElementById('rearrangeEditBtn').innerHTML = 'Save Order'
    document.getElementById('rearrangeEditBtn').classList.add('rearrangeSavetBtn');
    var productImages = document.querySelectorAll('.ImgDiv');
    productImages.forEach(function (item) {
        item.classList.add('draggable');
        item.setAttribute('draggable', true);
    })
    var listItens = document.querySelectorAll('.draggable');
    [].forEach.call(listItens, function (item) {
        addEventsDragAndDrop(item);
    });

}
function saveOrder() {
    var newRank = [];
    var productImgs = document.getElementsByClassName('productImg');
    for (i = 0; i < productImgs.length; i++) {
        var obj = {
            "img_id": productImgs[i].id,
            "rank": i + 1
        }
        newRank.push(obj);
    }
    console.log(newRank);
    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem('userId'));
    myHeaders.append("sessionkey", sessionStorage.getItem('sessionKey'));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", sessionStorage.getItem('user_type'));
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({"rank": newRank});

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    fetch(updateimageRank, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                if (result.status == 200) {
                    alert("Successfully changed the order of images!");
                    $('#multiImageModal').modal('hide');
                } else {
                    alert("Error changing the order");
                    $('#multiImageModal').modal('hide');
                }
            })
            .catch(error => {
                console.log('error', error);
                alert("Error")
            });
}