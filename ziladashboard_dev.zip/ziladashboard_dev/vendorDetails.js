var vendorAnalytics = localStorage.getItem("vendorAnalytics");
console.log("vendorAnalytics",vendorAnalytics);

var vendorName = localStorage.getItem("user_name");
var vendorID = localStorage.getItem("vendorID");
document.getElementById("vendorName").innerHTML = "<b>" + vendorName + "</b><br> (User Id: " + vendorID + ")";

var myHeaders = new Headers();
myHeaders.append("userid", "25");
myHeaders.append("sessionkey", "a2ed9c4adb38820e98d7f511962e2372");
myHeaders.append("languagetype", "2");
myHeaders.append("usertype", "3");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");


var urlencoded = new URLSearchParams();
urlencoded.append("vendor_id", vendorID);



var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: urlencoded,
    redirect: 'follow'
};

fetch(vendorAnalytics, requestOptions)
        .then(response => response.json())
        .then(result => {
            console.log(result);
            // console.log("Last name : ",result.data.address[0].phone);
            document.getElementById("pd_name1").innerHTML += vendorName;
            document.getElementById("email1").innerHTML += result.data.email;
            document.getElementById("id1").innerHTML += vendorID;
            document.getElementById("business1").innerHTML += result.data.username;
            document.getElementById("cancel").innerHTML += result.analytics.amount_cancel;
            document.getElementById("cancel_month").innerHTML += result.analytics.amount_cancel_m;
            document.getElementById("cancel_week").innerHTML += result.analytics.amount_cancel_w;
            document.getElementById("retur").innerHTML += result.analytics.amount_return;
            document.getElementById("retur_m").innerHTML += result.analytics.amount_return_m;
            document.getElementById("retur_w").innerHTML += result.analytics.amount_return_w;
            document.getElementById("sold").innerHTML += result.analytics.products_sold;
            document.getElementById("sold_m").innerHTML += result.analytics.products_sold_m;
            document.getElementById("sold_w").innerHTML += result.analytics.products_sold_w;
            document.getElementById("earning").innerHTML += result.analytics.earning;
            document.getElementById("earning_m").innerHTML += result.analytics.earning_m;
            document.getElementById("earning_w").innerHTML += result.analytics.earning_w;
            document.getElementById("delivered").innerHTML += result.analytics.orders_delivered;
            document.getElementById("delivered_m").innerHTML += result.analytics.orders_delivered_m;
            document.getElementById("delivered_w").innerHTML += result.analytics.orders_delivered_w;
            document.getElementById("received").innerHTML += result.analytics.orders_received;
            document.getElementById("received_m").innerHTML += result.analytics.orders_received_m;
            document.getElementById("received_w").innerHTML += result.analytics.orders_received_w;
            document.getElementById("returned").innerHTML += result.analytics.orders_returned;
            document.getElementById("returned_m").innerHTML += result.analytics.orders_returned_m;
            document.getElementById("returned_w").innerHTML += result.analytics.orders_returned_w;
            document.getElementById("products").innerHTML += result.analytics.products;
            document.getElementById("products_m").innerHTML += result.analytics.products_m;
            document.getElementById("products_w").innerHTML += result.analytics.products_w;
            document.getElementById("sales").innerHTML += result.analytics.gmv;
            document.getElementById("sales_m").innerHTML += result.analytics.gmv_m;
            document.getElementById("sales_w").innerHTML += result.analytics.gmv_w;
            document.getElementById("pay_amount").innerHTML += result.analytics.to_pay;



            if (result.data.address.length > 0) {
                document.getElementById("ph_no1").innerHTML += result.data.email;
                document.getElementById("f_name").innerHTML += result.data.address[0].first_name;
                document.getElementById("l_name").innerHTML += result.data.address[0].last_name;
                document.getElementById("phone").innerHTML += result.data.address[0].phone;
                document.getElementById("full_address").innerHTML += result.data.address[0].address;
                document.getElementById("city").innerHTML += result.data.address[0].city;
                document.getElementById("state").innerHTML += result.data.address[0].state;

                if (result.data.address[0].pincode > 0) {
                    document.getElementById("pincode").innerHTML += result.data.address[0].pincode;
                } else {
                    document.getElementById("pincode").innerHTML += "Not Available";
                }

            } else
            {
                document.getElementById("ph_no1").innerHTML += "Not Available";
                document.getElementById("f_name").innerHTML += "Not Available";
                document.getElementById("l_name").innerHTML += "Not Available";
                document.getElementById("phone").innerHTML += "Not Available";
                document.getElementById("full_address").innerHTML += "Not Available";
                document.getElementById("city").innerHTML += "Not Available";
                document.getElementById("state").innerHTML += "Not Available";
                document.getElementById("pincode").innerHTML += "Not Available";
            }

            if (result.data.aadhar_card == 0)
            {
                document.getElementById("aadhar_no").innerHTML += "Not Updated";
            } else
            {
                document.getElementById("aadhar_no").innerHTML += result.data.aadhar_card;

            }
            if (result.data.pancard == 0)
            {
                document.getElementById("pan_no").innerHTML += "Not Available";
            } else
            {
                document.getElementById("pan_no").innerHTML += result.data.pancard;

            }

            if (result.data.aadhar_image_front == 0)
            {
                var tab2 = document.getElementById("front_img");

                var img2 = "<img src='images/empty.jpg' height='150px' weight='100px'>"

                tab2.innerHTML += img2;
            } else
            {


                var tab2 = document.getElementById("front_img");

                var img2 = "<img src='" + result.data.aadhar_image_front + "' height='150px' weight='100px'>"

                tab2.innerHTML += img2;
            }

            if (result.data.aadhar_image_back == 0)
            {
                var tab2 = document.getElementById("back_img");

                var img2 = "<img src='images/empty.jpg' height='150px' weight='100px'>"


                tab2.innerHTML += img2;
            } else
            {


                var tab2 = document.getElementById("back_img");

                var img2 = "<img src='" + result.data.aadhar_image_back + "' height='150px' weight='50px'>"

                tab2.innerHTML += img2;
            }
            if (result.data.pan_image == 0)
            {
                var tab2 = document.getElementById("pan_image");

                var img2 = "<img src='images/empty.jpg' height='150px' weight='100px'>"

                tab2.innerHTML += img2;
            } else
            {


                var tab2 = document.getElementById("pan_image");

                var img2 = "<img src='" + result.data.pan_image + "' height='150px' weight='50px'>"

                tab2.innerHTML += img2;
            }


        })
        .catch(error => console.log('error', error));