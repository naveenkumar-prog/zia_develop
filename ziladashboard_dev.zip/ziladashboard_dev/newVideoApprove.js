$(document).ready(function () {
    $(document).ajaxStart(function () {
        $("#wait").css("display", "block");
    });
    $(document).ajaxComplete(function () {
        $("#wait").css("display", "none");
    });
    // $("button").click(function(){
    //     tableFromJson();
    // });
});

var newAssignProduct = localStorage.getItem("newAssignProduct");
var newgetUploadvideo = localStorage.getItem("newgetUploadvideo");

console.log("newAssignProduct:",newAssignProduct);
console.log("newgetUploadvideo",newgetUploadvideo);

var userId = localStorage.getItem("userId");

var activitiesconfig = {
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-activities.firebaseapp.com",
    databaseURL: "https://zila-android-activities.firebaseio.com",
    storageBucket: "zila-android-activities.appspot.com"
};
const activityApp = firebase.initializeApp(activitiesconfig, 'Secondary');

function changeStatus(prodVideoId, newStatus) {
    console.log(prodVideoId, newStatus);
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("product_video_id", prodVideoId);
    urlencoded.append("product_video_status", newStatus);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";

    fetch(newAssignProduct, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                if (result.status == 200) {
                    var status;

                    var today = new Date();
                    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                    var dateTime = date + ' ' + time;


                    if (newStatus == 1) {
                        status = "Approved";
                    } else if (newStatus == 2) {
                        status = "Rejected";
                    } else {
                        status = "Not Approved";
                    }
                    var data = {
                        activity: "Changed the status of product video ID '" + prodVideoId + "' to: '" + status + "' ",
                        userId: userId,
                        time: dateTime
                    };
                    activityApp.database().ref('Activities/').push(data);
                    document.getElementById(prodVideoId).cells.item(10).textContent = status;
                }
            })
            .catch(error => console.log('error', error));
}

function changeLang(x) {
    return x;
    location.reload();
}

function addProductList(seller_id, product_video_id, div_id) {
    var divElem = document.getElementById(div_id);
    var arrProdNo = divElem.innerText.split(" ");
    for (var i = 2; i < arrProdId.length; i++) {
        var product_no = arrProdNo[i].split(",")[0];

        var myHeaders = new Headers();
        myHeaders.append("userid", "1784");
        myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
        myHeaders.append("languagetype", "1");
        myHeaders.append("usertype", "0");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
        myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

        var urlencoded = new URLSearchParams();
        urlencoded.append("seller_id", seller_id);
        urlencoded.append("video_link", product_video_id);
        urlencoded.append("product_id", product_no);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: urlencoded,
            redirect: 'follow'
        };

        console.log("sellerId", seller_id, "video_link", product_video_id, "productNo", product_no);

        // const proxyurl = "https://cors-anywhere.herokuapp.com/";

        fetch(newAssignProduct, requestOptions)
                .then(response => response.json())
                .then(result => {
                    //console.log(result)
                    alert("Products added successfully");
                })
                .catch(error => {
                    console.log('error', error)
                    alert("Error adding products!");
                });
    }
}

function addProduct(productId, divId) {
    var divElem = document.getElementById(divId);
    divElem.innerHTML += productId + ', ';
}

// the json data. (you can change the values for output.)
var myHeaders = new Headers();
myHeaders.append("usertype", "0");
myHeaders.append("userid", "1784");
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("languagetype", "1");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

// const proxyurl = "https://cors-anywhere.herokuapp.com/";
const url = newgetUploadvideo+"seller_id=0&status=0";

fetch(url, requestOptions)
        .then(response => {
            return response.json()
        })
        .then(data => {
// Work with JSON data here


            for (var i = 0; i < data.data.length; i++) {
                var statusString = "<select onchange='changeStatus(" + data.data[i].product_video_id + ",this.value)' id=" + 63 + " name=" + status + "> <option selected=" + 0 + " value=" + 0 + ">Not Approved</option> <option value=" + 1 + ">Approved</option><option value=" + 2 + ">Rejected</option> </select>";

                var obj = data.data[i];
                var videoString = "<button  id='" + data.data[i].video_link + "' onclick='videoPopup(this.id)' data-toggle='modal' data-target='#modal1' >Watch video</button>";
                var imageString = "<img src=" + data.data[i].thumbnail + " alt=\"Thumbnail\" width=" + 150 + " height=" + 150 + ">";
                var rowId = data.data[i].product_video_id
                var $tr = $("<tr id='" + rowId + "'>");
                var $SNO = $("<td>");
                var $title = $("<td>");
                var $category_id = $("<td>");
                var $Video = $("<td>");
                var $product_details = $("<td>");
                var $add_product = $("<td>");
                var $created_on = $("<td>");
                var $seller_id = $("<td>");
                var $seller_name = $("<td>");
                var $thumbnail = $("<td>");
                var $status = $('<td>');
                var $changeStatus = $("<td>");

                var listProd = "<div id='listOfProducts" + rowId + "'><b>Product Ids: </b></div>"
                var prodInput = "<input class='prodAddInput' placeholder='Enter product id'/><br><input class='addbtn' type='button' value='Add product'/> <input type='button' class='donebtn' value='Done'/>";
                var vidStatus = "Not approved";
                if (data.data[i].isApproved == 1) {
                    vidStatus = "Approved"
                }

                $SNO.append(i + 1);
                $title.append(obj.title);
                $category_id.append(obj.category_id);
                $Video.append(videoString);
                $product_details.append(obj.product_id + "<br> Details");
                $add_product.append(listProd + prodInput);
                $created_on.append(obj.created_on);
                $seller_id.append(obj.seller_id);
                $seller_name.append(obj.name);
                $thumbnail.append(imageString);
                $status.append(vidStatus)
                $changeStatus.append(statusString);

                $tr.append($SNO);
                $tr.append($title);
                $tr.append($category_id);
                $tr.append($Video);
                $tr.append($product_details);
                $tr.append($add_product);
                $tr.append($created_on);
                $tr.append($seller_id);
                $tr.append($seller_name);
                $tr.append($thumbnail);
                $tr.append($status);
                $tr.append($changeStatus);

                $('#tableBody').append($tr);
            }

            $('.addbtn').click(function () {
                var $this = $(this);
                //get the row element of the edit button
                var trId = $(this).closest('tr').prop('id');
                var currentRow = document.getElementById(trId);
                var inputElem = $(currentRow).find("input")[0];
                var inputVal = inputElem.value;
                var divId = "listOfProducts" + trId;
                var sellerId = currentRow.cells.item(6).textContent;
                //seller_id = sellerId , product_video_id = trId, product_id = inputVal
                //addProduct(sellerId, trId, inputVal);
                //console.log("sellerId ", sellerId, "trId", trId, "inputVal", inputVal, "divId", divId);
                inputElem.value = ''
                addProduct(inputVal, divId);
            });

            $('.donebtn').click(function () {
                var $this = $(this);
                //get the row element of the edit button
                var trId = $(this).closest('tr').prop('id');
                var currentRow = document.getElementById(trId);

                var divId = "listOfProducts" + trId;
                var sellerId = currentRow.cells.item(7).textContent;
                //seller_id = sellerId , product_video_id = trId, product_id = inputVal
                addProductList(sellerId, trId, divId);
            });

            //console.log(data)
            checkEditAccess();
        })
        .catch(error => {
            // Do something for an error here
            console.log("Error", error);
            alert("Error fetching data");
        })

function checkEditAccess() {


    // console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(21);//.orderByKey();

    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);
        var tble = document.getElementById("table");
        var row = tble.rows;

        if (!snapshot.val().edit) {
            $(".addbtn").remove();
            $(".donebtn").remove();
            $(".prodAddInput").remove();

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(11);
            }
        }

    })
}

var video = document.getElementById('video');

function videoPopup(id) {
    var video = document.getElementById('video');
    // var proxyurl = "https://cors-anywhere.herokuapp.com/";
    console.log(id);
    if (id.toString().slice(-3) == 'mp4') {
        //   console.log(3);
        $('#video').html("<source src='" + id + "' type='video/mp4'>")
        // var source = document.createElement('source');
        // source.setAttribute('src', proxyurl+id);
        // video.appendChild(source);
        video.load();
        video.play();
        return;
    } else if (video.canPlayType('application/x-mpegURL'))
    {
        console.log(2);
        $('#video').html("<source src='" + id + "' type='application/x-mpegURL'>")
        video.src = id;
        video.addEventListener('canplay', function ()
        {
            video.play();
        });
    } else if (Hls.isSupported())
    {
        console.log(1);
        var hls = new Hls();
        hls.loadSource(proxyurl + "https://zila-media.s3.us-east-2.amazonaws.com/testing/output.m3u8");
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, function ()
        {
            video.play();
        });
    }


}

function stopVideo() {
    var video = document.getElementById('video');
    video.pause();
    video.currentTime = 0;
}