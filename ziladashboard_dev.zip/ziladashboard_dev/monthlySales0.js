// const proxyurl = "https://cors-anywhere.herokuapp.com/";
var getSalesData = localStorage.getItem("getSaleData");


console.log("getSalData",getSalesData);

buildTable();

function buildTable() {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(getSalesData+"page=0", requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result.month_sale)
                var data = result.month_sale;
                var table = document.getElementById("tableBody");
                table.innerHTML = '';
                for (var i = data.length - 1; i >= 0; i--) {
                    var row = "<tr>" +
                            "<td>" + data[i].month + "</td>" +
                            "<td>" + data[i].tot_orders + "</td>" +
                            "<td>" + data[i].total_sale + "</td>" +
                            "</tr>";

                    table.innerHTML += row;
                }
            })
            .catch(error => {
                console.log('error', error);
                alert("Error fetching data!");
            });
}