var getVerification = localStorage.getItem("getVerification");
var verification = localStorage.getItem("verification");
var getAccountDetails = localStorage.getItem("getAccountDetails");
var proxyurl =localStorage.getItem("proxyurl",proxyurl);
var vendorData = localStorage.getItem("vendorData",vendorData);
var addAccount = localStorage.getItem("addAccount",addAccount);
var addAddress = localStorage.getItem("addAddress",addAddress);
var userAddressList = localStorage.getItem("userAddressList",userAddressList);
var editAddress = localStorage.getItem("editAddress",editAddress);

console.log("editAddress",editAddress);
console.log("userAddressList",userAddressList);
console.log("addAccount",addAccount);
console.log("addAddress",addAddress);
console.log("vendorData",vendorData);
console.log("proxyurl",proxyurl);
console.log("getAccountDetails",getAccountDetails);
console.log("getVerification",getVerification);
console.log("verification",verification);

$('#edit').click(function () {
    var $this = $(this);
    if ($this.html() === 'Edit details') {
        $this.html('Save details')
        var elem = document.getElementsByClassName("info-input")
        for (var i = 0; i < elem.length; i++) {
            elem[i].disabled = false;
        }
    } else {
        $this.html('Edit details')
        sessionStorage.setItem("name", document.getElementById("name").textContent);
        sessionStorage.setItem("email", document.getElementById("email").textContent);
        localStorage.setItem("userId", document.getElementById("userid").textContent);
        localStorage.setItem("username", document.getElementById("userName").textContent);
        var elem = document.getElementsByClassName("info-input")
        for (var i = 0; i < elem.length; i++) {
            elem[i].disabled = true;
        }
    }
})

document.getElementById("name").value = sessionStorage.getItem("name");
document.getElementById("email").value = sessionStorage.getItem("email");
document.getElementById("userid").value = localStorage.getItem("userId");
document.getElementById("userName").value = localStorage.getItem("username");
var user_type = sessionStorage.getItem("user_type");

var userId = parseInt(localStorage.getItem("userId"), 10);
// console.log(userId);
var sessionKey = sessionStorage.getItem("sessionKey");

var data;

var aadhaarnum;
var pannum;
var AImgFront;
var AImgBack;
AImgBack = document.getElementById('AImgBack');
AImgFront = document.getElementById('AImgFront');
var PanImg;
PanImg = document.getElementById('PanImg');

checkVerification();

// var label = document.getElementsByClassName("uploadImgLabel")[0];
// var imgPreviewDiv = document.getElementById("imgPreviewDiv");

function showPreview(event, i) {
    var label = document.getElementsByClassName("uploadImgLabel")[i];
    var imgPreviewDiv = document.getElementsByClassName("imgPreviewDiv")[i];
    if (event.target.files.length > 0) {
        label.style.display = "none";
        var imgPreview = document.getElementsByClassName("imgPreview")[i];
        var preview = document.createElement("img");
        var src = URL.createObjectURL(event.target.files[0]);
        preview.src = src;
        preview.style.width = "132.28px";
        preview.style.height = "94.49px";
        preview.style.margin = "2px";
        imgPreview.appendChild(preview);
        //imgPreviewDiv.insertBefore(preview, label);
        imgPreviewDiv.style.width = "auto";
        imgPreviewDiv.style.height = "auto";
        document.getElementsByClassName("clearBtn")[i].style.display = "block";
    }
}
{/* <div class="addImagesDiv">
    <h4>Upload Images</h4>
    <div>
        <div id="imgPreviewDiv">
            <div id="imgPreview"></div>
                <label class="uploadImgLabel" for="imgsUpload">
                    <h1 style="color: blue;">+</h1>
                </label>
        </div>
        <button class="btn btn-primary my-2" style="display: none;" id="clearBtn" onclick="clearAll()">Choose a different picture</button>
    </div>           
    <input type="file" name="images[]" id="imgsUpload" accept="image/*" class="m-2" onchange="showPreview(event)" style="display: none;">            
</div> */
}



function display() {
    if (user_type == 2) {
        var verificationDetails =
                "<div class='details'>" +
                "<h4 class='my-4' id='vHeader'>Fill in the following details to get your account verified</h4>" +
                "<form onsubmit='submitDetailss(event); return false'>" +
                "<div class='info'>" +
                "<p class='info-field' style='font-weight: 600;'>Aadhaar Number: &nbsp;<input id='aadhaarnum' style='margin-left: 6.5rem;' required></p>" +
                "<p class='info-field' style='font-weight: 600;'>PAN Number: &nbsp;&nbsp;<input id='pannum' style='margin-left: 8rem;' required></p>" +
                "<div class='row p-3'>" +
                "<p class='info-field' style='font-weight: 600;'>Aadhar Card Image (Front):" +
                "<div class='addImagesDiv mx-5'>" +
                "<p class='uploadImg__h'>Upload image below</p>" +
                "<div>" +
                "<div class='imgPreviewDiv'>" +
                "<div class='imgPreview'></div>" +
                "<label class='uploadImgLabel' for='AImgFront'>" +
                "<h1 style='color: blue;''>+</h1>" +
                "</label>" +
                "</div>" +
                "<span><button type='button' class='btn btn-primary btn-sm my-2 clearBtn' style='display: none;' onclick='clearImg(0)'>Choose a different picture</button></span>" +
                "</div>" +
                "<input type='file' accept='image/*' id='AImgFront' accept='image/*' class='m-2' onchange='showPreview(event, 0)' style='display: none;' required>" +
                "</div>" +
                "<span id='AImgFrontP' style='display: none;'>Submitted</span>" +
                "</p>" +
                "</div>" +
                "<div class='row p-3'>" +
                "<p class='info-field' style='font-weight: 600;'>Aadhar Card Image (Back): " +
                "<div class='addImagesDiv  mx-5'>" +
                "<p class='uploadImg__h'>Upload image below</p>" +
                "<div>" +
                "<div class='imgPreviewDiv'>" +
                "<div class='imgPreview'></div>" +
                "<label class='uploadImgLabel' for='AImgBack'>" +
                "<h1 style='color: blue;''>+</h1>" +
                "</label>" +
                "</div>" +
                "<span><button type='button' class='btn btn-primary btn-sm my-2 clearBtn' style='display: none;' class='clearBtn' onclick='clearImg(1)'>Choose a different picture</button></span>" +
                "</div>" +
                "<input type='file' accept='image/*' id='AImgBack' accept='image/*' class='m-2' onchange='showPreview(event, 1)' style='display: none;' required>" +
                "</div>" +
                "</span>" +
                "<span id='AImgBackP' style='display: none;'>Submitted</span>" +
                "</p>" +
                "</div>" +
                "<div class='row p-3'>" +
                "<p class='info-field' style='font-weight: 600;'>PAN Card Image:" +
                "<div class='addImagesDiv  mx-5'>" +
                "<p class='uploadImg__h' style='margin-left: 4.5rem;'>Upload image below</p>" +
                "<div>" +
                "<div class='imgPreviewDiv' style='margin-left: 4.5rem;'>" +
                "<div class='imgPreview'></div>" +
                "<label class='uploadImgLabel' for='PanImg'>" +
                "<h1 style='color: blue;''>+</h1>" +
                "</label>" +
                "</div>" +
                "<span><button type='button' class='btn btn-primary btn-sm my-2 clearBtn' style='display: none; margin-left: 4.5rem;' class='clearBtn' onclick='clearImg(2)'>Choose a different picture</button></span>" +
                "</div>" +
                "<input type='file' accept='image/*' id='PanImg' accept='image/*' class='m-2' onchange='showPreview(event, 2)' style='display: none;' required>" +
                "</div>" +
                "<span id='PanImgP' style='display: none;'>Submitted</span>" +
                "</p>" +
                "</div>" +
                "<button class='btn btn-primary btn-lg mt-5' type='submit' id='submitDetails'>Submit details</button>" +
                "</div>";

        document.getElementById("verificationDetails").style.display = "block";
        document.getElementById("verificationDetails").innerHTML += verificationDetails;

        if (data) {
            var vHeader = document.getElementById("vHeader");
            aadhaarnum = document.getElementById('aadhaarnum');
            pannum = document.getElementById('pannum');
            var AImgFrontP = document.getElementById('AImgFrontP');
            var AImgBackP = document.getElementById('AImgBackP');
            var PanImgP = document.getElementById('PanImgP');
            var submitDetails = document.getElementById('submitDetails');

            PanImg = document.getElementById('PanImg');

            AImgBack = document.getElementById('AImgBack');
            AImgFront = document.getElementById('AImgFront');

            console.log();
            vHeader.innerHTML = "Verified Details";
            aadhaarnum.value = data.aadhar_no;
            pannum.value = data.pan_no;

            aadhaarnum.disabled = "true";
            pannum.disabled = "true";

            AImgFrontP.style.display = "block";
            AImgBackP.style.display = "block";
            PanImgP.style.display = "block";

            var aadhar_image_front = data.aadhar_image_front;
            var aadhar_image_back = data.aadhar_image_back;
            var pan_image = data.pan_image;

            var imgs = [aadhar_image_front, aadhar_image_back, pan_image];
            // console.log(imgs)

            var imgPreview;

            for (i = 0; i < 3; i++) {
                var imgPreviewDiv = document.getElementsByClassName("imgPreviewDiv")[i]
                var label = document.getElementsByClassName("uploadImgLabel")[i];
                document.getElementsByClassName("uploadImg__h")[i].style.display = "none";
                label.style.display = "none";
                var preview = document.createElement("img");
                imgPreview = document.getElementsByClassName("imgPreview")[i];
                preview.src = imgs[i];
                preview.style.width = "132.28px";
                preview.style.height = "94.49px";
                preview.style.margin = "2px";
                imgPreview.appendChild(preview);
                imgPreviewDiv.style.width = "auto";
                imgPreviewDiv.style.height = "auto";
            }

            AImgBack.style.display = "none";
            AImgFront.style.display = "none";
            PanImg.style.display = "none";
            submitDetails.style.display = "none";


        }
    }
}

function clearImg(i) {
    // console.log("clear");
    var label = document.getElementsByClassName("uploadImgLabel")[i];
    document.getElementsByClassName("imgPreview")[i].innerHTML = "";
    label.style.display = "block";
    document.getElementsByClassName("clearBtn")[i].style.display = "none";
    imgPreviewDiv = document.getElementsByClassName("imgPreviewDiv")[i];
    imgPreviewDiv.style.width = "150px";
    imgPreviewDiv.style.height = "150px";
}



//console.log("Name ", sessionStorage.getItem("name"), "Email ", sessionStorage.getItem("email"), "Userid ", localStorage.getItem("userId"),"userName ", localStorage.getItem("username"))

document.onreadystatechange = function () {
    if (document.readyState !== "complete") {
        document.querySelector("body").style.visibility = "hidden";
        document.querySelector("#loader").style.visibility = "visible";
    } else {
        document.querySelector("#loader").style.display = "none";
        document.querySelector("body").style.visibility = "visible";
    }
};




function checkVerification() {
    var myHeaders = new Headers();
    myHeaders.append("sessionkey", sessionKey);
    myHeaders.append("userid", userId);
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formdata = new FormData();

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };


// const proxyurl = "https://cors-anywhere.herokuapp.com/";
    var url = getVerification;


    url += "user_id=" + userId;

    fetch(url, requestOptions)
            .then(response => response.json())
            .then(result => {
                //   console.log(result.data);
                data = result.data;
                display();
            })
            .catch(error => console.log('error', error));

    return data;
}

function submitDetailss() {
    event.preventDefault();
    // console.log(localStorage.getItem("userId"));
    // var AadhaarID = document.getElementById('AadhaarID').value;
    // var PanID = document.getElementById('PanID').value;
    // var gstnum = document.getElementById('gstnum').value;

    var aadhaarno = document.getElementById('aadhaarnum');
    var panno = document.getElementById('pannum');
    var AImgFrontP = document.getElementById('AImgFront');
    var AImgBackP = document.getElementById('AImgBack');
    var PanImgP = document.getElementById('PanImg');


    var myHeaders = new Headers();
    myHeaders.append("sessionkey", sessionKey);
    myHeaders.append("userid", userId);
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "5");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formdata = new FormData();
    formdata.append("aadhar_no", aadhaarno.value);
    formdata.append("pan_no", panno.value);
    formdata.append("aadhar_id", "0");
    formdata.append("pan_id", "0");
    formdata.append("isPanVerified", "0");
    formdata.append("isAadharVerified", "0");
    formdata.append("discription", "");
    formdata.append("aadhar_image_front", AImgFrontP.files[0], "/path/to/file");
    formdata.append("aadhar_image_back", AImgBackP.files[0], "/path/to/file");
    formdata.append("pan_image", PanImgP.files[0], "/path/to/file");

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

  //  const proxyurl = "https://cors-anywhere.herokuapp.com/";
    //const url = "http://api.myzila.com/Verification";
    const url = verification;

    fetch(proxyurl + url, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                console.log("Done");
                location.reload();
            })
            .catch(error => console.log('error', error));
}
getBankDetails();
function getBankDetails() {
    var myHeaders = new Headers();
    myHeaders.append("userid", "3513");
    myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";

    fetch(getAccountDetails+"user_id=" + localStorage.getItem("userId"), requestOptions)
            .then(response => response.json())
            .then(result => {
                // console.log(result);
                if (result.status == 200) {
                    var bankVerificationDetails = document.getElementById("bankVerificationDetails");
                    var details = "<div class='details'>" +
                            "<h4 class='my-4'>Bank Details</h4>" +
                            "<form id='bankDetailsForm' onsubmit='addAccount(event); return false'>" +
                            "<div class='info'>" +
                            "<p style='font-weight: 600;'>Account Number: &nbsp;<input id='acnum' style='margin-left: 5rem'; required></p>" +
                            "<p style='font-weight: 600;'>Account holder's name: &nbsp;<input id='holderName' style='margin-left: 2.4rem;' required></p>" +
                            "<p style='font-weight: 600;'>IFSC Code: &nbsp;<input id='ifsc' style='margin-left: 8.23rem;' required></p>" +
                            "<p style='font-weight: 600;'>Bank Name: &nbsp;<input id='bankName' style='margin-left: 7.55rem;' required></p>" +
                            "<p style='font-weight: 600; display:none'>Razor Pay: &nbsp;<input id='razorPay'></p>" +
                            "<button class='btn btn-primary m-1' style='display:none' id='submitBankDetails'>Submit details</button>" +
                            "</div>" +
                            "</form>" +
                            "<div class='info'>" +
                            "<button class='btn btn-primary' id='transferAmount' style='display:none' onclick='transferAmount()'>Transfer amount</button>" +
                            "<p class='text-secondary' id='minAmt' style='display:none'>You cannot transfer amount to your account right now<p>" +
                            "<p class='text-secondary' id='pending' style='display:none'>Your account details are yet to be verified<p>" +
                            "</div>" +
                            "</div>";
                    bankVerificationDetails.innerHTML = details;
                    // console.log(result.data[0].status, result.data[0].razorpay_id)
                    // console.log(result.data[0].status);
                    if (result.data.length != 0) {
                        if (result.data[0].status == 1) {
                            console.log("12");
                            var acnum = document.getElementById("acnum");
                            var holderName = document.getElementById("holderName");
                            var ifsc = document.getElementById("ifsc");
                            var bankName = document.getElementById("bankName");
                            var razorPay = document.getElementById("razorPay");

                            document.getElementById('submitBankDetails').remove();

                            acnum.value = result.data[0].account_no;
                            holderName.value = result.data[0].account_holder_name;
                            ifsc.value = result.data[0].ifsc_code;
                            bankName.value = result.data[0].bank_name;
                            razorPay.value = result.data[0].razorpay_id;
                            // console.log(razorPay.value, "  mm "+result.data[0].razorpay_id);

                            acnum.disabled = "true";
                            holderName.disabled = "true";
                            ifsc.disabled = "true";
                            bankName.disabled = "true";
                            razorPay.disabled = "true";

                            var myHeaders = new Headers();
                            myHeaders.append("userid", "3513");
                            myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
                            myHeaders.append("languagetype", "1");
                            myHeaders.append("usertype", "2");
                            myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

                            var requestOptions = {
                                method: 'GET',
                                headers: myHeaders,
                                redirect: 'follow'
                            };
                            // const proxyurl = "https://cors-anywhere.herokuapp.com/";
                            fetch(vendorData+"user_id=" + userId + "&order_status=3", requestOptions)
                                    .then(response => response.json())
                                    .then(result => {
                                        // console.log(result);
                                        console.log(+result.sale.profit)
                                        if (result.sale.profit > 5) {
                                            amt = +result.sale.profit;
                                            document.getElementById('transferAmount').style.display = 'block';
                                        } else {
                                            amt = +result.sale.profit;
                                            document.getElementById('transferAmount').style.display = 'block';
                                            document.getElementById("transferAmount").disabled = true;
                                            document.getElementById('minAmt').style.display = 'block';
                                        }
                                    })
                                    .catch(error => console.log('error', error));
                        } else if (result.data[0].status == 0) {
                            console.log('xxvv');
                            document.getElementById('bankDetailsForm').remove();
                            document.getElementById("pending").style.display = 'block';
                        }
                    } else {
                        console.log("2");
                        document.getElementById('submitBankDetails').style.display = 'block';
                        document.getElementById('transferAmount').remove();
                    }
                    bankVerificationDetails.style.display = 'block';
                }

            })
            .catch(error => console.log('error', error));
}
// console.log("xx")
function addAccount() {
    var acnum = document.getElementById("acnum");
    var holderName = document.getElementById("holderName");
    var ifsc = document.getElementById("ifsc");
    var bankName = document.getElementById("bankName");
    var myHeaders = new Headers();
    myHeaders.append("userid", "3513");
    myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("ifsc_code", ifsc.value.trim());
    urlencoded.append("account_holder_name", bankName.value.trim());
    urlencoded.append("account_no", acnum.value.trim());
    urlencoded.append("bank_name", holderName.value.trim());
    urlencoded.append("user_id", userId);

    // console.log(ifsc.value, bankName.value, acnum.value, holderName.value, userId)

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };
    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
    fetch(addAccount, requestOptions)
            .then(response => response.json())
            .then(result => {
                // console.log(result)
                if (result.status == 200) {
                    alert("Successfully submitted your account details!");
                    location.reload();
                } else {
                    alert("Could not submit your account details. Try Again.");
                    location.reload();
                }
            })
            .catch(error => console.log('error', error));
}
// getAmount();
var amt = 0;
// console.log("cc");
function transferAmount() {
    // console.log(userId);
    // console.log(sessionKey);
    var myHeaders = new Headers();
    myHeaders.append("userid", "3513");
    myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
    myHeaders.append("languagetype", "1");
    myHeaders.append("user_type", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var currentdate = new Date();
    var datetime = currentdate.getFullYear() + "-" + currentdate.getDate() + "-" + (currentdate.getMonth() + 1) + " " +
            +currentdate.getHours() + ":"
            + currentdate.getMinutes() + ":"
            + currentdate.getSeconds();
    console.log(datetime);
    console.log(razorPay.value);
    console.log(amt * 100);
    var urlencoded = new URLSearchParams();
    urlencoded.append("amount", amt * 100);
    urlencoded.append("account", razorPay.value);
    urlencoded.append("transaction_date", datetime);
    urlencoded.append("order_id", "Transfer To Account");

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };
    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
    // fetch(proxyurl+"http://api.myzila.com/TransferMoney", requestOptions)
    // .then(response => response.json())
    // .then(result => {
    //     console.log(result);
    //     if(result.status == 200){
    //         alert('Success!');
    //     }
    //     else{
    //         alert('Error. Try again later.');
    //     }
    // })
    // .catch(error => console.log('error', error));
}
getAddress();
function getAddress() {
    console.log(sessionKey, userId)
    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
    var myHeaders = new Headers();
    myHeaders.append("sessionkey", sessionKey);
    myHeaders.append("userid", userId);
    myHeaders.append("languagetype", "1");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    // myHeaders.append("Cookie", "ci_session=vr7d25lk2ajmfacb5gpd26h9am3qnf92");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    //console.log(Cookies.get('zilaSessionKey'), Cookies.get('zilaUserId')); 

    fetch(userAddressList, requestOptions)
            .then(response => {
                // console.log(response.status)
                if (response.status === 204) {
                    return 204;
                } else {
                    return response.json();
                }
            })
            .then(result => {
                // console.log(result);
                var addressForm = "<div class='addAddressForm' id='addAddressForm'>" +
                        "<div class='addressNames'>" +
                        "<label for'firstName'>First Name</label>" +
                        "<input class='form-control my-2' placeholder='First name' id='firstName' type='text'/>" +
                        "<label for'lastName'>Last Name</label>" +
                        "<input class='form-control my-2' placeholder='Last name' id='lastName' type='text'/>" +
                        "</div>" +
                        "<div class='location'>" +
                        "<label for'pincode'>Pin code</label>" +
                        "<input class='form-control my-2' placeholder='Pincode' id='pincode' type='text'/>" +
                        "</div>" +
                        "<div class='addressField'>" +
                        "<label for'fullAddress'>Full Address</label>" +
                        "<input class='form-control my-2' type='text' id='fullAddress' placeholder='Address'>" +
                        "</div>" +
                        "<div class='cityAndState'>" +
                        "<label for'city'>City</label>" +
                        "<input class='form-control my-2' type='text' id='city' placeholder='City'/>" +
                        "<label for'state'>State</label>" +
                        "<input class='form-control my-2' type='text' id='state' placeholder='State'/>" +
                        "</div>" +
                        "<div class='phone'>" +
                        "<label for'phoneNum'>Phone number</label>" +
                        "<input class='form-control my-2' type='text' id='phoneNum' placeholder='Phone number'>" +
                        "</div>" +
                        "<div class='addBtn' id>" +
                        "<input class='btn btn-primary m-3 mx-0' type='button' value='Save address' onclick='addAddress()'>" +
                        "</div>" +
                        "</div>";
                var addressDetails = document.getElementById('addressDetails');
                if (result == 204) {
                    var addressFormDiv = "<div class='details' id='showAddressFormDiv'>" +
                            "<h4 class='my-4'>Submit Address</h4>" +
                            addressForm +
                            "</div>";
                    addressDetails.innerHTML += addressFormDiv;
                    addressDetails.style.display = 'block';
                } else if (result.status == 200) {
                    var addresses = result.data;
                    for (var i = 0; i < addresses.length; i++) {

                        // var addressString = ""+addresses[i].first_name+" "+addresses[i].last_name+",\n Phone: "+addresses[i].phone+", "+addresses[i].address+", "+addresses[i].city+", "+addresses[i].state+", "+addresses[i].pincode;
                        var addressString = "<label for'firstNameEdit'>First Name</label>" +
                                "<input class='form-control my-2' value='" + addresses[i].first_name + "' id='firstNameEdit' type='text' disabled/>" +
                                "<label for'lastNameEdit'>Last Name</label>" +
                                "<input class='form-control my-2' value='" + addresses[i].last_name + "' id='lastNameEdit' type='text' disabled/>" +
                                "<label for'phoneNumEdit'>Phone number</label>" +
                                "<input class='form-control my-2' type='text' id='phoneNumEdit' value='" + addresses[i].phone + "' disabled/>" +
                                "<label for'fullAddressEdit'>Full Address</label>" +
                                "<input class='form-control my-2' type='text' id='fullAddressEdit' value='" + addresses[i].address + "' disabled/>" +
                                "<label for'cityEdit'>City</label>" +
                                "<input class='form-control my-2' type='text' id='cityEdit' value='" + addresses[i].city + "' disabled/>" +
                                "<label for'stateEdit'>State</label>" +
                                "<input class='form-control my-2' type='text' id='stateEdit' value='" + addresses[i].state + "' disabled/>" +
                                "<label for'pincodeEdit'>Pin code</label>" +
                                "<input class='form-control my-2' value='" + addresses[i].pincode + "' id='pincodeEdit' type='text' disabled/>" +
                                "<input class='btn btn-primary m-3 mx-0 editAddress' type='button' value='Edit Address' id='" + addresses[i].user_address_id + "' onclick='editAddress()'>";
                        var address = "<div class='details' id='addressDetailsChild'>" +
                                "<h4 class='my-4'>Address</h4>" +
                                "<div id='addressString'>" +
                                addressString +
                                "</div>" +
                                "</div>";

                        addressDetails.innerHTML += address;
                        addressDetails.style.display = 'block';
                    }
                }
            })
            .catch(error => console.log('error', error));
}

function editAddress() {
    var editBtn = document.getElementsByClassName('editAddress')[0];
    var firstNameEdit = document.getElementById('firstNameEdit');
    var lastNameEdit = document.getElementById('lastNameEdit');
    var phoneNumEdit = document.getElementById('phoneNumEdit');
    var fullAddressEdit = document.getElementById('fullAddressEdit');
    var cityEdit = document.getElementById('cityEdit');
    var stateEdit = document.getElementById('stateEdit');
    var pincodeEdit = document.getElementById('pincodeEdit');
    if (editBtn.value == 'Edit Address') {
        editBtn.value = 'Update Address';
        firstNameEdit.disabled = false;
        lastNameEdit.disabled = false;
        phoneNumEdit.disabled = false;
        fullAddressEdit.disabled = false;
        cityEdit.disabled = false;
        stateEdit.disabled = false;
        pincodeEdit.disabled = false;
    } else {
        editBtn.value = 'Edit Address';
        firstNameEdit.disabled = true;
        lastNameEdit.disabled = true;
        phoneNumEdit.disabled = true;
        fullAddressEdit.disabled = true;
        cityEdit.disabled = true;
        stateEdit.disabled = true;
        pincodeEdit.disabled = true;
        console.log(firstNameEdit.value)
        var myHeaders = new Headers();
        myHeaders.append("userid", userId);
        myHeaders.append("sessionkey", sessionKey);
        myHeaders.append("languagetype", "1");
        myHeaders.append("user_type", "4");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
        myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
        myHeaders.append("Cookie", "ci_session=12p29em3do4a17jkl7kqbahk9c9isfai");

        var urlencoded = new URLSearchParams();
        urlencoded.append("address", fullAddressEdit.value);
        urlencoded.append("first_name", firstNameEdit.value);
        urlencoded.append("last_name", lastNameEdit.value);
        urlencoded.append("state", stateEdit.value);
        urlencoded.append("phone", phoneNumEdit.value);
        urlencoded.append("city", cityEdit.value);
        urlencoded.append("latitude", "0");
        urlencoded.append("longitude", "0");
        urlencoded.append("pincode", pincodeEdit.value);
        urlencoded.append("user_address_id", editBtn.id);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: urlencoded,
            redirect: 'follow'
        };

        // const proxyurl = "https://cors-anywhere.herokuapp.com/";
        fetch(editAddress, requestOptions)
                .then(response => response.json())
                .then(result => {
                    console.log(result);
                    if (result.status == 200) {
                        alert("Your address has been updated successfully!");
                        location.reload()
                    } else
                        alert("Error updating your address.")
                })
                .catch(error => console.log('error', error));

    }
}

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        alert("Geolocation is not supported by this browser. Please use a different browser :(");
    }
}

function showPosition(position) {
    var lat = position.coords.latitude;
    var lng = position.coords.longitude;

    document.getElementById("lat").value = lat;
    document.getElementById('lng').value = lng;

    document.getElementById("latlngDiv").style.display = 'block';

    //console.log(lat, lng);
}

// function showAddressForm(){
//     document.getElementById('addAddressForm').style.display = 'block';
//     document.getElementById('showAddressFormBtn').style.display = 'none';
// }
console.log("vvv")
function addAddress() {

    var first_name = document.getElementById("firstName").value;
    var last_name = document.getElementById("lastName").value;
    var pin = document.getElementById("pincode").value;
    var complete_address = document.getElementById("fullAddress").value;
    var latitude = "0";
    var longitude = "0";
    var city = document.getElementById("city").value;
    var state = document.getElementById("state").value;
    var phone = document.getElementById("phoneNum").value;
    console.log(phone)

    if (first_name == "") {
        alert("Please enter the first name");
    } else if (last_name == "") {
        alert("Please enter the last name");
    } else if (pin == "") {
        alert("Please enter the pincode");
    } else if (complete_address == "") {
        alert("Please enter the address");
    } else if (city == "") {
        alert("Please enter the city");
    } else if (state == "") {
        alert("Please enter the state");
    } else if (phone == "") {
        alert("Please enter the phone");
    } else {
        var myHeaders = new Headers();
        myHeaders.append("sessionkey", sessionKey);
        myHeaders.append("userid", userId);
        myHeaders.append("languagetype", "1");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
        myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
        myHeaders.append("Cookie", "ci_session=vr7d25lk2ajmfacb5gpd26h9am3qnf92");

        var urlencoded = new URLSearchParams();
        urlencoded.append("address", complete_address);
        urlencoded.append("first_name", first_name);
        urlencoded.append("last_name", last_name);
        urlencoded.append("state", state);
        urlencoded.append("pincode", pin);
        urlencoded.append("city", city);
        urlencoded.append("phone", phone);
        urlencoded.append("latitude", latitude);
        urlencoded.append("longitude", longitude);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: urlencoded,
            redirect: 'follow'
        };



        fetch(addAddress, requestOptions)
                .then(response => response.json())
                .then(result => {
                    //console.log(result)
                    alert("Address added");
                    // changeAddressBtnDisplay(2);
                    // getAddressList();
                    location.reload();
                })
                .catch(error => console.log('error', error));
    }
}