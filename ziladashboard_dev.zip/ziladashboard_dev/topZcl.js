// const proxyurl = "https://cors-anywhere.herokuapp.com/";
var getSalesData = localStorage.getItem("getSaleData");

console.log("getSalesData",getSalesData);

getTopZcl();

function getTopZcl() {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(getSalesData+"page=0", requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                var data = result.top_zcl;
                var table = document.getElementById("tableBody");
                table.innerHTML = '';
                for (var i = 0; i < data.length; i++) {
                    var rank = i + 1;
                    var row = "<tr>" +
                            "<td>" + rank + "</td>" +
                            "<td>" + data[i].name + "</td>" +
                            "<td>" + data[i].store_partner_id + "</td>" +
                            "<td>" + data[i].tot_commission + "</td>" +
                            "<td>" + data[i].tot_order + "</td>" +
                            "</tr>";

                    table.innerHTML += row;
                }
            })
            .catch(error => console.log('error', error));
}