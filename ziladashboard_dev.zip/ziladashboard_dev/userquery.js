console.log('hello')
console.log('cc')

// To fetch data from firebase

var userqueryCon = firebase.initializeApp({
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-query.firebaseapp.com",
    databaseURL: "https://zila-android-query.firebaseio.com/",
//   projectId: "zila-android",
    storageBucket: "zila-android-query.appspot.com",
//   messagingSenderId: "628597092757"
}, 'userquery');

var userDataRef = userqueryCon.database().ref();

const divObj = document.getElementById("myTable");

var allData = {};
var userDataRef = userqueryCon.database().ref();
var count = 0;
userDataRef.on("value", function (snapshot) {
    divObj.innerHTML = ''
    count = 0
    snapshot.forEach(function (childSnapshot) {
        var rootKey = childSnapshot.key;
        var childData = childSnapshot.val();
        var key = Object.keys(childSnapshot.val());
        for (i in key) {
            // x++;
            count++;
            var sno = count
            var name = childData[key[i]].name;
            var email = childData[key[i]].email;
            var phoneno = childData[key[i]].phoneno;
            var subject = childData[key[i]].subject;
            var message = childData[key[i]].message;

            var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                    "<td>" + sno + "</td>" +
                    "<td>" + name + "</td>" +
                    "<td>" + email + "</td>" +
                    "<td>" + phoneno + "</td>" +
                    "<td>" + subject + "</td>" +
                    "<td>" + message + "</td>" +
                    "</tr>";

            divObj.innerHTML += row;
        }
    });
});