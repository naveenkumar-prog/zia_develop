// Onclick Add Link Button

var updateWhatsappLink = localStorage.getItem("updateWhatsappLink");

console.log("updateWhatsappLink:",updateWhatsappLink);

function whatsapplink() {
    var strid = document.getElementById("strid").value;
    var strph = document.getElementById("strno").value;
    var strlin = document.getElementById("strlink").value;

    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formdata = new FormData();
    formdata.append("phone", strph);
    formdata.append("zcl_id", strid);
    formdata.append("whatsapp_link", strlin);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    fetch(updateWhatsappLink, requestOptions)
            .then(response => response.text())
            .then(result => {
                alert("Link Added");
                location.href = "whatsapplink.html";
            })
            .catch(error => console.log('error', error));
}