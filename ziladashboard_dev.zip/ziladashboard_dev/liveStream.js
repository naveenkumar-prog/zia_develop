console.log('cx')
console.log('cc')

// To fetch firebase data
var getdetailsbyId = localStorage.getItem("getdetailsbyId");
var sendNotification = localStorage.getItem("sendNotification");

console.log("sendNotification:",sendNotification);
console.log("getdetailsbyId:",getdetailsbyId);

var liveStreamCon = firebase.initializeApp({
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-influencerlive.firebaseapp.com",
    databaseURL: "https://zila-android-influencerlive.firebaseio.com",
    //projectId: "zila-android",
    storageBucket: "zila-android-influencerlive.appspot.com",
    //messagingSenderId: "628597092757",
    //appId: "1:628597092757:android:8b4de02ddb17655c8d869c",
}, 'liveStream');

var userDataRef = liveStreamCon.database().ref().child("Request");

$(document).ready(function () {
    console.log('cc')
    $("#datePicker").datepicker({
        dateFormat: 'yy-mm-dd'
    });
});
var date;
var satusG;
$("#datePicker").on("change", function () {
    date = $(this).val()
    // console.log(date);  
    userDataRef.on('value', getDateData, errFunc);
});
$("#status").on("change", function () {
    statusG = $(this).val();
    console.log(statusG);
    userDataRef.on('value', getData, errFunc);
});
console.log('cc')
var divObj = document.getElementById("myTable");
/*
 const dbRefObj = firebase.database().ref();//.child('361');
 const dbRefList = dbRefObj.child('name');
 
 dbRefObj.on('value', snap => {
 //var obj =  JSON.parse(JSON.stringify(snap.val()));   
 console.log(snap.val());
 divObj.innerText = JSON.stringify(snap.val(), null, 3);
 });
 /*
 dbRefList.on('value', snap => {
 console.log(snap.val());
 list.innerText = JSON.stringify(snap.val(), null, 3);
 })
 */
var allData = {};
var userDataRef = liveStreamCon.database().ref().child("Request");//.orderByKey();
var count = 0;
userDataRef.on("value", function (snapshot) {
    divObj.innerHTML = ''
    count = 0
    snapshot.forEach(function (childSnapshot) {
        var rootKey = childSnapshot.key;
        var childData = childSnapshot.val();
        var x = 0;
        var key = Object.keys(childSnapshot.val()); // To return the keys as an array
        for (i in key) {
            // x++;
            count++;
            var sno = count
            var allotTime = childData[key[i]].allot_time;
            var description = childData[key[i]].description;
            var msg = childData[key[i]].message;
            var name = childData[key[i]].name;
            var sellerId = childData[key[i]].seller_id;
            var status = childData[key[i]].status;
            if (status == 0)
                status = "Pending"
            else if (status == 1)
                status = "Approved"
            else
                status = "Rejected"
            var thumbnail = "<img id='thumbnail" + sellerId + "' src='" + childData[key[i]].thumbnail + "' class='thumbnail'>";
            var time = childData[key[i]].time;
            var title = childData[key[i]].title;

            var prodId = []
            var length = 0;
            for (j in childData[key[i]].product_id) {
                length++;
                prodId.push(childData[key[i]].product_id[j]);
            }

            var listProd = "<div id='listOfProducts" + key[i] + "'><b>Product Ids: </b>" + prodId + "</div>"
            var prodInput = "<input placeholder='Enter product id' class='prodInputBox'/><br><input class='addbtn' type='button' value='Add product'/> <input type='button' class='donebtn' value='Done'/>";

            var change = "<select id='" + key[i] + "' onchange='changeStatus(this.id, " + rootKey + ", this.value)'>" +
                    "<option> --Select-- </option>" +
                    "<option value='0'> Pending</option>" +
                    "<option value='1'> Approve</option>" +
                    "<option value='2'> Reject</option>" +
                    "</select>";

            var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                    "<td>" + sno + "</td>" +
                    "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                    "<td>" + thumbnail + "</td>" +
                    "<td>" + name + "</td>" +
                    "<td>" + sellerId + "</td>" +
                    "<td class='canEdit'>" + allotTime + "</td>" +
                    "<td>" + listProd + prodInput + "</td>" +
                    "<td>" + status + "</td>" +
                    "<td>" + change + "</td>" +
                    "<td>" + title + "</td>" +
                    "<td>" + description + "</td>" +
                    "<td>" + msg + "</td>" +
                    "<td>" + time + "</td>" +
                    "</tr>";

            divObj.innerHTML += row;
        }

        $('.editbtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            //get the <td> elements of the selected row that can be edited
            var tds = $this.closest('tr').find('.canEdit').filter(function () {
                return $(this).find('.editbtn').length === 0;
            });

            if ($this.html() === 'Edit') {
                $this.html('Save');
                //make <td> elements of that row editable
                tds.prop('contenteditable', true);
                currentRow.classList.add('currRowEdit');
            } else {
                $this.html('Edit');
                tds.prop('contenteditable', false);
                currentRow.classList.remove('currRowEdit');
                var allotTime = currentRow.cells.item(5).textContent
                updateLiveStream(trId, currentRow.className, allotTime)
            }
        });

        $('.delbtn').click(function () {
            var $this = $(this);
            //get the row element of the delete button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var retVal = confirm("Do you want to remove this video?");
            //if 'ok' is clicked on the alert box
            if (retVal == true) {
                deleteVideo(trId, currentRow.className)
                currentRow.style.display = 'none';
            }
        });

        // On click Add Button

        $('.addbtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var inputElem = $(currentRow).find("input")[0];
            var inputVal = inputElem.value;
            var divId = "listOfProducts" + trId;
            inputElem.value = ''
            addProduct(inputVal, divId);
        });

        // On click Done Button

        $('.donebtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);
            var userId = currentRow.className;
            var divId = "listOfProducts" + trId;
            var divElem = document.getElementById(divId);
            var res = divElem.innerText.split(" ");
            var productIds = res[2].split(",");

            updateProductList(trId, currentRow.className, productIds)
        });
    });
    checkEditAccess();
});

// function searchFunc(val, data){
//     // console.log(data, val);
//     var filteredData = [];
//     // console.log(data.length)
//     var len = Object.keys(data).length;
//     for(var i=0; i<len; i++){
//         console.log(data[i].name.toLowerCase())
//         if(data[i].name.toLowerCase().includes(val)){
//             filteredData.push(data[i]);
//         }
//     }
//     buildSearchTable(filteredData);
//     console.log(filteredData);
// }

// To display the matched data according to our search as a table

function buildSearchTable() {
    userDataRef.once("value", function (snapshot) {
        var val = document.getElementById('search').value;
        if (val == "")
            return;
        divObj.innerHTML = ''
        count = 0
        snapshot.forEach(function (childSnapshot) {
            var rootKey = childSnapshot.key;
            var childData = childSnapshot.val();
            // console.log(d)        

            var key = Object.keys(childSnapshot.val());
            for (i in key) {
                var name = childData[key[i]].name;
                var title = childData[key[i]].title;
                if (name.toLowerCase().includes(val) || title.toLowerCase().includes(val)) {
                    count++;
                    var sno = count
                    var allotTime = childData[key[i]].allot_time;
                    var msg = childData[key[i]].message;
                    var sellerId = childData[key[i]].seller_id;
                    var description = childData[key[i]].description;
                    var status = childData[key[i]].status;
                    if (status == 0)
                        status = "Pending"
                    else if (status == 1)
                        status = "Approved"
                    else
                        status = "Rejected"
                    var thumbnail = "<img id='thumbnail" + sellerId + "' src='" + childData[key[i]].thumbnail + "' class='thumbnail'>";
                    var time = childData[key[i]].time;

                    var prodId = []
                    var length = 0;
                    for (j in childData[key[i]].product_id) {
                        length++;
                        prodId.push(childData[key[i]].product_id[j]);
                    }

                    var listProd = "<div id='listOfProducts" + key[i] + "'><b>Product Ids: </b>" + prodId + "</div>"
                    var prodInput = "<input placeholder='Enter product id' class='prodInputBox'/><br><input class='addbtn' type='button' value='Add product'/> <input type='button' class='donebtn' value='Done'/>";

                    var change = "<select id='" + key[i] + "' onchange='changeStatus(this.id, " + rootKey + ", this.value)'>" +
                            "<option> --Select-- </option>" +
                            "<option value='0'> Pending</option>" +
                            "<option value='1'> Approve</option>" +
                            "<option value='2'> Reject</option>" +
                            "</select>";

                    var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                            "<td>" + thumbnail + "</td>" +
                            "<td>" + name + "</td>" +
                            "<td>" + sellerId + "</td>" +
                            "<td class='canEdit'>" + allotTime + "</td>" +
                            "<td>" + listProd + prodInput + "</td>" +
                            "<td>" + status + "</td>" +
                            "<td>" + change + "</td>" +
                            "<td>" + title + "</td>" +
                            "<td>" + description + "</td>" +
                            "<td>" + msg + "</td>" +
                            "<td>" + time + "</td>" +
                            "</tr>";

                    divObj.innerHTML += row;
                }
            }

            $('.editbtn').click(function () {
                var $this = $(this);
                //get the row element of the edit button
                var trId = $(this).closest('tr').prop('id');
                var currentRow = document.getElementById(trId);

                //get the <td> elements of the selected row that can be edited
                var tds = $this.closest('tr').find('.canEdit').filter(function () {
                    return $(this).find('.editbtn').length === 0;
                });

                if ($this.html() === 'Edit') {
                    $this.html('Save');
                    //make <td> elements of that row editable
                    tds.prop('contenteditable', true);
                    currentRow.classList.add('currRowEdit');
                } else {
                    $this.html('Edit');
                    tds.prop('contenteditable', false);
                    currentRow.classList.remove('currRowEdit');
                    var allotTime = currentRow.cells.item(5).textContent
                    updateLiveStream(trId, currentRow.className, allotTime)
                }
            });

            $('.delbtn').click(function () {
                var $this = $(this);
                //get the row element of the delete button
                var trId = $(this).closest('tr').prop('id');
                var currentRow = document.getElementById(trId);

                var retVal = confirm("Do you want to remove this video?");
                //if 'ok' is clicked on the alert box
                if (retVal == true) {
                    deleteVideo(trId, currentRow.className)
                    currentRow.style.display = 'none';
                }
            });

            $('.addbtn').click(function () {
                var $this = $(this);
                //get the row element of the edit button
                var trId = $(this).closest('tr').prop('id');
                var currentRow = document.getElementById(trId);

                var inputElem = $(currentRow).find("input")[0];
                var inputVal = inputElem.value;
                var divId = "listOfProducts" + trId;
                inputElem.value = ''
                addProduct(inputVal, divId);
            });

            $('.donebtn').click(function () {
                var $this = $(this);
                //get the row element of the edit button
                var trId = $(this).closest('tr').prop('id');
                var currentRow = document.getElementById(trId);
                var userId = currentRow.className;
                var divId = "listOfProducts" + trId;
                var divElem = document.getElementById(divId);
                var res = divElem.innerText.split(" ");
                var productIds = res[2].split(",");

                updateProductList(trId, currentRow.className, productIds)
            });
        });
    });
}

//Get data according to Date

function getDateData(snapshot) {

    divObj.innerHTML = ''
    count = 0
    snapshot.forEach(function (childSnapshot) {
        var rootKey = childSnapshot.key;
        var childData = childSnapshot.val();
        // console.log(d)        

        var key = Object.keys(childSnapshot.val());
        for (i in key) {
            var d = childData[key[i]].time.split(' ', 2)[0];
            if (d == date) {
                count++;
                var sno = count
                var allotTime = childData[key[i]].allot_time;
                var description = childData[key[i]].description;
                var msg = childData[key[i]].message;
                var name = childData[key[i]].name;
                var sellerId = childData[key[i]].seller_id;
                var status = childData[key[i]].status;
                if (status == 0)
                    status = "Pending"
                else if (status == 1)
                    status = "Approved"
                else
                    status = "Rejected"
                var thumbnail = "<img id='thumbnail" + sellerId + "' src='" + childData[key[i]].thumbnail + "' class='thumbnail'>";
                var time = childData[key[i]].time;
                var title = childData[key[i]].title;

                var prodId = []
                var length = 0;
                for (j in childData[key[i]].product_id) {
                    length++;
                    prodId.push(childData[key[i]].product_id[j]);
                }

                var listProd = "<div id='listOfProducts" + key[i] + "'><b>Product Ids: </b>" + prodId + "</div>"
                var prodInput = "<input placeholder='Enter product id' class='prodInputBox'/><br><input class='addbtn' type='button' value='Add product'/> <input type='button' class='donebtn' value='Done'/>";

                var change = "<select id='" + key[i] + "' onchange='changeStatus(this.id, " + rootKey + ", this.value)'>" +
                        "<option> --Select-- </option>" +
                        "<option value='0'> Pending</option>" +
                        "<option value='1'> Approve</option>" +
                        "<option value='2'> Reject</option>" +
                        "</select>";

                var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                        "<td>" + sno + "</td>" +
                        "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                        "<td>" + thumbnail + "</td>" +
                        "<td>" + name + "</td>" +
                        "<td>" + sellerId + "</td>" +
                        "<td class='canEdit'>" + allotTime + "</td>" +
                        "<td>" + listProd + prodInput + "</td>" +
                        "<td>" + status + "</td>" +
                        "<td>" + change + "</td>" +
                        "<td>" + title + "</td>" +
                        "<td>" + description + "</td>" +
                        "<td>" + msg + "</td>" +
                        "<td>" + time + "</td>" +
                        "</tr>";

                divObj.innerHTML += row;
            }
        }

        $('.editbtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            //get the <td> elements of the selected row that can be edited
            var tds = $this.closest('tr').find('.canEdit').filter(function () {
                return $(this).find('.editbtn').length === 0;
            });

            if ($this.html() === 'Edit') {
                $this.html('Save');
                //make <td> elements of that row editable
                tds.prop('contenteditable', true);
                currentRow.classList.add('currRowEdit');
            } else {
                $this.html('Edit');
                tds.prop('contenteditable', false);
                currentRow.classList.remove('currRowEdit');
                var allotTime = currentRow.cells.item(5).textContent
                updateLiveStream(trId, currentRow.className, allotTime)
            }
        });

        $('.delbtn').click(function () {
            var $this = $(this);
            //get the row element of the delete button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var retVal = confirm("Do you want to remove this video?");
            //if 'ok' is clicked on the alert box
            if (retVal == true) {
                deleteVideo(trId, currentRow.className)
                currentRow.style.display = 'none';
            }
        });

        $('.addbtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var inputElem = $(currentRow).find("input")[0];
            var inputVal = inputElem.value;
            var divId = "listOfProducts" + trId;
            inputElem.value = ''
            addProduct(inputVal, divId);
        });

        $('.donebtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);
            var userId = currentRow.className;
            var divId = "listOfProducts" + trId;
            var divElem = document.getElementById(divId);
            var res = divElem.innerText.split(" ");
            var productIds = res[2].split(",");

            updateProductList(trId, currentRow.className, productIds)
        });
    });
    checkEditAccess();
}
function getData(snapshot) {

    divObj.innerHTML = ''
    count = 0
    snapshot.forEach(function (childSnapshot) {
        var rootKey = childSnapshot.key;
        var childData = childSnapshot.val();
        // console.log(d)        

        var key = Object.keys(childSnapshot.val());
        for (i in key) {
            var s = childData[key[i]].status;
            console.log(s, statusG);
            if (s == statusG) {
                console.log("x")
                count++;
                var sno = count
                var allotTime = childData[key[i]].allot_time;
                var description = childData[key[i]].description;
                var msg = childData[key[i]].message;
                var name = childData[key[i]].name;
                var sellerId = childData[key[i]].seller_id;
                var status = childData[key[i]].status;
                if (status == 0)
                    status = "Pending"
                else if (status == 1)
                    status = "Approved"
                else
                    status = "Rejected"
                var thumbnail = "<img id='thumbnail" + sellerId + "' src='" + childData[key[i]].thumbnail + "' class='thumbnail'>";
                var time = childData[key[i]].time;
                var title = childData[key[i]].title;

                var prodId = []
                var length = 0;
                for (j in childData[key[i]].product_id) {
                    length++;
                    prodId.push(childData[key[i]].product_id[j]);
                }

                var listProd = "<div id='listOfProducts" + key[i] + "'><b>Product Ids: </b>" + prodId + "</div>"
                var prodInput = "<input placeholder='Enter product id' class='prodInputBox'/><br><input class='addbtn' type='button' value='Add product'/> <input type='button' class='donebtn' value='Done'/>";

                var change = "<select id='" + key[i] + "' onchange='changeStatus(this.id, " + rootKey + ", this.value)'>" +
                        "<option> --Select-- </option>" +
                        "<option value='0'> Pending</option>" +
                        "<option value='1'> Approve</option>" +
                        "<option value='2'> Reject</option>" +
                        "</select>";

                var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                        "<td>" + sno + "</td>" +
                        "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                        "<td>" + thumbnail + "</td>" +
                        "<td>" + name + "</td>" +
                        "<td>" + sellerId + "</td>" +
                        "<td class='canEdit'>" + allotTime + "</td>" +
                        "<td>" + listProd + prodInput + "</td>" +
                        "<td>" + status + "</td>" +
                        "<td>" + change + "</td>" +
                        "<td>" + title + "</td>" +
                        "<td>" + description + "</td>" +
                        "<td>" + msg + "</td>" +
                        "<td>" + time + "</td>" +
                        "</tr>";

                divObj.innerHTML += row;
            }
        }

        $('.editbtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            //get the <td> elements of the selected row that can be edited
            var tds = $this.closest('tr').find('.canEdit').filter(function () {
                return $(this).find('.editbtn').length === 0;
            });

            if ($this.html() === 'Edit') {
                $this.html('Save');
                //make <td> elements of that row editable
                tds.prop('contenteditable', true);
                currentRow.classList.add('currRowEdit');
            } else {
                $this.html('Edit');
                tds.prop('contenteditable', false);
                currentRow.classList.remove('currRowEdit');
                var allotTime = currentRow.cells.item(5).textContent
                updateLiveStream(trId, currentRow.className, allotTime)
            }
        });

        $('.delbtn').click(function () {
            var $this = $(this);
            //get the row element of the delete button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var retVal = confirm("Do you want to remove this video?");
            //if 'ok' is clicked on the alert box
            if (retVal == true) {
                deleteVideo(trId, currentRow.className)
                currentRow.style.display = 'none';
            }
        });

        $('.addbtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var inputElem = $(currentRow).find("input")[0];
            var inputVal = inputElem.value;
            var divId = "listOfProducts" + trId;
            inputElem.value = ''
            addProduct(inputVal, divId);
        });

        $('.donebtn').click(function () {
            var $this = $(this);
            //get the row element of the edit button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);
            var userId = currentRow.className;
            var divId = "listOfProducts" + trId;
            var divElem = document.getElementById(divId);
            var res = divElem.innerText.split(" ");
            var productIds = res[2].split(",");

            updateProductList(trId, currentRow.className, productIds)
        });
    });
    checkEditAccess();
}

function errFunc(err) {
    alert("Error")
    console.log(err);
}

function checkEditAccess() {

    var userId = localStorage.getItem("userId");
    //console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(13);//.orderByKey();

    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);

        if ((!snapshot.val().edit) && (!snapshot.val().delete)) {

            var tble = document.getElementById("table");
            var row = tble.rows;

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(1);
            }

        }
        if (!snapshot.val().edit) {

            $(".editBtn").remove();
            $(".prodInputBox").remove();
            $(".doneBtn").remove();
            $(".addBtn").remove();

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(8);
            }
        }
        if (!snapshot.val().delete) {
            $(".delBtn").remove();
        }
    })
}

// On Change the current Status

function changeStatus(timeStamp, userId, newStatus) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        var oldStatus = childData.status;
        //console.log(rootKey) //same as timestamp
        var obj = {"status": newStatus, "old-status": oldStatus};
        ref.update(obj);
    })

    getFCM(timeStamp, userId, newStatus);
}
// console.log('cc')
function getFCM(timeStamp, id, s) {
    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem('userId'));
    myHeaders.append("sessionkey", sessionStorage.getItem("sessionKey"));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(getdetailsbyId+"user_id=" + id, requestOptions)
            .then(response => response.json())
            .then(result => {
                if (result.status == 200)
                    notify(timeStamp, result.userlist[0].FCM, id, s);
                else
                    alert("Could not send notification to user");
            })
            .catch(error => console.log('error', error));
}

function notify(timeStamp, fcm, id, s) {
    // console.log(fcm);
    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem('userId'));
    myHeaders.append("sessionkey", sessionStorage.getItem("sessionKey"));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var msg = '';
    switch (s) {
        case "0":
            msg = " is yet to be approved.";
            break;
        case "1":
            msg = " has been approved!";
            break;
        case "2":
            msg = " has been rejected.";
            break;
    }
    // console.log(document.getElementsByClassName(id)[0].cells[12].innerHTML)
    var notif_body = "Your live stream scheduled for " + document.getElementById(timeStamp).cells[12].innerHTML + msg;
    var notif_title = "Live Streaming";
    // console.log(notif_body);
    // console.log(notif_title);
    var formdata = new FormData();
    formdata.append("fcm_token", fcm);
    formdata.append("body_notification", notif_body);
    formdata.append("title_notification", notif_title);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";

    fetch(sendNotification, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result);
                notifyUsers(timeStamp, s, id);
                if (result.status == 200) {
                    // alert("Notification sent to zilakar user");
                } else {
                    alert("Could not send notification to zilakar user!");
                }

            })
            .catch(error => {
                console.log('error', error);
                alert("Could not send notification to zilakar user!");
            });
}
function notifyUsers(timeStamp, s, id) {
    switch (s) {
        case "0":
            break;
        case "1":
            sendNotifUser(timeStamp, id);
            break;
        case "2":
            break;
    }
}

function sendNotifUser(timeStamp, id) {
    //console.log(id);
    //console.log(timeStamp);
    var str = document.getElementById(timeStamp).cells[12].innerHTML;
    //console.log(str)
    var tokens = str.split(" ").slice(1);
    result = tokens.join(" ");
    var str1 = result.split(":").slice(0, 2);

    var time = str1.join(":");
    var notif_title = "Live streaming";
    var notif_topic = "zila";
    var notif_body = document.getElementsByClassName(id)[0].cells[3].innerHTML + " is going live at " + time + "!";
    // var notif_image = document.getElementById("notifImage");
    var notif_image = document.getElementById('thumbnail' + id).src;
    //console.log(notif_body);
    //console.log(notif_title);
    //console.log(notif_topic);
    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem('userId'));
    myHeaders.append("sessionkey", sessionStorage.getItem("sessionKey"));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    //console.log(notif_image);
    var formdata = new FormData();
    formdata.append("topic", notif_topic);
    formdata.append("body_notification", notif_body);
    formdata.append("title_notification", notif_title);
    formdata.append("image_url", notif_image);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";

    fetch(sendNotification, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                if (result.status != 200)
                    alert("Could not send notification to users");
            })
            .catch(error => {
                console.log('error', error);
                alert("Could not send notification to users");
            });


}
// console.log('hh')
function updateLiveStream(timeStamp, userId, newAllotTime) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        //console.log(rootKey) //same as timestamp
        var obj = {"allot_time": newAllotTime};
        ref.update(obj);
        //console.log(childData.allot_time);
    })
}

function addProduct(productId, divId) {
    var divElem = document.getElementById(divId);
    divElem.innerHTML += ',' + productId;
}

// On click Done Button

function updateProductList(timeStamp, userId, productIdList) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        //console.log(rootKey) //same as timestamp
        var childRef = ref.child("product_id");
        childRef.once("value", function (childSnapshot) {
            console.log(productIdList);
            var numberOfProducts = productIdList.length;
            for (var i = 1; i < numberOfProducts + 1; i++) {
                var product = "product" + i;
                var j;
                if (productIdList[0] == "") {
                    j = i;
                } else {
                    j = i - 1;
                }
                var prod = {[product]: productIdList[j]};
                childRef.update(prod);
            }
        })
        alert("Product list updated");
        /*
         functions.childRef.onUpdate(event => {
         console.log("Added product list");
         console.log(event.data.val());
         })
         */
    })
}

function deleteVideo(timeStamp, userId) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.remove();
    alert("Video deleted");
}