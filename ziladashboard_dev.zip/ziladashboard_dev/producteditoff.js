var searchproduct = localStorage.getItem("searchproduct");
var updatediscount = localStorage.getItem("updatediscount");


function getpid() {
    $('#producttableBody').empty();
    document.getElementById("ptable").style.display = "block";
    var value = document.getElementById("pname").value;
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "2");
    myHeaders.append("user_type", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Cookie", "ci_session=pk1mtoors8tjkhh6rlq368a4etjh7cjv");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    var table = document.getElementById("producttableBody");
    fetch(searchproduct + value + "&page=0", requestOptions)
            .then(response => response.json())
            .then(result => {
                var myList = result.data;
                for (var i = 0; i < myList.length; i++) {
                    var sno = i + 1;
                    var row = "<tr id='" + myList[i].product_id + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td>" + myList[i].product_id + "</td>" +
                            "<td>" + myList[i].name + "</td>" +
                            "</tr>";
                    table.innerHTML += row;
                }
            })
            .catch(error => console.log('error', error));
}

function pidisedit() {
    var pid = document.getElementById("pid").value;
    var pdiss = document.getElementById("pdiss").value;

    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("product_id", pid);
    urlencoded.append("discount", pdiss);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    fetch(updatediscount, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result.status);
                if (result.status == 206) {
                    alert("Product already attached to product offer");
                    location.reload();
                } else if (result.status == 200) {
                    alert("Offer Added");
                    location.reload();
                } else if (result.status == 207) {
                    alert("Product already attached to Daily Offer");
                    location.reload();
                } else if (result.status == 208) {
                    alert("Product already attached to Weekly Offer");
                    location.reload();
                } else if (result.status == 209) {
                    alert("Product already attached to buy one get one offer");
                    location.reload();
                }
            })
}