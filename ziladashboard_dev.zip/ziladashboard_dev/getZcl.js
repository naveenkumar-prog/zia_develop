var getUsers = localStorage.getItem("getUsers");

console.log("getUsers:",getUsers);

var users = []
var id = 5

// const proxyurl = "https://cors-anywhere.herokuapp.com/";
const getUserUrl = getUsers+"user_type_id=";

var myHeaders = new Headers();
myHeaders.append("userid", "1784");
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("languagetype", "1");
myHeaders.append("usertype", "0");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

var state = {
    'querySet': users,

    'page': 1,
    'rows': 20,
    'window': 5,
}

buildTable(id);

function pagination(querySet, page, rows) {

    var trimStart = (page - 1) * rows
    var trimEnd = trimStart + rows

    var trimmedData = querySet.slice(trimStart, trimEnd)

    var pages = Math.ceil(querySet.length / rows);
    //console.log(pages)

    return {
        'querySet': trimmedData,
        'pages': pages,
    }
}

function pageButtons(pages) {
    var wrapper = document.getElementById('pagination-wrapper')

    wrapper.innerHTML = ``
    //console.log('Pages:', pages)

    var maxLeft = (state.page - Math.floor(state.window / 2))
    var maxRight = (state.page + Math.floor(state.window / 2))

    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = state.window
    }

    if (maxRight > pages) {
        maxLeft = pages - (state.window - 1)

        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = pages
    }

    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += `<button value=${page} class="page btn btn-sm btn-info">${page}</button>`
    }

    if (state.page != 1) {
        wrapper.innerHTML = `<button value=${1} class="page btn btn-sm btn-info">&#171; First</button>` + wrapper.innerHTML
    }

    if (state.page != pages) {
        wrapper.innerHTML += `<button value=${pages} class="page btn btn-sm btn-info">Last &#187;</button>`
    }

    $('.page').on('click', function () {
        //$('#table-body').empty()

        state.page = Number($(this).val())

        buildTable(id)
    })
}

function buildTable(id) {
    document.getElementById("tableBody").innerHTML = ''
    fetch(getUserUrl + id, requestOptions)
            .then(response => response.json())
            .then(result => {
                users = result.data
                state.querySet = result.data
                //console.log(state.querySet)
                var tab = document.getElementById("tableBody")
                tab.innerHTML = ''
                var res = pagination(state.querySet, state.page, state.rows)
                var myList = res.querySet
                for (var i = 0; i < myList.length; i++) {
                    var sno = i + 1
                    var row = "<tr id='" + myList[i].userId + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td>" + myList[i].name + "</td>" +
                            "<td>" + myList[i].userId + "</td>" +
                            "<td>" + myList[i].username + "</td>" +
                            "<td>" + myList[i].email + "</td>" +
                            "<td>" + myList[i].wallet_balance + "</td>" +
                            "<td>" + myList[i].primary_address + "</td>" +
                            "<td><button class='viewDetails'><span>View</span></button></td>" +
                            "<td>" + myList[i].deviceType + "</td>" +
                            "<td>" + myList[i].createdOn + "</td>" +
                            "<td>" + myList[i].updatedOn + "</td>" +
                            "<td>" + myList[i].lang + "</td>" +
                            "<td>" + myList[i].isactive + "</td>" +
                            "</tr>";

                    tab.innerHTML += row;
                }
                pageButtons(res.pages)

                $('.viewDetails').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    //console.log(currentRow)
                    localStorage.setItem("zclid", trId);
                    localStorage.setItem("zclName", currentRow.cells.item(1).textContent);
                    location.href = 'getZclDetails.html';
                    //console.log(localStorage.getItem("zclid"));
                    //console.log(localStorage.getItem("zclName"));
                });

            })
            .catch(error => console.log('error', error));
}
