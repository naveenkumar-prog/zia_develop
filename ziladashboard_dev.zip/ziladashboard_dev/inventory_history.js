
var Inventory = localStorage.getItem("Inventory");



// Function for the Table

buildTable() 
function buildTable() {

var myHeaders = new Headers();
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("usertype", "0");
myHeaders.append("userid", "1784");
myHeaders.append("languagetype", "1");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
myHeaders.append("Content-Type","application/x-www-form-urlencoded");
var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    redirect: 'follow'

};

    console.log("buildTable enters");

console.log("Inventory",Inventory)
    fetch(Inventory+"operation=2", requestOptions)
    .then(response => response.json())
    .then(result => {
                console.log('result',result);
                document.getElementById("loader").style.display = "none";
                myList = result.data;
               // state.querySet = products;
                console.log("threshold",myList[0].threshold)
                var table = document.getElementById("myTable")
                table.innerHTML = ''

              //  var res = pagination(state.querySet, state.page, state.rows)
              //  var myList = res.querySet
                console.log("myList");
                console.log('myList',myList)

                for (var i = 0; i < myList.length; i++)
                {
                    var j = i+1 
                     var row = "<tr id=" + myList[i].inventory_id + ">" +
                           "<td>" + j + "</td>" +
                            "<td>" + myList[i].product_id + "</td>" +
                            "<td>" + myList[i].inventory_id + "</td>" +
                            "<td>" + myList[i].seller_name + "</td>" +
                            "<td>" + myList[i].seller_mobile + "</td>" +
                            "<td>" + myList[i].seller_address + "</td>" +
                            "<td>" + myList[i].created_on + "</td>" +
                            "<td>" + myList[i].quantity + "</td>" +
                            "<td>" + myList[i].quantity_unit + "</td>" +
                            "<td>" + myList[i].seller_price_per_unit + "</td>" +
                            "<td>" + myList[i].cgst + "</td>" +
                            "<td>" + myList[i].sgst + "</td>" +
                            "<td>" + myList[i].igst + "</td>" +
                            "<td>" + myList[i].total_amount + "</td>" +
                            "<td>" + myList[i].zila_mrp + "</td>" +
                            "<td>" + myList[i].zila_offer + "</td>" +
                            "<td>" + myList[i].cp_commission + "</td>" +
                            "<td>" + myList[i].threshhold + "</td>" +
                            "</tr>";
                    table.innerHTML += row;
                    //mainContainer.appendChild(row);
                }



            })
            .catch(error => console.log('error', error));

}

