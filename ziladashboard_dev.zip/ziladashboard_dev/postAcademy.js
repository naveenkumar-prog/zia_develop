// OnClick Add Video Button

var postAcademy = localStorage.getItem("postAcademy");

function getData() {

    var vidCode = document.getElementById("videoCode").value;
    var appNumber = document.getElementById("appNo").value;
    var isActive, flag = 0;
    var ele = document.getElementsByName("active");
    if (ele[0].checked) {           // if ele is 0 then isActive ==0
        isActive = ele[0].value;
    } else if (ele[1].checked) {   // else isActive ==1
        isActive = ele[1].value;
    } else {
        flag = 1;
    }
    var title = document.getElementById("videoTitle").value;

    if (vidCode == "" || appNumber == 0 || flag == 1 || title == "") {
        alert("Please fill in all the fields!");
    } else {
        postAcademy(vidCode, appNumber, isActive, title)   // Redirect to the function
    }
}

function postAcademy(videoCode, appNo, isActive, videoTitle) {

    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("video_code", videoCode);
    urlencoded.append("app_no", appNo);
    urlencoded.append("isActive", isActive);
    urlencoded.append("video_title", videoTitle);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
    const postAcademyUrl = postAcademy;

    fetch(postAcademyUrl, requestOptions)
            .then(response => response.json())
            .then(result => {
                alert("New video added");
                window.location.reload();
            })
            .catch(error => {
                console.log('error', error);
                alert("Could not add new video!");
            });
}