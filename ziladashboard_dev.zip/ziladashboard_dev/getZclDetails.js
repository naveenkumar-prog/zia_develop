var zclCustomer = localStorage.getItem("zclCustomer");
console.log("zclcustomer",zclCustomer);
var getOrderlist = localStorage.getItem("getOrderlist");
var updateStatus = localStorage.getItem("updateStatus");
var getdetailsbyId = localStorage.getItem("getdetailsbyId"); 
var getTask = localStorage.getItem("getTask");
var updateTask = localStorage.getItem("updateTask");
var pageNum = 0;

var searchPageNum = 0;


var zclName = localStorage.getItem("zclPartName");
var zclId = localStorage.getItem("zclid");
document.getElementById("zclName").innerHTML = "<b>" + zclName + "</b><br> (User Id: " + zclId + ")";
//document.getElementById("zcltb_name").innerHTML = zclName;
document.getElementById("pd_name").innerHTML = zclName;
// const proxyurl = "https://cors-anywhere.herokuapp.com/";

var myHeaders = new Headers();
myHeaders.append("userid", "25");
myHeaders.append("sessionkey", "a2ed9c4adb38820e98d7f511962e2372");
myHeaders.append("languagetype", "2");
myHeaders.append("usertype", "3");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");


var urlencoded = new URLSearchParams();
urlencoded.append("zcl_id", zclId);



var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: urlencoded,
    redirect: 'follow'
};
document.getElementById('popup').style.display = 'none';


fetch(zclCustomer+"operation=6", requestOptions)

        .then(response => response.json())
        .then(result => {
            console.log("before res");
            console.log("zcl customers res:",result);
        //    console.log(result.data.length);
            //     console.log(result.partnerDetails.aadhar_image_front);
            //   console.log(result.data[1].user_name);
            //   console.log(result.data[1].order_on);

            //     console.log("'"+result.partnerDetails.address[0].image+"'");
            var earning = result.analytics.earnings;
            document.getElementById("cd2_hd1").innerHTML += parseFloat(earning).toFixed(2);

            document.getElementById("cd2_hd2").innerHTML += result.analytics.orders;
            var sales = result.analytics.sales;

            // console.log(parseFloat(sales));
            // console.log(parseFloat(sales).toFixed(2));
            document.getElementById("cd2_hd3").innerHTML += parseFloat(sales).toFixed(2);
            document.getElementById("cd2_hd4").innerHTML += result.analytics.products;

            document.getElementById("pancard").innerHTML += result.partnerDetails.pancard;
            document.getElementById("aadhar_card").innerHTML += result.partnerDetails.aadhar_card;

            document.getElementById("cd2_hd5").innerHTML += result.analytics.customers;
            document.getElementById("cty").innerHTML += result.partnerDetails.address[0].city;
            document.getElementById("st").innerHTML += result.partnerDetails.address[0].state;

            if (result.partnerDetails.aadhar_image_front != 0)
            {
                var tab1 = document.getElementById("img_fid");

                var img = "<img src='" + result.partnerDetails.address[0].image + "' height='150px' weight='150px'>"

                tab1.innerHTML += img;
            } else
            {
                document.getElementById("img_fid").innerHTML += "Front image is not available";


            }

            if (result.partnerDetails.aadhar_image_back == 0)
            {
                document.getElementById("img_lid").innerHTML += "Back image is not available";
            } else
            {


                var tab2 = document.getElementById("img_lid");

                var img2 = "<img src='" + result.partnerDetails.address[0].image + "' height='150px' weight='150px'>"

                tab2.innerHTML += img2;
            }

            if (result.partnerDetails.pan_image == 0)
            {
                document.getElementById("img_pid").innerHTML += "PAN image is not available";
            } else
            {

                var tab3 = document.getElementById("img_pid");

                var img3 = "<img src='" + result.partnerDetails.pan_image + "' height='150px' weight='150px'>"

                tab3.innerHTML += img3;
            }


            document.getElementById("address").innerHTML += result.partnerDetails.address[0].address + " " + result.partnerDetails.address[0].city + " " + result.partnerDetails.address[0].state + " " + result.partnerDetails.address[0].pincode;
            document.getElementById("long_no").innerHTML += result.partnerDetails.address[0].longitude;
            document.getElementById("ph_no").innerHTML += result.partnerDetails.address[0].phone;
            document.getElementById("lat_no").innerHTML += result.partnerDetails.address[0].latitude;
            document.getElementById("gstn").innerHTML += result.partnerDetails.address[0].gstn_no;
            document.getElementById("add").innerHTML += result.partnerDetails.address[0].user_address_id;
            //        document.getElementById("cd").innerHTML += result.data[0].user_name ;

            if (result.data.length >= 1)
            {
                for (var i = 0; i < result.data.length; i++) {
                    var sno = i + 1;
                    var tr = "<tr>" +
                            "<td>" + result.data[i].user_name + "</td>" +
                            "<td>" + result.data[i].order_on + "</td>" +
                            "<td>" + result.data[i].user_mobile + "</td>"+
                            "<td>" + result.data[i].user_order + "</td>" +
                            "</tr>";

                    document.getElementById("cd").innerHTML += tr;
                }


            } else
            {
                document.getElementById("cd").innerHTML += "<br>  No Customers available";
            }
        })
        .catch(error => console.log('error', error));


var searchpageNum = 0;

// To display page buttoms according to the search

function searchpageButtons(numTask, tasks) {
    var wrapper = document.getElementById('pagination-wrapper')
    wrapper.innerHTML = ''
    var maxLeft = (searchpageNum - 2)
    var maxRight = (searchpageNum + 2)
    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = 5
    }
    var numberOfPages = Math.ceil(numTask / 10);
    totalPages = numberOfPages;
    if (maxRight > numberOfPages) {
        maxLeft = numberOfPages - 5
        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = numberOfPages
    }
    var wrapper = document.getElementById("pagination-wrapper");
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += "<button value='" + page + "' class='page btn btn-sm btn-info'>" + page + "</button>"
    }
    if (searchpageNum != 0) {
        wrapper.innerHTML = "<button value='1' class='page btn btn-sm btn-info'>&#171; First</button>" + wrapper.innerHTML
    }
    if (searchpageNum != numberOfPages) {
        wrapper.innerHTML += "<button value='" + numberOfPages + "' class='page btn btn-sm btn-info'>Last &#187;</button>"
    }
    $('.page').on('click', function () {
        $('#tableBody').empty()
        searchpageNum = Number($(this).val()) - 1
        fetchData(id, tasks);
    })
}

const getTaskUrl = getTask+"store_id=";


function changeStatus(status, storeTaskId) {
    //console.log(status, storeTaskId)
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    var urlencoded = new URLSearchParams();
    urlencoded.append("status", status);
    urlencoded.append("store_task_id", storeTaskId);
    urlencoded.append("task_date", "2020-05-31 00:00:00");
    urlencoded.append("close_order_time", "2020-05-31 00:00:00");
    urlencoded.append("cancel_reason", "");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };
    fetch(updateTask, requestOptions)
            .then(response => response.text())
            .then(result => {
                console.log(result)
                //$("#tableBody").load(" #tableBody > *");
                searchButton()
            })
            .catch(error => console.log('error', error));
}

function searchButton() {
    
    fetchData(zclId)
}
// To fetch the details from api

function getdetails(order_id) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };
    fetch(getOrderlist+"order_id=" + order_id, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                displayDetails(result.data);
            })
            .catch(error => console.log('error', error));
}

// To display details

function displayDetails(orders)
{
    document.getElementById('popup').style.display = 'block';
//    document.getElementById('tasksContent').style.display='none'
    //var elem = document.getElementById('data');
    var tab = document.getElementById("orderDetailsTable");
    tab.innerHTML = '';

    for (var i = 0; i < orders.length; i++) {
        var sno = i + 1;
        var tr = "<tr>" +
                "<td>" + sno + "</td>" +
                "<td>" + orders[i].name + "</td>" +
                "<td><img src='" + orders[i].image + "' class='orderImage'></td>" +
                "<td>" + orders[i].order_no + "</td>" +
                "<td>" + orders[i].product_id + "</td>" +
                "<td>" + orders[i].actual_amount + "</td>" +
                "<td>" + orders[i].offer_amount + "</td>" +
                "<td>" + orders[i].quantity + "</td>" +
                "</tr>";

        tab.innerHTML += tr;
    }
    document.getElementById('popup').classList.add('stick');
    document.getElementById("tasksContent").classList.add("hideOverflow");
}

fetchData(zclId);

// To fetch data according to search

function fetchData(zclId, tasks) {
   
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };
    fetch(getTask+"store_id=" + zclId + "&page=" + searchpageNum, requestOptions)
            .then(response => response.json())
            .then(result => {
                tasks = result.data
                if (tasks.length == 0) {
                    alert("No tasks!");
                } else {
                    document.getElementById("store-name").innerHTML = "Store name: " + tasks[0].store_name;
                }
                var tab = document.getElementById("tableBody")
                tab.innerHTML = ''
                for (var i = 0; i < tasks.length; i++) {
                    if (tasks[i].payment_method == 1)
                        payMethod = "Cash"
                    else
                        payMethod = "Online"
                    if (tasks[i].mode == 1)
                        modeDel = "Delivery"
                    else
                        modeDel = "Pickup"
                    var status
                    if (tasks[i].status == 1) {
                        status = "Delivered"
                    } else if (tasks[i].status == 2) {
                        status = "In-transit"
                    } else if (tasks[i].status == 3) {
                        status = "Pending"
                    } else if (tasks[i].status == 4) {
                        status = "Cancelled"
                    } else if (tasks[i].status == 5) {
                        status = "To-deliver"
                    }
                    var sno = i + 1
                    var shipDetails = "<b>Address:</b> " + tasks[i].address + "<br><b>Name:</b> " + tasks[i].name + "<br><b>Payment method:</b> " + payMethod + "<br><b>User id:</b> " + tasks[i].user_id;

                    var change = "<select onchange=\"changeStatus(this.value,'" + tasks[i].store_task_id + "')\">" +
                            "<option value='select'>--Select--</option>" +
                            "<option value='1'>Delivered</option>" +
                            "<option value='2'>In-transit</option>" +
                            "<option value='3'>Pending</option>" +
                            "<option value='4'>Cancel</option>" +
                            "<option value='5'>To deliver</option>" +
                            "</select>"
                    var row = "<tr id='" + tasks[i].order_id + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td>" + tasks[i].task_date + "</td>" +
                            "<td><img src='" + tasks[i].image + "' class='taskImage'></td>" +
                            "<td>" + tasks[i].order_id + "</td>" +
                            
                            "<td>" + status + "</td>" +
                            "<td>" + change + "</td>" +
                            "<td>" + shipDetails + "</td>" +
                            "<td><button class='viewDetails'><span>View</span></button></td>" +
                            "<td>" + modeDel + "</td>" +
                            "<td>" + tasks[i].total_amount + "<br><b>Final amount: </b>" + tasks[i].final_amount + "<br><b>To pay: </b>" + tasks[i].topay + "<br><b>Wallet bal used: </b>" + tasks[i].wallet_bal_used + "</td>" +
                            "<td>" + tasks[i].commision + "</td>" +
                            "<td>" + tasks[i].close_order_time + "</td>" +
                            //"<td><button class='btn btn-info downloadBtn' data-topay='"+tasks[i].topay+"' data-wallet='"+tasks[i].wallet_bal_used+"'>Download</button></td>"+
                            "<td><button class='btn btn-info veiwInvoice' data-topay='" + tasks[i].topay + "' data-wallet='" + tasks[i].wallet_bal_used + "'>View Invoice</button></td>" +
                            "</tr>";
                    tab.innerHTML += row;
                }
                $('.viewDetails').click(function () {
                    var $this = $(this);
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    getdetails(trId);
                });
                $('.veiwInvoice').click(function () {
                    var $this = $(this);
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    var orderids = currentRow.cells.item(3).innerHTML;
                    var storeName = currentRow.cells.item(4).textContent;
                    var storeLocation = currentRow.cells.item(5).textContent;
                    var wallet_balance_used = $(this).attr("data-wallet");
                    var topay = $(this).attr("data-topay");
                    localStorage.setItem("Order_Id", orderids);
                    localStorage.setItem("Store_Name", storeName);
                    localStorage.setItem("Store_Location", storeLocation);
                    localStorage.setItem("Wallet_balance", wallet_balance_used);
                    localStorage.setItem("Grand_Total", topay);
                    console.log("Order_id " + orderids);
                    console.log("Store_Name " + storeName);
                    console.log("Store_Location " + storeLocation);
                    console.log("Wallet_balance " + wallet_balance_used);
                    console.log("Grand_Total " + topay);
                    getOrderinfos();
                })
                // $('.downloadBtn').click(function(){
                //     var $this = $(this);
                //     var trId = $(this).closest('tr').prop('id');
                //     var currentRow = document.getElementById(trId);
                //     var storeName = currentRow.cells.item(4).textContent;
                //     var storeLocation = currentRow.cells.item(5).textContent;
                //     var wallet_balance_used = $(this).attr("data-wallet");
                //     var topay = $(this).attr("data-topay");
                //     //console.log(wallet_balance_used, topay);
                //     getOrderDetails(trId,storeName,storeLocation, topay, wallet_balance_used);          
                // });
                //checkEditAccess();
            })
            .catch(error => console.log('error1', error));
}

function checkEditAccess() {
    var userId = localStorage.getItem("userId");
    console.log(userId);
    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(17);//.orderByKey();
    userDataRef.on("value", function (snapshot) {
        //console.log(snapshot.val().view);
        var tble = document.getElementById("table");
        var row = tble.rows;
        if (!snapshot.val().edit) {
            for (var j = 0; j < row.length; j++) {
                // Deleting the "change-status" cell of each row. 
                row[j].deleteCell(7);
            }
        }
    })
}

function changeDisplay() {
    document.getElementById('popup').classList.remove('stick');
    document.getElementById("tasksContent").classList.remove('hideOverflow');
    document.getElementById('popup').style.display = 'none';
}

function getOrderinfos() {
    window.open("getOrderInfo.html", "_blank");
}