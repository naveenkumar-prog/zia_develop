var transactionList = localStorage.getItem("transactionList");
var referralCount = localStorage.getItem("referralCount");

console.log("referralCount",referralCount);
console.log("transactionList",transactionList);

let userId = sessionStorage.getItem("wUserId");
let sessionkey = sessionStorage.getItem("wSessionkey");
let user_type = sessionStorage.getItem("wUserType");
document.getElementById("userIdSpan").innerHTML = userId;
var myHeaders = new Headers();
myHeaders.append("userid", userId);
myHeaders.append("sessionkey", sessionkey);
myHeaders.append("languagetype", "1");
myHeaders.append("user_type", user_type);
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
myHeaders.append("Cookie", "ci_session=m1b6i7pgl1f3cv7s1iogt5l0erg3n4sf");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

// const proxyUrl = "https://cors-anywhere.herokuapp.com/";
const url = transactionList;

fetch(url, requestOptions)
        .then(response => response.json())
        .then(result => {
            document.getElementById("overlay").style.display = "none";
            if (result.status == 200)
            {
                // console.log(result);
                var data = result.data;
                var table = document.getElementById("myTable");
                let transaction_type, amt;
                for (i = 0; i < data.length; i++) {
                    if (data[i].credit_amt == 0) {
                        transaction_type = "Debit";
                        amt = data[i].debit_amt;
                    } else if (data[i].debit_amt == 0) {
                        transaction_type = "Credit";
                        amt = data[i].credit_amt;
                    }
                    var row = "<tr>" +
                            "<td>" + data[i].wallet_transaction_id + "</td>" +
                            "<td>" + data[i].last_amount + "</td>" +
                            "<td>" + transaction_type + "</td>" +
                            "<td>" + amt + "</td>" +
                            "<td>" + data[i].cur_amount + "</td>" +
                            "<td>" + data[i].order_id + "</td>" +
                            "<td>" + data[i].money_type + "</td>" +
                            "<td>" + data[i].transaction_date + "</td>" +
                            "</td>";
                    table.innerHTML += row;
                }
                getReferrals();
            } else if (result.status == 400) {
                //   console.log(result);
                alert("No data to fetch");
            } else {
                alert("Could not fetch data");
            }
        })
        .catch(error => console.log('error', error));

function getReferrals() {
    var myHeaders = new Headers();
    myHeaders.append("userid", userId);
    myHeaders.append("sessionkey", sessionkey);
    myHeaders.append("languagetype", "1");
    myHeaders.append("user_type", user_type);
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Cookie", "ci_session=2hhtlasgjq8hu00d3jr38j4paovhjlb5");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(referralCount, requestOptions)
            .then(response => response.json())
            .then(result => {
                // console.log(result);
                document.getElementById('ref').innerHTML = result.data[0].count;
                document.getElementById('bal').innerHTML = result.data[0].wallet_balance;
                document.getElementById('earn').innerHTML = result.data[0].total_earn;
                document.getElementById('dbt').innerHTML = result.data[0].total_dbt;
            })
            .catch(error => console.log('error', error));
}