var signin = localStorage.getItem("signIn");

console.log("signin",signin);

var user_type;
console.log('x')
var config = {
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-activities.firebaseapp.com",
    databaseURL: "https://zila-android-activities.firebaseio.com",
    storageBucket: "zila-android-activities.appspot.com"
};
firebase.initializeApp(config);

function checkVerification(data) {
    var password = document.getElementById("InputPassword1").value;
    var email = document.getElementById("InputEmail1").value;
    // var emailExists = firebase.auth().getUserByEmail(email).then(() => true).catch(() => false));
    firebase.auth().signInWithEmailAndPassword(email, password)
            .then(function () {
                var user = firebase.auth().currentUser;
                if (user.emailVerified) {
                    gotoDashboard(data)
                } else {
                    alert("Please verify your email")
                    document.getElementById("overlay").style.display = "none";
                }
            })
            .catch(function (error) {
                // Handle Errors here.
                var errorCode = error.code;
                var errorMessage = error.message;
                if (errorCode == "auth/user-not-found") {
                    firebase.auth().createUserWithEmailAndPassword(email, password).then(function (user) {
                        console.log("okay");
                        var user = firebase.auth().currentUser;

                        user.sendEmailVerification().then(function () {
                            alert("A verification link has been sent to your email account. Please verify your email ID to login.");
                            location.reload();
                        })
                                .catch(function (error) {
                                    var errorCode = error.code;
                                    if (errorCode == 'auth/weak-password') {
                                        alert('The password is too weak.');
                                        document.getElementById("overlay").style.display = "none";
                                    } else {
                                        alert('Error');
                                        document.getElementById("overlay").style.display = "none";
                                    }
                                    var errorMessage = error.message;
                                    console.log(errorMessage);
                                    // ...
                                });
                    }).catch(function (error) {
                        var errorCode = error.code;
                        if (errorCode == 'auth/weak-password') {
                            alert('The password is too weak.');
                            document.getElementById("overlay").style.display = "none";
                        } else {
                            alert('Error');
                            document.getElementById("overlay").style.display = "none";
                        }
                        var errorMessage = error.message;
                        console.log(errorMessage);
                        // ...
                    });
                } else {
                    alert(errorMessage);
                }
            })
}

function gotoDashboard(details) {
    var numExpiryDays = 30
    var d = new Date();
    d.setTime(d.getTime() + (numExpiryDays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = "zilaName=" + details.name + ";" + expires + ";path=/";

    //console.log(document.cookie);

    sessionStorage.setItem("name", details.name);
    sessionStorage.setItem("email", details.email);
    sessionStorage.setItem("user_type", user_type);
    // console.log(details);
    // console.log(details.user_type);
    sessionStorage.setItem("sessionKey", details.sessionKey);
    localStorage.setItem("userId", details.userId);
    localStorage.setItem("username", details.username);
    //console.log("Name ", details.name, "Email ", details.email, "Userid ", details.userId, "username ", details.username) 
    document.getElementById("overlay").style.display = "none";
    location.href = "dashboard";
    //console.log("Name ", sessionStorage.getItem("name"), "Email ", sessionStorage.getItem("email"), "Userid ", localStorage.getItem("userId"),"username ", localStorage.getItem("username"))
}

function getRadioVal(form, name) {
    var val;
    // get list of radio buttons with specified name
    var radios = form.elements[name];

    // loop through list of radio buttons
    for (var i = 0, len = radios.length; i < len; i++) {
        if (radios[i].checked) { // radio checked?
            val = radios[i].value; // if so, hold its value in val
            break; // and break out of for loop
        }
    }
    return val; // return value of checked radio or undefined if none checked
}

function signIn() {
    // the json data. (you can change the values for output.)
    // var adminLoginCheckbox = document.getElementById("adminLoginCheck");
    // if(adminLoginCheckbox.checked){
    //     user_type = 0;
    // } else{
    //     user_type = 4;
    // }
    document.getElementById("overlay").style.display = "block";
    var user_typeString = getRadioVal(document.getElementById('form'), 'userType');
    user_type = parseInt(user_typeString, 10);
    // alert(user_type);
    // var user_type = $('input[name="name_of_your_radiobutton"]:checked').val();
    // console.log(user_type);
    var myHeaders = new Headers();
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var password = document.getElementById("InputPassword1").value;
    var email = document.getElementById("InputEmail1").value;

    var urlencoded = new URLSearchParams();
    urlencoded.append("usertype", user_type);
    urlencoded.append("password", password);
    urlencoded.append("email", email);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    }

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
    const url = signin;

    fetch(url, requestOptions)
            .then(response => {
                return response.json()
            })
            .then(result => {
                // Work with JSON data here
                if (result.status == 200) {
                    gotoDashboard(result.data);
                    // console.log(result.data);
                    // checkVerification(result.data)
                } else {
                    console.log(result)
                    document.getElementById("overlay").style.display = "none";
                    document.getElementById("err").innerHTML = "Incorrect email or password!!";
                }
            })
            .catch(error => {
                // Do something for an error here
                console.log("error", error)
            })
}

function showPass() {
    var x = document.getElementById("InputPassword1");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}