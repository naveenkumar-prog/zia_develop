var addNotification = localStorage.getItem("addNotification");
var updateNotification = localStorage.getItem("updateNotification");
var sendNotification = localStorage.getItem("sendNotification");

console.log("sendNotification",sendNotification);
console.log("addNotification:",addNotification);
console.log("updateNotification:",updateNotification);

var notifications = []
// const proxyurl = "https://cors-anywhere.herokuapp.com/";

var myHeaders = new Headers();
myHeaders.append("userid", "1784");
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("languagetype", "1");
myHeaders.append("usertype", "0");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var formdata = new FormData();
formdata.append("notification_id", "0");
/*
 formdata.append("image", fileInput.files[0], "Screenshot from 2020-06-15 16-51-16.png");
 formdata.append("topic", "topic");
 formdata.append("title", "title");
 formdata.append("description", "des");
 */
var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: formdata,
    redirect: 'follow'
};

fetch(addNotification, requestOptions)
        .then(response => response.json())
        .then(result => {
            notifications = result.databean
            buildTable(notifications)
        })
        .catch(error => console.log('error', error));

// To Update the edited data in database

function updateNotif(img, title, topic, desc, notif_id, isUpdateImage) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formdata = new FormData();
    if (isUpdateImage)
        formdata.append("image", img);
    formdata.append("topic", topic);
    formdata.append("title", title);
    formdata.append("notification_id", notif_id);
    formdata.append("description", desc);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    fetch(updateNotification, requestOptions)
            .then(response => response.json())
            .then(result => {
                alert("Notification updated");
            })
            .catch(error => {
                console.log('error', error)
                alert("Error updating notification!");
            });
}

function deleteNotif(notif_id) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formdata = new FormData();
    formdata.append("notification_id", notif_id);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    fetch(updateNotification, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                alert("Notification deleted");
                document.getElementById(notif_id).style.display = "none";
            })
            .catch(error => {
                console.log('error', error);
                alert("Error deleting notification!");
            });
}

// To display the result as a table

function buildTable(data) {
    var table = document.getElementById("myTable");
    table.innerHTML = '';

    for (var i = 0; i < data.length; i++) {
        var sno = i + 1;
        //console.log("URL " +data[i].image);
        var row = "<tr id='" + data[i].notification_id + "'>" +
                "<td>" + sno + "</td>" +
                "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                "<td>" + data[i].notification_id + "</td>" +
                "<td><img src='" + data[i].image + "' class='notifImage'></td>" +
                "<td class='canEdit'>" + data[i].tittle + "</td>" +
                "<td class='canEdit'>" + data[i].topic + "</td>" +
                "<td class='canEdit'>" + data[i].description + "</td>" +
                "<td class='canEdit'>" + data[i].image + "</td>" +
                "<td><button class='sendbtn m-5 btn btn-primary btn-small'>Send Notification</button>" +
                "</tr>";

        table.innerHTML += row;
    }

    // onclick send Button

    $('.sendbtn').click(function () {
        var $this = $(this);
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);
        var tds = $this.closest('tr').find('.canEdit').filter(function () {
            return $(this).find('.editbtn').length === 0;
        });

        var title = currentRow.cells.item(4).textContent;
        sessionStorage.setItem("Title", title);

        var topic = currentRow.cells.item(5).textContent;
        sessionStorage.setItem("Topic", topic);

        var desc = currentRow.cells.item(6).textContent;
        sessionStorage.setItem("Desc", desc);

        var imgurl = currentRow.cells.item(7).textContent;
        sessionStorage.setItem("Imag_Url", imgurl);

        sendNotifications();
    });

    $('.editbtn').click(function () {
        var $this = $(this);
        //get the row element of the edit button
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);

        //get the <td> elements of the selected row that can be edited
        var tds = $this.closest('tr').find('.canEdit').filter(function () {
            return $(this).find('.editbtn').length === 0;
        });

        if ($this.html() === 'Edit') {
            $this.html('Save');
            tds.prop('contenteditable', true);
            currentRow.classList.add('currRowEdit');
        } else {
            $this.html('Edit');
            tds.prop('contenteditable', false);
            currentRow.classList.remove('currRowEdit');

            var img = 0
            var title = currentRow.cells.item(4).textContent
            var topic = currentRow.cells.item(5).textContent
            var desc = currentRow.cells.item(6).textContent
            var isUpdateImage = false

            updateNotif(img, title, topic, desc, trId, isUpdateImage)
        }
    });

    $('.delbtn').click(function () {
        var $this = $(this);
        //get the row element of the delete button
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);

        var retVal = confirm("Do you want to delete this notification?");
        if (retVal == true) {
            deleteNotif(trId)
        }
    });

    checkEditAccess();
}


function checkEditAccess() {

    var userId = localStorage.getItem("userId");
    console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(25);//.orderByKey();

    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);

        var tble = document.getElementById("table-1");
        var row = tble.rows;

        if ((!snapshot.val().edit) && (!snapshot.val().delete)) {

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(1);
            }
        }
        if (!snapshot.val().edit) {
            $(".editbtn").remove();
        }
        if (!snapshot.val().delete) {
            $(".delbtn").remove();
        }
    })
}

// To send the notification

function sendNotifications() {
    var notif_title = sessionStorage.getItem("Title");
    var notif_topic = sessionStorage.getItem("Topic");
    var notif_body = sessionStorage.getItem("Desc");
    var notif_image = sessionStorage.getItem("Imag_Url");

    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formdata = new FormData();
    formdata.append("topic", notif_topic);
    formdata.append("body_notification", notif_body);
    formdata.append("title_notification", notif_title);
    formdata.append("image_url", notif_image);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    fetch(sendNotification, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                alert("Notification sent");
            })
            .catch(error => {
                console.log('error', error);
                alert("Could not send notification!");
            });
}