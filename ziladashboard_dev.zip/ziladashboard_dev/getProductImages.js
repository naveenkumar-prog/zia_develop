// To fetch firebase data

var getimage = localStorage.getItem("getimage");

console.log("getimage",getimage);

var productimageCon = firebase.initializeApp({
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-productimage.firebaseapp.com",
    databaseURL: "https://zila-android-productimage.firebaseio.com/",
    //projectId: "zila-android",
    storageBucket: "zila-android-productimage.appspot.com",
    //messagingSenderId: "628597092757",
    //appId: "1:628597092757:android:8b4de02ddb17655c8d869c",
}, 'getProductImages');

var userDataRef = productimageCon.database().ref();

const divObj = document.getElementById("myTable");

var allData = {};
var userDataRef = productimageCon.database().ref();//.orderByKey();
var count = 0;
userDataRef.on("value", function (snapshot) {
    divObj.innerHTML = ''
    count = 0
    snapshot.forEach(function (childSnapshot) {
        var rootKey = childSnapshot.key;
        var childData = childSnapshot.val();
        var x = 0;
        var key = Object.keys(childSnapshot.val());
        for (i in key) {
            // x++;
            count++;
            var sno = count
            var productId = childData[key[i]].product_id;
            var sellerId = childData[key[i]].seller_id;
            var sellerName = childData[key[i]].seller_name;
            var timestamp = childData[key[i]].timestamp;

            var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                    "<td>" + sno + "</td>" +
                    "<td>" + productId + "</td>" +
                    "<td>" + sellerId + "</td>" +
                    "<td>" + sellerName + "</td>" +
                    "<td>" + timestamp + "</td>" +
                    "<td><button style='margin-top:5px;' type='button' id='multiImagesBtn" + productId + "' class='btn btn-success' data-toggle='modal' onclick='multiImages(this.id)'>View images</button>" +
                    "<td><button style='margin-top:5px;' class='delbtn btn btn-success'>Delete</button></td>"
            "</tr>";

            divObj.innerHTML += row;
        }

        // on click delete button

        $('.delbtn').click(function () {
            var $this = $(this);
            //get the row element of the delete button
            var trId = $(this).closest('tr').prop('id');
            var currentRow = document.getElementById(trId);

            var retVal = confirm("Do you want to remove this notification?");
            //if 'ok' is clicked on the alert box
            if (retVal == true) {
                deleteNotification(trId, currentRow.className)
                currentRow.style.display = 'none';
            }
        });
    });
});

// If a product have multiple images

function multiImages(btnid) {
    var id = btnid.split('n', 2)[1];
    getImage(id);
}

// To get images of the product id

function getImage(pid) {
    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem("userId"));
    myHeaders.append("sessionkey", sessionStorage.getItem("sessionKey"));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", sessionStorage.getItem("user_type"));
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(getimage+"product_id=" + pid, requestOptions)
            .then(response => response.json())
            .then(result => {
                // console.log(result);
                document.getElementById("idInModal").innerHTML = pid;
                var modalBody = document.getElementById("multiImageModalBody");
                modalBody.innerHTML = "";
                var resultobj = [];
                for (i = 0; i < result.data.length; i++) {
                    var t = {
                        rank: result.data[i].rank,
                        product_image_id: result.data[i].product_image_id,
                        image: result.data[i].image,
                        product_id: result.data[i].product_id
                    }
                    resultobj.push(t);
                }
                resultobj.sort(function (a, b) {
                    return a.rank - b.rank
                })
                console.log(resultobj);
                var remImages = [];
                if (resultobj[resultobj.length - 1].rank != 0) {
                    console.log(resultobj)
                    for (j = 0; j < resultobj.length; j++) {
                        if (resultobj[j].rank != 0) {
                            var img = "<div class='ImgDiv' id='ImgDiv" + resultobj[j].product_image_id + "' style='border:1px solid black;'><img class='productImg' src=" + resultobj[j].image + " id=" + resultobj[j].product_image_id + " style='width:150px; height:150px; padding:3px; margin:3px;'><span class='removeImage' id='removeImage" + resultobj[j].product_image_id + "' onclick='removeImage(this.id)' style='position:absolute'>X</span></div>";
                            modalBody.innerHTML += img;
                        } else {
                            var img = "<div class='ImgDiv' id='ImgDiv" + resultobj[j].product_image_id + "' style='border:1px solid black;'><img class='productImg' src=" + resultobj[j].image + " id=" + resultobj[j].product_image_id + " style='width:150px; height:150px; padding:3px; margin:3px;'><span class='removeImage' id='removeImage" + resultobj[j].product_image_id + "' onclick='removeImage(this.id)' style='position:absolute'>X</span></div>";
                            var id = resultobj[j].product_image_id;
                            var imgObj = {
                                img: img,
                                id: id
                            }
                            remImages.push(imgObj);
                        }
                    }
                    console.log(remImages)
                    for (i = 0; i < remImages.length; i++) {
                        modalBody.innerHTML += remImages[i].img;
                    }
                } else {
                    for (j = 0; j < resultobj.length; j++) {
                        var img = "<div class='ImgDiv' id='ImgDiv" + resultobj[j].product_image_id + "' style='border:1px solid black;'><img class='productImg' src=" + resultobj[j].image + " id=" + resultobj[j].product_image_id + " style='width:150px; height:150px; padding:3px; margin:3px;'><span class='removeImage' id='removeImage" + resultobj[j].product_image_id + "' onclick='removeImage(this.id)' style='position:absolute'></span></div>";
                        modalBody.innerHTML += img;
                    }
                }
                //document.getElementById("overlay").style.display="none";
                $('#imgs').val('');


                $('#multiImageModal').modal('show');
            })
            .catch(error => console.log('error', error));
}

function deleteNotification(timeStamp, userId) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.remove();
    alert("Notification Deleted");
}