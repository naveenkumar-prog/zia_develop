var getTask = localStorage.getItem("getTask");
var updateTask = localStorage.getItem("updateTask");

console.log("updateTask",updateTask);

console.log("getTask",getTask);

var tasks = []

var myHeaders = new Headers();
myHeaders.append("userid", "1784");
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("languagetype", "1");
myHeaders.append("usertype", "0");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

// const proxyurl = "https://cors-anywhere.herokuapp.com/";
const getTaskUrl = getTask+"store_id=1959";

// on change the current status

function changeStatus(status, storeTaskId) {

    //console.log(status, storeTaskId)

    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("status", status);
    urlencoded.append("store_task_id", storeTaskId);
    urlencoded.append("task_date", "2020-05-31 00:00:00");
    urlencoded.append("close_order_time", "2020-05-31 00:00:00");
    urlencoded.append("cancel_reason", "");

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    fetch(updateTask, requestOptions)
            .then(response => response.text())
            .then(result => console.log(result))
            .catch(error => console.log('error', error));

}

fetch(getTaskUrl, requestOptions)
        .then(response => response.json())
        .then(result => {
            tasks = result.data
            buildTable(tasks)
        })
        .catch(error => console.log('error', error));


// Too Display the Alloted Tasks  in a Table

function buildTable(tasks) {
    var tab = document.getElementById("tableBody")
    tab.innerHTML = ''
    for (var i = 0; i < tasks.length; i++) {

        if (tasks[i].payment_method == 1)
            payMethod = "Cash"
        else
            payMethod = "Online"

        if (tasks[i].mode == 1)
            modeDel = "Delivery"
        else
            modeDel = "Pickup"

        var sno = i + 1

        var status
        if (tasks[i].status == 1) {
            status = "Delivered"
        } else if (tasks[i].status == 2) {
            status = "In-transit"
        } else if (tasks[i].status == 3) {
            status = "Pending"
        } else if (tasks[i].status == 4) {
            status = "Cancelled"
        } else if (tasks[i].status == 5) {
            status = "To-deliver"
        }

        var shipDetails = "<b>Address:</b> " + tasks[i].address + "<br><b>Name:</b> " + tasks[i].name + "<br><b>Payment method:</b> " + payMethod + "<br><b>User id:</b> " + tasks[i].user_id;

        var change = "<select onchange=\"changeStatus(this.value,'" + tasks[i].store_task_id + "')\">" +
                "<option value='select'>--Select--</option>" +
                "<option value='1'>Delivered</option>" +
                "<option value='2'>In-transit</option>" +
                "<option value='3'>Pending</option>" +
                "<option value='4'>Cancel</option>" +
                "<option value='5'>To deliver</option>" +
                "</select>"

        var row = "<tr id='" + tasks[i].order_id + "'>" +
                "<td>" + sno + "</td>" +
                "<td>" + tasks[i].task_date + "</td>" +
                "<td><img src='" + tasks[i].image + "' class='taskImage'></td>" +
                "<td>" + tasks[i].order_id + "</td>" +
                "<td>" + status + "</td>" +
                "<td>" + change + "</td>" +
                "<td>" + tasks[i].verification_code + "</td>" +
                "<td>" + shipDetails + "</td>" +
                "<td>" + modeDel + "</td>" +
                "<td>" + tasks[i].total_amount + "</td>" +
                "<td>" + tasks[i].commision + "</td>" +
                "<td>" + tasks[i].close_order_time + "</td>" +
                "<td>" + tasks[i].cancel_reason + "</td>" +
                "</tr>";

        tab.innerHTML += row;
    }
    checkEditAccess();
}

function checkEditAccess() {

    var userId = localStorage.getItem("userId");
    console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(16);//.orderByKey();

    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);
        var tble = document.getElementById("table");
        var row = tble.rows;

        if (!snapshot.val().edit) {

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(5);
            }
        }
    })
}