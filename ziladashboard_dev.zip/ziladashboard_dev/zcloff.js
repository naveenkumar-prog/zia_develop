var api = localStorage.getItem("zclbanner");
getproffers();

function getproffers() {
    console.log("api:",api);
    var myHeaders = new Headers();
        myHeaders.append("sessionkey", "a2ed9c4adb38820e98d7f511962e2372");
        myHeaders.append("usertype", "3");
        myHeaders.append("userid", "25");
        myHeaders.append("languagetype", "2");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

        var formdata = new FormData();
        formdata.append("operation", "3");
                

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };
    //  Main Body

    var table = document.getElementById("tableBody");


    fetch(api, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log("res",result);
                console.log("reslen",result.data.length);
                if ((result.data.length) == 0)
                {
                    alert("No offers are available");
                }

                var myList = result.data;
                for (var i = 0; i < myList.length; i++) {
                    var sno = i + 1;
                    var row = "<tr id='" + myList[i].banner_id + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td>" + myList[i].banner_id + "</td>" +
                            "<td>" +
                            "<img id='displayImg" + myList[i].banner_id + "' src=" + myList[i].banner_image + " class='product_image'>" +
                            "</td>" +
                           
                            
                            "<td>" + myList[i].isactive + "</td>" +
                            "<td><button class='deleteUsers' id = '" + myList[i].banner_id + "'> <span>Delete Offer</span></button></td>" +
                            "</tr>";
                    table.innerHTML += row;
                   
                }
                $('.deleteUsers').click(function () {
                    var $this = $(this);
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                     var banner_id = trId;
                     console.log("banner_id",banner_id);
                   

                    deloff(banner_id);
                });

               
            })
}

// To delete offers 

function deloff(banner_id) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formData = new FormData();


    formData.append("banner_id", banner_id);
    formData.append("operation", "2");
    
    
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formData,
        redirect: 'follow'
    };

    fetch(api, requestOptions)
            .then(response => response.json())
            .then(result => {
                alert("Offer Deleted");
                location.reload();
            })
}


// On Click Update graphic 


// on click Add New Offer

function addOff() {
    
    var image = document.getElementById("graphics");
    if (image.files.length == 0) {
        alert("Please add image");
    } else {
        var myHeaders = new Headers();
        myHeaders.append("sessionkey", "a2ed9c4adb38820e98d7f511962e2372");
        myHeaders.append("usertype", "3");
        myHeaders.append("userid", "25");
        myHeaders.append("languagetype", "2");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

        var formdata = new FormData();
        formdata.append("operation", "1");
        
        formdata.append("graphic", image.files[0]);
        

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };

        fetch(api, requestOptions)
                .then(response => response.json())
                .then(result => {
                    alert("ZCl Offer Added!!");
                    location.reload();
                })
    }
}