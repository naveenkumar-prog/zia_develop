// const proxyurl = "https://cors-anywhere.herokuapp.com/";

var updateSubCategory = localStorage.getItem("updateSubCategory");
var getsubcategory = localStorage.getItem("getsubcategory");

console.log("getsubcategory",getsubcategory);
console.log("updateSubCategory",updateSubCategory);

function updateSubCategory(img, name, hindi_name, cat_id, sub_cat_id, updateImage) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formdata = new FormData();
    formdata.append("category_id", cat_id);
    formdata.append("hindi_name", name);
    formdata.append("name", hindi_name);
    if (updateImage == true)
        formdata.append("image", img)
    formdata.append("sub_category_id", sub_cat_id);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    fetch(updateSubCategory, requestOptions)
            .then(response => response.json())
            .then(result => console.log(result))
            .catch(error => console.log('error', error));
}

function deleteSubCategory(sub_cat_id) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var formdata = new FormData();
    formdata.append("sub_category_id", sub_cat_id);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };

    fetch(updateSubCategory, requestOptions)
            .then(response => response.json())
            .then(result => console.log(result))
            .catch(error => console.log('error', error));
}

subcat();
function subcat() {
    var categoryName = localStorage.getItem("catName")
    var categoryId = localStorage.getItem("catid")
    document.getElementById("categName").innerHTML = "" + categoryName + " (Category id: " + categoryId + ")";

    var subCategories = []

    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    const url = getsubcategory+"category_id=" + categoryId;

    fetch(url, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                subCategories = result.sub_category
                var tab = document.getElementById("myTable");
                tab.innerHTML = ''

                for (var i = 0; i < subCategories.length; i++) {
                    var sno = (i + 1)
                    var name = "img" + subCategories[i].sub_category_id

                    var row = "<tr id='" + subCategories[i].sub_category_id + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                            "<td>" + subCategories[i].sub_category_id + "</td>" +
                            "<td class='image'><img src='" + subCategories[i].image + "' class='subCategoryImage'><p class='imgbtn'>Change</p><input type='file' name='" + name + "' hidden /></td>" +
                            "<td class='canEdit'>" + subCategories[i].name + "</td>" +
                            "<td class='canEdit'>" + subCategories[i].hindi_name + "</td>" +
                            "</tr>";

                    tab.innerHTML += row;
                }

                $('.imgbtn').click(function () {
                    var $this = $(this);
                    //get the row element of the button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);

                    //get the <td> elements of the selected row
                    var tds = $this.closest('tr').find('.image').filter(function () {
                        return $(this).find('.editbtn').length === 0;
                    });

                    if ($this.html() === 'Change') {
                        $this.html('Update');
                        var name = "img" + trId
                        document.getElementsByName(name)[0].hidden = false
                    } else {
                        $this.html('Change');
                        var name = "img" + trId
                        var imgElem = document.getElementsByName(name)
                        imgElem[0].hidden = true

                        var img = imgElem[0].files[0]
                        var name = currentRow.cells.item(4).textContent
                        var hindi_name = currentRow.cells.item(5).textContent
                        var cat_id = localStorage.getItem("catid")
                        var isUpdateImage = true
                        if (imgElem[0].files.length == 1) {
                            updateSubCategory(img, name, hindi_name, cat_id, trId, isUpdateImage);
                        }
                    }
                });

                $('.editbtn').click(function () {
                    var $this = $(this);
                    //get the row element of the edit button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);

                    //get the <td> elements of the selected row
                    var tds = $this.closest('tr').find('.canEdit').filter(function () {
                        return $(this).find('.editbtn').length === 0;
                    });

                    if ($this.html() === 'Edit') {
                        $this.html('Save');
                        //make <td> elements of that row editable
                        tds.prop('contenteditable', true);
                        currentRow.classList.add('currRowEdit');
                    } else {
                        $this.html('Edit');
                        tds.prop('contenteditable', false);
                        currentRow.classList.remove('currRowEdit');
                        var img = 0
                        var name = currentRow.cells.item(4).textContent
                        var hindi_name = currentRow.cells.item(5).textContent
                        var cat_id = localStorage.getItem("catid")
                        var isUpdateImage = false
                        updateSubCategory(img, name, hindi_name, cat_id, trId, isUpdateImage);
                    }
                });

                $('.delbtn').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    console.log(trId);

                    var retVal = confirm("Do you want to remove this sub-category?");
                    //if 'ok' is clicked on the alert box
                    if (retVal == true) {
                        deleteSubCategory(trId)
                        currentRow.style.display = 'none';
                    }
                });

            })
            .catch(error => console.log('error', error));
}

