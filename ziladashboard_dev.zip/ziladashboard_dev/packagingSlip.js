function getDelhiveryS() {
    alert("Waybill Number is not yet genrated, Packaging slip cannot be downloded")
}
function getDelhivery(id) {
    console.log("sd")
    console.log(" id " + id)
    var myHeaders = new Headers();
    myHeaders.append("Authorization", "Token 93c95e3f3d9acf9d562a71e22e274d2f08ad950c");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    const proxyurl = "https://cors-anywhere.herokuapp.com/";
    fetch(proxyurl + "https://track.delhivery.com/api/p/packing_slip?wbns=" + id, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log("result " + result);
                createPDF(result);
            })
            .catch(error => console.log('error', error));
}

function createPDF(result) {
    var type = "Surface";
    if (result.packages[0].mot == "E")
        type = "Express";
    // const AmiriRegular = 'AAEAAAASAQAABAAgRFNJR2D2zXQA.....A';
    // console.log("ss");
    var doc = new jsPDF('p', 'pt', 'a4');
    // console.log('x');
    barcode = result.packages[0].barcode;
    oid_barcode = result.packages[0].oid_barcode;
    zila_logo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIYAAACGCAYAAAAYefKRAAAABHNCSVQICAgIfAhkiAAAFQdJREFUeF7tnXlcFMe2x3897LuyBUVxhSAIooka4xI3oiJoorhhjHGPyY3GxLwk931yL8nLTfLURK8aP7maJxp3UJMoiGhccEdFAi4BFZRF2TfZt+n3qQYGhkGYnumebpiuf5KPdFWdOuc71dVVp86h0E4J9gg2tu3nMkIGagpoTIIMXgAM2qsn/V08GqBByylQd2maipLL605Q8rIrqyJXVbUlIfW8PzJA9O01iaLoLRRF9RLPMCVJONBAOuTy1XlmVhHBYbOrW2uvVTC2TthqR5ubn6YoajAHQkhNiFQDNE3fqyqpeW3t+RV5LUVUAWOT/24XQ5n8LwDmIh2PJBaHGqBpuqrWgHJf89uix82bVQJj85QdPSgjw/sUYMZh31JTItcADVQbQO793rElSY2iKsD4duq2rlYy0wxQlDRTiNyQvIhHo7ymurr/mqgVmaR9BozgscGGtpYu0TIZ9SovnUqNdggN0DSu335aPWp77IoaBowtATvHUxR1pkNILwnJqwbkckxbFb7oODULswxeC5gSC4oaxGuPUuMdQgM0Td+9cNxyELXVf+cQyKjYDiE1B0IamxvByMwIhkYGAEVBXleHmspaVJVVg66jmR4MjAxgbGEMQxMDyAxkoOU0aqtrUV1eg9rKWg6kEHcTdXX0SGqrf8hHkOF7cYuqnXSGpoYYMMEVQwK9YGnb+tq6rrYOyVdTYWplAhcf5+d2mJtagJg9t5ARn4m66jrtBBNpbUqOYOrHgJ0naIqaIlIZtRLL2MIIM77zQ1dnG+aXz1WhaRp1tXI8iknDua2XUVPRuWYRmqbPUlsCdj6hKKo7V0oTQzvkVeH78Rj0GuKsAgQxanHmMxRkFMPZ0wkmFsZtipyTko+K4krYuXSBpZ2FyrPVFTVIiPiLmUU6TaGRRW2dFkJw7zSHYt0HvoAJq0bB+gUrhZ3Ir/vuqSQkX05F3uMCyGvkmLBmFPq90gsU1bTHl5OcDyNTQ2aGaSzkFXPryB1cPxAHsy5mcOxnhwETXdH3FRelupmJOTi1IRqluWWdgY86Akb9iqsTFM8pL2L0kmHM4rGxxIffQ2xYAiqKKpl/snK0hN9/j4d9b1vFM8SoMftu4UlCFmQGFPqP7oMRC19WWo+kxj3BqfXRqC6rP3Oy7dUFw4IGo+8wF1CyergqnlXi9PcXkP7n0w6vzU4DxkuzvTE8aLDiV1z4pBhR688j/1Ghwkj2fW3h/8VEWDQsQOV1csQciEPckTvMl4dSoYBxH4yE+9h+itdRflohjv3jFMoLKxSP9h3RC6OXD1dARGaYqA3ReHQ1rUPD0SnA8JnhiZELhzKGIGuIR9fTEPnNOSXDWDtZIXD9VJhZmzL/XllahaOfR6IwrahNA7pP7I/RS4fD2MyIea40vwwHVx9DVUmTO4NZF1ME/NMXDn3tFG2dXHeOeXV11NLhwejp050xCpnOCRR3Tibiwk8xSvYwNDbAvB/fgLVj/bqjrLAce1ccRW2Vel8Tjq72mPbV6zAxr1+oEqh2Lw5Tqk8ZUAgI9kVP76Z1fOR3Z5HSQWcOUYJh090K3QY6wcpW9Sug5S/Qa6q7YhYgr48HFx6p/Ei7OFvDbUzf+hlFTuPWkdvM5yabYmFvDk9fN0WVsqJy3I28r/z2oYDBM73qN88aCvliqXzWNLtUlFQiNzkfOUl5DMhiLaIBw8nDEePefxXWDpYwNDEUq744k4usRSpLqnDjUALuRiZy1i5XDQkOBtl2nvTpOLj4dOd0E4orBemindxHBTj9fTQK04t10Z1afQgKhqWDBd78ZgqsHS3VErYzP1RVXs18DqfdeiKKYQoGhqmNKQLXTYWNU9NGlCg0IqAQZDEc+vFxUcwcgoExfvUoDBjfX8UMZJOIbBClxmagpHPsIiqNkRzS9RzUDS5DnGHjZK0y/uryauxaFMqc+ApZBAGjm4cjZnzrpzLuJ/eycOLrs4rdRSEVo4u+Ry0bBi8/d8hkygd857Zdwb0o5S8eXcjTvA9BwPD9aAzcXqv/fGwsuY/yEfZRuOoOpK41ouP+hs3zwdC5Pkq9kk/pHXP3oa5GuGN9QcBYdmA+iMNM87JrcSjK8st1bBbhuyNnePN+fFPp4I5IFfZJOHLuq1z30JnAOgfDtndXzPv3dKUBkqPtsDXHdTZosXXkMdkN41Yq+2H/sekiks4lCyaqzsHoO8IFUz4brzTgC9tjcDuC3HHSz+Lk7oCZ/ztVafA3w+IRszdOMIXoHAxypD1p7WtKAz65IRrJF1W3srXVCtlBJQtdm25WMDIxAtkrKHr6DFmJOYxPhliKXR9bzN00TUmcuN/v4srOG4KJ2CnBIGcj3gEe8Jz0ImQNvhLNNVxTWYP44/cQf4ycY9T7aQhZJDAAxgmGrxmDnLB6TnbDmOWvKHlXPc/oxB+D+E48vp4OOctDNS5BksDgGQyyLzDI34O1zbIf5uHkd+cEc8uTwOARDO+AAYxDjTYl7rc7uBJyU5smNKorgcETGMRJZvHuucydEG0K40GeVYKodeeRl1KgTVOs6kpg8ATGyKVD4RPgycoYbT1M1h7J11JxZtMlnVwqksDgCYwFOwJ5ObonTr9Xdt9E0vlkgEdnKwkMnsBYfmg+jEyVt9g5mz4APL6Zjiu7YlGY3rbjsKZ9SmDwAAb5RF159G21Pk81NRypRw60YvbHISH8L85fLxIYPIBhbGmMZfuCtLE5q7qlBeU49o8oTp1pJDB4AMPKyQpv/2cmK+Nq+zD5ekk8n4xzmy9z4iYggcEDGI5u9pi13l9bW2tUn3h5k1PQ1JsZGtVvrCSBwQMYPXy6Y/qXr2tlGG0qy+U04o/d1WpjTAKDBzD6jHCBX4tjfG0MrUld8mohx+TX9/2pSXVIYPAAxgBfV4z/20iNDMJlJfLVQu7C5jxg73UlgcEDGENmemHE2y9xaWON28p+kIvDayNY15fA4AGM4QuG4OVAb9bG4KMCuXb48/wDrAO4SWDwAIamR+18gEHajP7pKu5EKiIvq9WNBAYPYEz8aDRefK2fWgbQxUPJMak42SI2R3v9SmDwAIZ/sC96DX5++MX2jML134nTz+GPw1k1K4HBAxgz1vmh24uOrAzB58OPYzMQ8dUfrLqQwOABDBIpx7ZHF1aG4PPhq3tjcSvsNqsuJDB4AGPRL3NgbiOO9CpyuRy7l4ahPL8peJs6hEhg8ADG0v1B7QZxVcc4XDxTkF6EA3/7jXVTEhhcg0EBy/YHwbghaBpri3BYgcT2Or3pAh5Es784JYHBMRgkqi+ZMVpekObQ3mo39eh6Ok78S7OULxIYXIMhawCjIQan2lbk+MH0hExEfHUadRpee5TA4BgMEt6ZzBh8+nu2x9CN0HjcOpyA2irNY1lIYHAOhqwBDN2GfyTH7PcvpDAxyrmItCeBwTkYup0xyAIz9VYGbh6KRzaHQU0kMDgGg+SAXLJ3HkwttbuB1t7rgswQeY8KcG3fLaTd5D7cogQG12AAmPDhKLiPU43+156x1f17SU4porfHIPVGurpVWD8ngcEDGCZWJlj8y9xW42CwtlBDBTJDkMUkcfRNucp/BgEJDB7AILacvTFAKSWEpkCQesRFL/o/15B0NhnkDqsuigQGT2CYWBnjrZ9marXWICEUr+2Lxb2oBzqPMyqBwRMY5FdNcqFN/WIijFneYSXu/zdD/2S8rhrTY+lilmjehwQGj2AQRZOEMxNWj4Jtz/aP4cmn5+2TiYg7ekewSDqNcEhg8AwGUTSJ1Ddk5kD0H9VHJagq+TvJyJwR/5S5oMzF5hQXs4sEhg7AaG4okvai+0AnmNmYMjfUSZScrKQcXmNdaAKKBAYAknVwymfjlPQXvf0a7kSIL8uPJkbWpM4L7g4I1PcAsCRf6bzNbyjpLy+1EIdW/a6JTjtFHY9Jbhj3nnLI6NMbL+D++RTBxqfzALDMNvaeeSqB1HYvCUNpXqfIcszKmJQMWLA9EFYOylmeSEKb3If5rNri8mHdg0G2sVePgnuLJDYktfbhTyI4j1bDpbL4aGvkkqHwmaYcWI7ki9+54IDG/h1cyCkIGA6u9pi9QTWmxdN72fhj40WQ84nOXmRGMiaCsYevq0qYqDObLyHxzENBVSAIGGTE41aNhMcEV5XBk1/L/egUEEga86gLqiGOOyfJgclXiMdEV0Uq8eZdlBdXYO/yI/qZ+ooogmxjz9rg32peMI5t0WGaI8HvD6z6HSXZws+Ygs0YxFrmXc0w+4cA5r/EsVefC0mS99sXUYIuOJvrX1AwiCAyQxmmfz2JuWZIQjPqWyFH/M+ySxC2NgJVJU2pvoXWg+BgNCqA7FJO/mwcXuhvL7ROdNY/iTx8etNFPEnI5CT6H5eCiwaMxkGZWpvAzNoUFvbmMBLBRSIulU3aktfUMV9dJOIfOc0lh3liLKIDQ4xK0keZJDD00epqjFkCQw0l6eMjEhj6aHU1xiyBoYaS9PERCQx9tLoaY5bAUENJ+viIBIY+Wl2NMUtgqKEkfXxEAkMfra7GmCUw1FCSPj6iMzCsHCwgM5BprOOS3FLI65TPFcgdEnI1QJNS+ayyTWcYK8cmH8yK4krUVtVq0k2bdciFbONmYaJKc0tBi+ToRGdgLN0XBBNLY42Vu++9oyh68kyp/oDXXTH+fc1ylVzZHYu4o60HajUwNsC7YQsUfZ359yUknuXe1Y64G/Tw6qbo59TGC3ggoGd4c+VKYLSCqi7AIH4oyw7Oh6GRgUKCoqfF2LfyV41/PFxW1BkYAcG+MFMzgq+RiQG6ONsoxpmbks94kMtrlcMS9BneEyMWvqyiD0s7c0XAturKGpTll6s8c+NQPB5Et35vQxdgeAV4YMzSYUpyEde+nW8f1CrQG1dw6AwMNgK3jJITsugQygvUD8Mc8KUvXHzqMxJoEvRdF2AEbvDHC671TkmPb2Wg95AeIN5cUevPI/ky/8Fa2rOH6MDoP7o3Jq0dy8hNQhQQV/r755LbG4fS38UOBkXCUO4LYhaeRZnPcOnn6/D/YiIzhuLsUuxdcVjw+7WiAoN4b83dPB0WXc0ZJaXFPcHx4NOsoCAPix0M7+meGL14KDOu25GJTBTAd0JmKxyidy0KRVmB6uuPtSK0qCAqMPz/ORG9hvRghlNWWIE9y8I0uo0lajAoMDHDiPsiKSe+PYtH19Iwc50fnBryrpwkr5NLj7Uwq/ZVRQOG29i+8F0zRvEKObUhGsmXNVOOmMEwMjPE0r1BjHc8ifH18/z9qKmohdu4vvD9sH78+WlFOPgB+ywG2uPQ1IJowCCfbo2bPSRv+pmNFzUep5jB8JzyIsa+O4IZW0pMGiK/Ocv8v003KyaOWGPZ++4RFGeWaKwDbSsKDga5SzLre39F1L2yogrsX3kU1eU1Go9NtGAwN/3nwtSq/jVCrg40LqyJHphMCg07oSSUZBLLRbfGCmulouBgeExyxdiVryoWXuH/8wdSb2ZoNUaxgkGuRLzzf7MVY9uz4gieZTXNCi/PGYThQYOZv2cm5eDof53QSg/aVBYUDOtuVpi/7U3IZPVnKAkRf+Hi9hhtxsPUFSsYzdONtxYshly6WrB9pkIfe949gmcCvU4EA4NsIr3xr8lwcnNgjFmaX46Dq35DVWl15wSDAt76aYbiEve5bVdwL+q+0lgNjAyweM9cxevkwvZruC1QCCrBwPB50xMj36n/lifl0JpjTPA0LooYZ4wuztaYv22GYngXd8SgJFc1gtDQeT5w6GPLPPf0XhZ+/fwkFyph3YYgYNj16Yo5G6cx6wqyDZxwIhGXOHiFNI5ejGB4TnZj1lJsC8nKWNoKQGzbYfu8IGDM+iEAjv3sGFnLiyqwa3Eo6Ba+FmwH0vx5MYIxZ/N02PfqynpYbbkHsG6MRQWdg/HKwpfw0gwvRsTa6jrsWXGY1QGZOmMTGxhdetggaOsbzAxJzn/ObrncZqyxl2Z5wb53w+vkbjZ+/XukOsPm9BmdgkFCDAWu84OhcX2qKnL0fX1/HKcDIo2JDYxB0z0xquFspKaiBjuC9rd5y73PKy7w+3w8oxcS/H734lAQLzJdFp2CEfTjm+jao97PIispF0c+jeDlFFFsYAR+76+I+5F4/iHObLzUpo3JZhf5OmnM3BRz4E/cPPinLrmAzsAYv2okBjQEYyMB2MI+CUdRejEvgxUTGORrhPwgmIW2nMYvyw+rtZgkn/LOA50Y/WQ/zMPhj8N50dXzGtUJGA797RC43l+RhSjjdiYesjw9TLmWqpI2wqa7NXp4N/lMNg7S23+AIgMB2Ui6c0I1HHXmvWwUpBW1qpeWjjrE35PMcOoU4jTcfCv75bk+GD7Ph6laVliOXe+EqtMMmr9+yFosZOFBrY4J1Oq02UO8g0GmxRWhb4Fs3mhTjnx6AlmJOUpN6MoZmI3cZC1A3PMaCzkHcmwIH8XGv4RJ6bVrDnMKS8r1g3G4cSCejShaPcs7GCRp7sqjC7USklTuiGCY25phUcgcZuxkv+b4l6eRHvdUbV3MXD9VsTOsa0dh3sEgWnD37a91uMbHMekqK3NrJys4e9e/h9mWp3eyUfxU+TpCYxtklnOfqFlmRpJkr9HJ2NrJEs4NrzqS3puti6Kjmz3setfvfZDXiS6vFugEDLZGk54XXgMSGMLbQJQSSGCI0izCCyWBIbwNRCkBAYM4QBiJUjpJKKE0UENtCQhJoSj0EUoCqV/xaYCmkUZtnbYrDKADxSeeJJFQGqBpRFCb/UOWyWTYLpQQUr/i04C8jlpLbfXb7QZDeZL4xJMkEkoDdC28mQQhWwNCIkFhslCCSP2KRwM0jbMfHF80gQFj27Td3nLIdXdCIx49SJK00ECNXP7qmvAlVxUphbYE7NpDUfRbkqb0VwM0jbAPji9ibkQpwPhhRKiZsUMZuUXsqL+q0eOR08iV1xr1XxX5FnOy2DIJmWxLwM5ciqLqPVGloicaoEsrHuc7fZLwieKii0p2uh9G/GBm7NCVfKX01BOt6Pswc/KepPYJjg1WitTSatrC9a//YmFqUreOovCevmutM49fLsdOg1KL1e+fn62S6LXNfJZb/EK8IMPfKRnmdmYF6dvYaBpHautqvl5zYvlzXc/VSnS6ecqOHjCUTZTBYCRN0QMpwAm0dPDWEYCiQddSFJUFOe7KaVyWU7I/PgxfmNae7P8PPz6wmGbwH3UAAAAASUVORK5CYII=";
    logo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAA+CAYAAADd977FAAAACXBIWXMAAAsSAAALEgHS3X78AAAHYElEQVR42u1czYvkRBT/ddMsHsTpnPQ2URZznN6rATsgeBCX7cWLnjYLet6ef8DJoPfJHkRvmwHB4/b8BZs+BNaLZkCQHGS72YMgsumGRcSD7SEva01tVb4zXemdB8P09OSjqn7v/d5HXqW32WxQRmLT0AH4APbRnqwBOFoQuYL7TwDoAHwtiELsmAwqnDNpEYw1ABeAqwXRigFhBMCmnz3m+zWAGYCZFkSzXQCkV8FCPAB3WhjLKYBpCkRsGkMCfwrgoCCYHoG5eJUACQsuUFGZA7DTRSRrmNYE/YwoL9xpQEhr44buvSQgfLq2XcIaKlldF6Rf8vhRQ37iUAsiHUAYm4YTm8YCwIOGwQBZ2YICgZ0ExGpAY3UAs9g0XAALAEctR2x7AB7GpuFcWcj/cg7gBgCHoqgnAO6xEdMlyBEFJK+0hawBHDLR0pOWIrTCFKY6KIUBoYSwjEafkU8YKQAED8p0FyykKF0tAdwEEBJV3VFw3icUXnc6Uy9CV8cA/gDw/SX7hyriNRQ1Kmkh5wC+oNLGNx0AAwAOKPfpZmIYm4bswPsUyt5qOHvnlaENkJeUD3ULEOLbnwVW8RjApw0s1hmSIqEvq0NRUGFRxNYk+He1IPK6BsgUwAmX4Fk1E7q0suuVLQYSODYllbWtUQsiq2uAeBQt/UIh7M0GgHDr1pjIcr0GSi5vq1IhLgpICOApgPcBvFGTmuymi30NPBJQhraKRlnPAXxcE4xDLYgmbVRetSCyCeyqogxlDQponwXArElR1iU8m7ApGa3i15TJR/ota89lgQGyPKdqTtIlQEaqg8GA4iEp3VQNEHYaEHtLj1CrNjsMlQeE4v0qnHy8xS4Qv+J5ehcspIp1zLUgcrY4p/AKkIt+w97mhLrcAlQEkLIRltP1BdklC1mKWj+vpCFAKAwsU8V1rpazXQspax2eChOiyPAygwElAVHJOqrmTSvVASnq0Nc1krE2xNpVQIrWd2aK9c5WahtVpTG7L+HhMlqmjHVQD2+VysK56k59VEKzVKKrqg1w4a4AMlfIOiwA44qn+6rMY1DTMfotLe6QU4rUR7EV2ZDzXXWSUnUBocXY37Kp27jY5fIDgM84quwxYxZt9Lmd0ilZz6OMHGqhMmWViePbiq54C30mc8JUUXBytN7qQlAioyxLAUB4pXhdZJlkzR7EJZ5pbBoAgN61/iebf/6V3cu9AiTff/CUyT/N8xkwZPnSiya6DDDmqlWnBzUpS0eyLa3MYtsEerrICyTdi77k/ucCJfmNqGaBpONep4QwtZQzxr8NOcVhozGPxuXh4gMql86ZcOOZ0VjTrdsu+38tiCzyVxPJOnpszY+OdaSAVNiUMywBhk0T5a8/RrKJ5pT6q/jF/0lgBR8AmAheLuDT9V1md+8EwIr7e0zO3KNxsU12T5F08n8kmMYYgBObRtq8YTPzWRNA90oEQQ4Xqh/3a1hH4TIFLcKDHLDv0HH8GJ5zf3+lBZHDl2togTz67HNz0gU063C/U/lLAkYqe0g2rfLKu5cDxoX1JUVgwVgCcPs1/AcATIiG8sRjPq8pJO0B0HCxbUdkIdcY6rqhBdGXsWlMY9PwBVvTZoIyiCUAZM5YB+uvIgAGR5c3aKy3me/3Jcq4RrI945j54SkeEkVwtCBaDWpayB6VK5wcqtrjwtEVUy/zGcp4S2BF7yDpYnGY650wFOLm0MJIEIh8K1mU3zlAHABDGusq57rCPjSugrDP5E37XHDhiZx6ldLDUWwaPkcTMq0Akr0dsv0dr3MTfAzgOybB03PC1BGbfzC0onPW6gis4xQvN2w/zLjXdYHDDiX50DjLkbM1uD7nFKvKo4ydrWVo8E+isENaxNc4jZ9wFrQUgB8KtJjVzDGNyeHAL1uYvF4wwRQ5cnYOpyyQgxp0xcsJOWUPF5+R+Jzl3RWEfmmo+Cu7eSY2DZ3LE6w8euK0lHWinzMg8NbhaEG0ShPJLApiLO9JwTKSn8FCLynCoIZDhyQsHAN4EJvGnAY5BPAjgL/pmA+JLoYUzi4pnzhg6YgsdpHD23m1NHZOXzOauc/Vslwmf7nF+EePs/w0f+IX+Vz2kI6AXkrqgy9tWmrSQmTgAMCZFkSTDMefFv/CDH8gyuB9DkCZQ0/fsfKmpJDJ0onFAHcgKErer6AYvsA/LUUdnmzY22ZL/i0KU0eS7N0FsBbQTZijMNLjGYeeJpyiisIZG4zQ/S1kd9D7BaiTl0WOIryQ3mazyStPNy1rZgI6o/VrwQIvmHBT1Cc2zzheR7Kr1+Z8VSZlCHwbu+ihFkQLwZuFMvdLCjJ4KWOkgPC7bHdBtrZvkKxTZ/zOEaeQI1lRc9CgQ1dFllTn2uZzcjcj18rsf+635NC3JfcFoe82RLaep3n9z71n773b5HsUtyVzJO9W3Hr3iOC9lKlv9IpQ6KDj1jEnCvBVGRA5917V8wcd9B9p6+pO7kXpCiBLiv935g3WXaOstOwSIuMNQbsKyDYc4Yq7b5h+16WXHrch/wFxwBMEDjDsWgAAAABJRU5ErkJggg==";
    // console.log(logo)
    doc.addImage(barcode, 'PNG', 205, 120);
    doc.text(result.packages[0].pin.toString(), 50, 240);
    doc.text(result.packages[0].sort_code.toString(), 460, 240);
    doc.addImage(zila_logo, 'PNG', 260, 40, 62, 62);
    var finalY = doc.previousAutoTable.finalY;
    var table = doc.autoTable({
        theme: 'grid',
        head: [],
        body: [
            ["Shipping Address: \n" + result.packages[0].name + "\n" + result.packages[0].address + "\nPIN:" + result.packages[0].pin, "" + result.packages[0].pt + ":\nINR " + result.packages[0].cod.toString() + "\n" + type],
        ],
        columnStyles: {
            1: {cellWidth: 85, fontStyle: "bold"}
        },
        startY: 250
    })
    finalY = doc.previousAutoTable.finalY;
    doc.autoTable({
        theme: 'grid',
        head: [],
        body: [
            ["Seller: " + result.packages[0].snm + "\nAddress:" + result.packages[0].sadd, ""],
        ],
        startY: finalY,
        columnStyles: {
            1: {cellWidth: 170}
        },
    })
    finalY = doc.previousAutoTable.finalY;
    doc.autoTable({
        theme: 'grid',
        head: [],
        body: [
            ["Product", "Price", "Total"],
        ],
        columnStyles: {
            0: {cellWidth: 345},
            1: {cellWidth: 85},
            2: {cellWidth: 85},
        },
        startY: finalY
    })
    finalY = doc.previousAutoTable.finalY;
    doc.autoTable({
        theme: 'grid',
        head: [],
        body: [
            ["" + result.packages[0].prd, "INR " + result.packages[0].rs, "INR " + result.packages[0].rs],
        ],
        columnStyles: {
            0: {cellWidth: 345},
            1: {cellWidth: 85},
            2: {cellWidth: 85},
        },
        startY: finalY
    })
    finalY = doc.previousAutoTable.finalY;
    doc.autoTable({
        theme: 'grid',
        head: [],
        body: [
            ["Total", "INR " + result.packages[0].rs, "INR " + result.packages[0].rs],
        ],
        columnStyles: {
            0: {cellWidth: 345, fontStyle: "bold"},
            1: {cellWidth: 85, fontStyle: "bold"},
            2: {cellWidth: 85, fontStyle: "bold"},
        },
        startY: finalY
    })
    finalY = doc.previousAutoTable.finalY;
    doc.addImage(oid_barcode, 'PNG', 240, finalY + 8, 110, 50);
    doc.autoTable({
        theme: 'grid',
        head: [],
        body: [
            ["Return address: " + result.packages[0].radd + "-" + result.packages[0].rcty + "-" + result.packages[0].rst + "-" + result.packages[0].rpin],
        ],

        startY: finalY + 65
    })

    doc.save("Packaging slip.pdf")

}