$(document).ready(function () {
    $(document).ajaxStart(function () {
        $("#wait").css("display", "block");
    });
    $(document).ajaxComplete(function () {
        $("#wait").css("display", "none");
    });
    // $("button").click(function(){
    //     tableFromJson();
    // });
});

var newAssignProduct = localStorage.getItem("newAssignProduct");
var getAssignProduct = localStorage.getItem("getAssignProduct");
var getUploadvideo = localStorage.getItem("getUploadvideo");



console.log("getAssignProduct:",getAssignProduct);
console.log("newAssignProduct:",newAssignProduct);
console.log("getUploadvideo:",getUploadvideo);


var userId = localStorage.getItem("userId");

var activitiesconfig = {
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-activities.firebaseapp.com",
    databaseURL: "https://zila-android-activities.firebaseio.com",
    storageBucket: "zila-android-activities.appspot.com"
};
const activityApp = firebase.initializeApp(activitiesconfig, 'Secondary');

function changeStatus(prodVideoId, newStatus) {
    console.log(prodVideoId, newStatus);
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("product_video_id", prodVideoId);
    urlencoded.append("product_video_status", newStatus);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";

    fetch(newAssignProduct, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                if (result.status == 200) {
                    var status;

                    var today = new Date();
                    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                    var dateTime = date + ' ' + time;


                    if (newStatus == 1) {
                        status = "Approved";
                    } else if (newStatus == 2) {
                        status = "Rejected";
                    } else {
                        status = "Not Approved";
                    }
                    var data = {
                        activity: "Changed the status of product video ID '" + prodVideoId + "' to: '" + status + "'",
                        userId: userId,
                        time: dateTime
                    };
                    activityApp.database().ref('Activities/').push(data);
                    document.getElementById(prodVideoId).cells.item(10).textContent = status;
                }
            })
            .catch(error => console.log('error', error));
}

function changeLang(x) {
    return x;
    location.reload();
}

function addProductList(seller_id, product_video_id, div_id) {
    var divElem = document.getElementById(div_id);
    var arrProdId = divElem.innerText.split(" ");
    for (var i = 2; i < arrProdId.length; i++) {
        var product_id = arrProdId[i].split(",")[0];

        var myHeaders = new Headers();
        myHeaders.append("userid", "1784");
        myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
        myHeaders.append("languagetype", "1");
        myHeaders.append("usertype", "0");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
        myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

        var urlencoded = new URLSearchParams();
        urlencoded.append("seller_id", seller_id);
        urlencoded.append("video_link", product_video_id);
        urlencoded.append("product_id", product_id);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: urlencoded,
            redirect: 'follow'
        };

        console.log("sellerId", seller_id, "video_link", product_video_id, "productId", product_id);

        // const proxyurl = "https://cors-anywhere.herokuapp.com/";

        fetch(newAssignProduct, requestOptions)
                .then(response => response.json())
                .then(result => {
                    //console.log(result)
                    alert("Products added successfully");
                })
                .catch(error => {
                    console.log('error', error)
                    alert("Error adding products!");
                });
    }
}

// OnClick  Add Product Button

function addProduct(productId, divId) {
    var divElem = document.getElementById(divId);
    divElem.innerHTML += productId + ', ';
}


// OnClick See Products

function getproduct(product_video_id)
{
    var allproducts = "";
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("user_type", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Cookie", "ci_session=qu7e6hiedl5lgliame14h8kt94vd20uu");


    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
    const url = getAssignProduct+"product_video_id=" + product_video_id;

    fetch(url, requestOptions)
            .then(response => response.json())
            .then(result => {

                for (var i = 0; i < result.data.length; i++) {
                    var obj = result.data[i];
                    allproducts = allproducts + obj.product_id + ", ";
                    console.log("" + obj.product_id);
                }

            }
            )
            .catch(error => console.log('error', error));
}

// console.log("this " +getproduct("1174"));  
// the json data. (you can change the values for output.)
var myHeaders = new Headers();
myHeaders.append("usertype", "0");
myHeaders.append("userid", "1784");
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("languagetype", "1");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

// const proxyurl = "https://cors-anywhere.herokuapp.com/";
const url = getUploadvideo+"seller_id=0&status=0";

fetch(url, requestOptions)
        .then(response => {
            return response.json()
        })
        .then(data => {
// Work with JSON data here


            for (var i = 0; i < data.data.length; i++) {
                var statusString = "<select onchange='changeStatus(" + data.data[i].product_video_id + ",this.value)' id=" + 63 + " name=" + status + "> <option selected=" + 0 + " value=" + 0 + ">Not Approved</option> <option value=" + 1 + ">Approved</option><option value=" + 2 + ">Rejected</option> </select>";

                var obj = data.data[i];
                var videoString = "<button class='watchvideo' id='" + data.data[i].hindi_video_link + "' onclick='videoPopup(this.id)' data-toggle='modal' data-target='#modal1' >Watch video</button>";
                var imageBtnString = "<button class='seeImage' id='" + data.data[i].hindi_video_link + "' onclick='imagePopup(this.id)' data-toggle='modal' data-target='#modal2' >See Image</button>";
                var imageString = "<img src=" + data.data[i].thumbnail + " alt=\"Thumbnail\" width=" + 150 + " height=" + 150 + ">";
                var videolinktring = data.data[i].hindi_video_link + "";
                var videotypestring = videolinktring.substr(videolinktring.lastIndexOf('.') + 1);
                var productdetailString = "<button  id='" + data.data[i].product_video_id + "' onclick='getproduct(this.id)' data-toggle='modal' data-target='#modalp' >See Products</button>";
                // var imageString = "<img src="+data.data[i].thumbnail+" alt=\"Thumbnail\" width="+150+" height="+150+">";
                var rowId = data.data[i].product_video_id
                var $tr = $("<tr id='" + rowId + "'>");
                var $SNO = $("<td>");
                var $title = $("<td>");
                var $category_id = $("<td>");
                var $Video = $("<td>");
                var $product_details = $("<td>");
                var $add_product = $("<td>");
                var $created_on = $("<td>");
                var $seller_id = $("<td>");
                var $seller_name = $("<td>");
                var $thumbnail = $("<td>");
                var $status = $('<td>');
                var $changeStatus = $("<td>");
                var $video_type = $("<td>");

                var listProd = "<div id='listOfProducts" + rowId + "'><b>Product Ids: </b></div>"
                var prodInput = "<input class='prodAddInput' placeholder='Enter product id'/><br><input class='addbtn' type='button' value='Add product'/> <input type='button' class='donebtn' value='Done'/>";
                var vidStatus = "Not approved";

                if (data.data[i].isApproved == 1) {
                    vidStatus = "Approved"
                }


                $SNO.append(i + 1);
                $title.append(obj.title);
                $category_id.append(obj.category_id);

                if (videotypestring == 'jpeg' || videotypestring == 'webp' || videotypestring == 'jpg')
                {
                    $Video.append(imageBtnString);
                } else {
                    $Video.append(videoString);
                }




                $product_details.append(productdetailString);
                $add_product.append(listProd + prodInput);
                $created_on.append(obj.created_on);
                $seller_id.append(obj.seller_id);
                $seller_name.append(obj.name);
                $thumbnail.append(imageString);
                $status.append(vidStatus)
                $changeStatus.append(statusString);
                $video_type.append(videotypestring);

                $tr.append($SNO);
                $tr.append($title);
                $tr.append($category_id);
                $tr.append($Video);
                $tr.append($product_details);
                $tr.append($add_product);
                $tr.append($created_on);
                $tr.append($seller_id);
                $tr.append($seller_name);
                $tr.append($thumbnail);
                $tr.append($status);
                $tr.append($changeStatus);
                $tr.append($video_type);

                $('#tableBody').append($tr);
            }



            $('.addbtn').click(function () {
                var $this = $(this);
                //get the row element of the edit button
                var trId = $(this).closest('tr').prop('id');
                var currentRow = document.getElementById(trId);
                var inputElem = $(currentRow).find("input")[0];
                var inputVal = inputElem.value;
                var divId = "listOfProducts" + trId;
                var sellerId = currentRow.cells.item(6).textContent;
                //seller_id = sellerId , product_video_id = trId, product_id = inputVal
                //addProduct(sellerId, trId, inputVal);
                //console.log("sellerId ", sellerId, "trId", trId, "inputVal", inputVal, "divId", divId);
                inputElem.value = ''
                addProduct(inputVal, divId);
            });

            $('.donebtn').click(function () {
                var $this = $(this);
                //get the row element of the edit button
                var trId = $(this).closest('tr').prop('id');
                var currentRow = document.getElementById(trId);

                var divId = "listOfProducts" + trId;
                var sellerId = currentRow.cells.item(7).textContent;
                //seller_id = sellerId , product_video_id = trId, product_id = inputVal
                addProductList(sellerId, trId, divId);
            });

            //console.log(data)
            checkEditAccess();
        })
        .catch(error => {
            // Do something for an error here
            console.log("Error", error);
            alert("Error fetching data");
        })




function checkEditAccess() {


    // console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(21);//.orderByKey();

    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);
        var tble = document.getElementById("table");
        var row = tble.rows;

        if (!snapshot.val().edit) {
            $(".addbtn").remove();
            $(".donebtn").remove();
            $(".prodAddInput").remove();

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(11);
            }
        }

    })
}

var video = document.getElementById('video');

// on click watch video

function videoPopup(id) {
    // var proxyurl = "https://cors-anywhere.herokuapp.com/";
    // console.log(id);
    if (id.toString().slice(-3) == 'mp4') {
        console.log(3);
        $('#video').html("<source src='" + id + "' type='video/mp4; codecs=\"avc1.42E01E, mp4a.40.2\"'>");

        // var source = document.createElement('source');
        // source.setAttribute('src', proxyurl+id);
        // video.appendChild(source);
        video.load();
        video.play();
        return;
    } else if (id.toString().slice(-4) == 'webm') {
        console.log(4);

        $('#video').html("<source src='" + id + "' type='video/webm'>");

        // var source = document.createElement('source');
        // source.setAttribute('src', proxyurl+id);
        // video.appendChild(source);
        video.load();
        video.play();
        return;
    } else if (Hls.isSupported())
    {
        console.log(1);
        var hls = new Hls();
        hls.loadSource(id);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, function ()
        {
            video.play();
        });
    } else if (video.canPlayType('application/vnd.apple.mpegurl'))
    {
        console.log(2);
        video.src = id;
        video.addEventListener('canplay', function ()
        {
            video.play();
        });
    }

}

function stopVideo() {
    video.pause();
    video.currentTime = 0;
}

//OnClick View Image Button

function imagePopup(id) {
    // var proxyurl = "https://cors-anywhere.herokuapp.com/";
    if (id.toString().slice(-4) == 'jpeg') {
        console.log(3);
        $('#image').html("<img src='" + id + "' style='width:300px; height:300px; padding:3px; margin-left:25rem;'>");

        // document.getElementById('image').innerHTML="<img src='"+ id +"'>";

        return;
    } else if (id.toString().slice(-4) == 'webp') {
        console.log(4);
        // document.getElementById('image').innerHTML="<img src='"+ id +"'>";
        $('#image').html("<img src='" + id + "' style='width:300px; height:300px; padding:3px; margin-left:25rem;'>");

        return;
    }
}

// On Click See Products


function getproduct(id) {
    // var proxyurl = "https://cors-anywhere.herokuapp.com/";

    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("user_type", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Cookie", "ci_session=5ehngk0b2crsgafql8e108vbjmbhjrtd");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

// var proxyurl = "https://cors-anywhere.herokuapp.com/";
    var url = getAssignProduct+"product_video_id=" + id;

    fetch(url, requestOptions)
            .then(response => response.json())
            .then(result => {
                var showdata = "";

                for (var i = 0; i < result.data.length; i++) {

                    showdata = showdata + 'Product ID : ' + result.data[i].product_id + "<br>";
                    document.getElementById("myData").innerHTML = showdata;
                    // mainContainer.appendChild(data);

                    // document.getElementById("myElement").innerHTML = xhr.responseText;
                }

            })



            .catch(error => console.log('error', error));

    // var mainContainer = document.getElementById("myData");

}