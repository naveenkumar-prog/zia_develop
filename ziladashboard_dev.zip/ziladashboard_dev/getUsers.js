var getUsers = localStorage.getItem("getUsers");
var deleteuser = localStorage.getItem("deleteuser");
var addwalletmoney = localStorage.getItem("addMoney");

console.log("getUsers:",getUsers);
console.log("deleteuser:",deleteuser);
console.log("addwalletmoney:",addwalletmoney);

var users = [];
var id = 0;
document.getElementById("select").value = 0;
let wltBlc = "transactionList";

// const proxyurl = "https://cors-anywhere.herokuapp.com/";
const getUserUrl = getUsers+"user_type_id=";

var myHeaders = new Headers();
myHeaders.append("userid", "1784");
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("languagetype", "1");
myHeaders.append("usertype", "0");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

var state = {
    'querySet': users,

    'page': 1,
    'rows': 20,
    'window': 5,
}

buildTable(id);

// To Display filtered pages 

function pagination(querySet, page, rows) {

    var trimStart = (page - 1) * rows
    var trimEnd = trimStart + rows

    var trimmedData = querySet.slice(trimStart, trimEnd)

    var pages = Math.ceil(querySet.length / rows);
    //console.log(pages)

    return {
        'querySet': trimmedData,
        'pages': pages,
    }
}

// To display page buttons in footer

function pageButtons(pages) {
    var wrapper = document.getElementById('pagination-wrapper')

    wrapper.innerHTML = ``
    //console.log('Pages:', pages)

    var maxLeft = (state.page - Math.floor(state.window / 2))
    var maxRight = (state.page + Math.floor(state.window / 2))

    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = state.window
    }

    if (maxRight > pages) {
        maxLeft = pages - (state.window - 1)

        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = pages
    }

   /* for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += `<button value=${page} class="page btn btn-sm btn-info">${page}</button>`
    }

    if (state.page != 1) {
        wrapper.innerHTML = `<button value=${1} class="page btn btn-sm btn-info">&#171; First</button>` + wrapper.innerHTML
    }

    if (state.page != pages) {
        wrapper.innerHTML += `<button value=${pages} class="page btn btn-sm btn-info activePage">Last &#187;</button>`
    }
*/
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += `<button value=${page} class="pg btn btn-sm btn-info pg${page}" id ='${page}'>${page}</button>`
    }
    for(var p= maxLeft; p<=maxRight;p++){
        document.getElementById(p.toString()).style.backgroundColor='#91bbcf';
    }

    var sp = state.page
    document.getElementById(sp.toString()).style.backgroundColor='crimson';


    if (state.page > 3) {
        wrapper.innerHTML = `<button value=${1} class="pg btn btn-sm btn-info ">&#171; First</button>` + wrapper.innerHTML
    }

    if ((state.page != pages) && (state.page != pages-1)){
        wrapper.innerHTML += `<button value=${pages} class="pg btn btn-sm btn-info " id = "lst">Last &#187;</button>`
    }
    $('.pg').on('click', function () {
        $('#table-body').empty()

        state.page = Number($(this).val())

        buildTable(id)
    })
}

// To display filtered data as a table

function buildTable(userId) {
    console.log("buildTable enters");
    document.getElementById("userTypeSno").innerHTML = "S.No";
    document.getElementById("tableBody").innerHTML = ''
    id = userId;
    fetch(getUserUrl + id, requestOptions)
            .then(response => response.json())
            .then(result => {
                users = result.data


                state.querySet = result.data
                console.log("sq",state.querySet)
                var tab = document.getElementById("tableBody")
                tab.innerHTML = ''
                var res = pagination(state.querySet, state.page, state.rows)
                var myList = res.querySet
                console.log("before for",state.page);
                for (var i = 0; i < myList.length; i++) {
                    var sno = i + 1
                    var row = "<tr id='" + myList[i].userId + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td>" + myList[i].name + "</td>" +
                            "<td>" + myList[i].userId + "</td>" +
                            "<td>" + myList[i].username + "</td>" +
                            "<td>" + myList[i].email + "</td>" +
                            "<td class='walletBalance'id='walletBalance" + myList[i].userId + "' onclick='transactionList(this.id)' style='cursor:pointer' >" + myList[i].wallet_balance + "</td>" +
                            "<td>" + myList[i].primary_address + "</td>" +
                            "<td>" + myList[i].phone + "</td>" +
                            "<td><button class='viewDetails'><span>View</span></button></td>" +
                            "<td>" + myList[i].deviceType + "</td>" +
                            "<td>" + myList[i].createdOn + "</td>" +
                            "<td>" + myList[i].updatedOn + "</td>" +
                            "<td>" + myList[i].lang + "</td>" +
                            "<td>" + myList[i].isactive + "</td>" +
                            "<td><button class='accounts'><span>View other accounts</span></button></td>" +
                            "<td><button class='addMoney'><span>Add Money</span></button></td>" +
                            "<td style='display:none'>" + myList[i].sessionKey + "</td>" +
                            "<td style='display:none'>" + myList[i].userType + "</td>" +
                            "<td><button class='deleteUsers' id='walletBalance" + myList[i].userId + "' onclick= 'delUser(this.id)' ><span>Delete User</span></button></td>" +
                            "<td style='display:none;'>" + myList[i].userType + "</td>" +
                            "</tr>";

                    tab.innerHTML += row;
                }
                pageButtons(res.pages)

                // on View Details button clicked

                $('.viewDetails').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    var usertype = currentRow.cells.item(17).innerHTML;
                    console.log(currentRow)
                    console.log("User " + usertype);

                    if (usertype == 5) {
                        localStorage.setItem("zclid", trId);
                        localStorage.setItem("zclPartName", currentRow.cells.item(1).textContent);
                        window.open('getZclDetails.html', '_blank');
                    } else if (usertype == 4) {
                        sessionStorage.setItem("userId", currentRow.cells.item(2).textContent);
                        window.open('employeeAccess.html');
                    } else if (usertype == 2) {
                        console.log("checki:", trId);
                        localStorage.setItem("vendorID", trId);
                        localStorage.setItem("user_name", currentRow.cells.item(1).textContent);
                        window.open('vendorDetails.html')
                    }
                });
                $('.addMoney').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    var headers = {
                        userid: trId,
                        user_type: currentRow.cells.item(17).textContent,
                        sessionkey: currentRow.cells.item(16).textContent
                    }
                    // sessionStorage.setItem("mUserId", trId);
                    // sessionStorage.setItem("mUserType", currentRow.cells.item(17).textContent);
                    // sessionStorage.setItem("mSessionKey", currentRow.cells.item(16).textContent);
                    // window.open('addMoney.html');
                    // document.getElementById("modal").style.display="block";
                    $("#modal").modal();

                    document.getElementById("userh3").innerHTML = trId;
                    console.log(headers.sessionkey);
                    // addMoney(c_amt, d_amt, o_id, headers);
                    document.getElementById("addMoneyBtn").onclick = function (event) {
                        event.preventDefault();
                        console.log(headers);
                        var d_amt = document.getElementById("debit_amt").value;
                        var c_amt = document.getElementById("credit_amt").value;
                        var o_id = document.getElementById("order_id").value;
                        console.log(d_amt, c_amt, o_id);
                        addMoney(c_amt, d_amt, o_id, headers);

                    }
                });
                $('.accounts').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    sessionStorage.setItem("phone", currentRow.cells.item(7).textContent);
                    window.open('otherAccounts.html');
                });

            })
            .catch(error => console.log('error', error));
}

// While Addding Money

function addMoney(credit_amt, debit_amt, order_id, headers) {
    console.log(headers);
    var myHeaders = new Headers();
    myHeaders.append("userid", headers.userid);
    myHeaders.append("sessionkey", headers.sessionkey);
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", headers.user_type);
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    // myHeaders.append("Cookie", "ci_session=05hs6nu0kgvknnom0r3gtiu6nm5pd787");
    console.log(headers.userid);

    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var urlencoded = new URLSearchParams();
    urlencoded.append("credit_amt", credit_amt);
    urlencoded.append("debit_amt", debit_amt);
    urlencoded.append("transaction_date", dateTime);
    urlencoded.append("description", order_id);

    console.log(urlencoded);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
   // const url = "http://api.myzila.com/AddWalletMoney";

    fetch(addwalletmoney, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                console.log(result.status);
                if (result.status == 200) {
                    alert("Money added successfully!");
                } else {
                    alert("Could not add money.");
                }
            })
            .catch(error => console.log('error', error));
}


//display table based on search results
// $('#search-input').on('keyup', function(){
//     value = $(this).val()
//     var keycode = (event.keyCode ? event.keyCode : event.which);
//     if(keycode == '13'){
//         searchPageNum=0;  
//     }
//     buildSearchTable(value);
// })

//display search results in table 
function buildSearchTable() {
    var value = document.getElementById("search-input").value;
    var table = document.getElementById("tableBody");
    table.innerHTML = '';
    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
    const url = getUsers+"phone=" + value;

    var myHeaders = new Headers();
    myHeaders.append("userid", "3513");
    myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
// myHeaders.append("Cookie", "ci_session=05hs6nu0kgvknnom0r3gtiu6nm5pd787");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(url, requestOptions)
            .then(response => response.json())
            .then(result => {
                // var tab = document.getElementById("tableBody");
                var myList = result.data;
                var userTypeMap = {
                    '0': "Admin",
                    '1': "Seller",
                    '2': "Vendor",
                    '3': "User",
                    '4': "Employee",
                    '5': "Community leader"
                };

                console.log(myList);

                for (var i = 0; i < myList.length; i++) {
                    var sno = i + 1;
                    document.getElementById("userTypeSno").innerHTML = "User Type";
                    var row = "<tr id='" + myList[i].userId + "'>" +
                            "<td>" + userTypeMap[myList[i].userType] + "</td>" +
                            "<td>" + myList[i].name + "</td>" +
                            "<td>" + myList[i].userId + "</td>" +
                            "<td>" + myList[i].username + "</td>" +
                            "<td>" + myList[i].email + "</td>" +
                            "<td class='walletBalance' id='walletBalance" + myList[i].userId + "' onclick= transactionList(this.id) style='cursor:pointer' >" + myList[i].wallet_balance + "</td>" + "<td>" + myList[i].primary_address + "</td>" +
                            "<td>" + myList[i].phone + "</td>" +
                            "<td><button class='viewDetails'><span>View</span></button></td>" +
                            "<td>" + myList[i].deviceType + "</td>" +
                            "<td>" + myList[i].createdOn + "</td>" +
                            "<td>" + myList[i].updatedOn + "</td>" +
                            "<td>" + myList[i].lang + "</td>" +
                            "<td>" + myList[i].isactive + "</td>" +
                            "<td><button class='accounts'><span>View other accounts</span></button></td>" +
                            "<td><button class='addMoney'><span>Add Money</span></button></td>" +
                            "<td style='display:none'>" + myList[i].sessionKey + "</td>" +
                            "<td style='display:none'>" + myList[i].userType + "</td>" +
                            "<td><button class='deleteUsers' id = '" + myList[i].userId + "' onclick = delUser(this.id)> <span>Delete User</span></button></td>" +
                            "<td style='display:none;'>" + myList[i].userType + "</td>" +
                            "</tr>";

                    table.innerHTML += row;
                }
                //console.log(data)
                // searchPageButtons()

                // checkEditAccess();
                // pageButtons(res.pages);
                $('.viewDetails').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    var usertype = currentRow.cells.item(17).innerHTML;
                    console.log(currentRow)
                    console.log("User " + usertype);
                    if (usertype == 2) {
                        // console.log("2  entered");
                        localStorage.setItem("userId", currentRow.cells.item(2).textContent);
                        window.open('vendorDetails.html');
                    } else if (usertype == 4) {
                        sessionStorage.setItem("userId", currentRow.cells.item(2).textContent);
                        window.open('employeeAccess.html');
                    } else if (usertype == 5) {
                        localStorage.setItem("zclid", trId);
                        localStorage.setItem("zclName", currentRow.cells.item(1).textContent);
                        window.open('getZclDetails.html', '_blank');

                    }
                });
                $('.addMoney').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    var headers = {
                        userid: trId,
                        user_type: currentRow.cells.item(17).textContent,
                        sessionkey: currentRow.cells.item(16).textContent
                    }
                    // sessionStorage.setItem("mUserId", trId);
                    // sessionStorage.setItem("mUserType", currentRow.cells.item(17).textContent);
                    // sessionStorage.setItem("mSessionKey", currentRow.cells.item(16).textContent);
                    // window.open('addMoney.html');
                    // document.getElementById("modal").style.display="block";
                    $("#modal").modal();

                    document.getElementById("userh3").innerHTML = trId;
                    console.log(headers.sessionkey);
                    // addMoney(c_amt, d_amt, o_id, headers);
                    document.getElementById("addMoneyBtn").onclick = function (event) {
                        event.preventDefault();
                        console.log(headers);
                        var d_amt = document.getElementById("debit_amt").value;
                        var c_amt = document.getElementById("credit_amt").value;
                        var o_id = document.getElementById("order_id").value;
                        console.log(d_amt, c_amt, o_id);
                        addMoney(c_amt, d_amt, o_id, headers);

                    }
                });
                $('.accounts').click(function () {
                    var $this = $(this);
                    //get the row element of the delete button
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    sessionStorage.setItem("phone", currentRow.cells.item(7).textContent);
                    window.open('otherAccounts.html');
                });
            })
            .catch(error => {
                // Do something for an error here
                console.log("error", error)
            })
}

// To Display Wallet Balance

function transactionList(id) {
    console.log(id)
    console.log(id.split("e", 3)[2])
    let row = document.getElementById(id.split("e", 3)[2]);
    console.log(row);
    sessionStorage.setItem("wUserId", row.cells[2].innerHTML);
    sessionStorage.setItem("wSessionkey", row.cells[16].innerHTML);
    sessionStorage.setItem("wUserType", document.getElementById("select").value);
    location.href = "transactionList";
}


// On Delete User Button  clicked

function delUser(userId) {
    console.log("usi" + userId.split);
    let row = document.getElementById(userId);
    console.log("Row " + row)
    console.log("user id " + userId);
    console.log("Data " + row.cells[2].innerHTML + " " + row.cells[7].innerHTML + " " + row.cells[17].innerHTML + " ");
    alert("Do you want to delete this user....!");
    console.log(id);
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");


    var urlencoded = new URLSearchParams();
    urlencoded.append("usertype", row.cells[17].innerHTML);
    urlencoded.append("user_id", userId);
    urlencoded.append("number", row.cells[7].innerHTML);

    console.log("Number " + row.cells[7].innerHTML);
    console.log("usertype " + row.cells[17].innerHTML);
    console.log("user_ids " + userId);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    fetch(deleteuser, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                if (result.status == 200) {
                    alert("Account Deleted");
                    location.reload();
                }
            })
            .catch(error => console.log('error', error));
}