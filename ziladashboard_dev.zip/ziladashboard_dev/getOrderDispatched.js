var ordersTodispatch = localStorage.getItem("ordersTodispatch");

console.log("ordersTodispatch:",ordersTodispatch);

function checkEditAccess() {
    /*
     var config = {
     apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
     authDomain: "zila-dashboard-access.firebaseapp.com",
     databaseURL: "https://zila-dashboard-access.firebaseio.com",
     storageBucket: "zila-dashboard-access.appspot.com",
     };
     
     firebase.initializeApp(config);
     */
    var userId = localStorage.getItem("userId");
    console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(12);//.orderByKey();


    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);
        var tble = document.getElementById("table");
        var row = tble.rows;

        if (!snapshot.val().edit) {

            for (var j = 0; j < row.length; j++) {

                // Deleting the "change-status" cell of each row. 
                row[j].deleteCell(12);
            }
        }
    })
}



function tobeDispatched() {
    var userId = localStorage.getItem("userId");

    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem("userId"));
    myHeaders.append("sessionkey", sessionStorage.getItem("sessionKey"));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", sessionStorage.getItem("user_type"));
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    console.log(sessionStorage.getItem("sessionKey"));
    console.log(sessionStorage.getItem("user_type"));
    console.log(localStorage.getItem("userId"));

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    // fetch("http://api.myzila.com/OrdersToDispatch?vendor_id="+userId, requestOptions)
    // .then(response => response.text())
    // .then(result => console.log(result))
    // .catch(error => console.log('error', error));

    var displayUrl = ordersTodispatch+"vendor_id=" + userId;

    fetch(displayUrl, requestOptions)
            .then(response => {
                return response.json()
            })
            .then(data => {

                document.getElementById("tableBody").innerHTML = '';
                for (var i = 0; i < data.data.length; i++) {
                    var obj = data.data[i];
                    var status = "";

                    switch (data.data[i].status)
                    {
                        case 0 :
                            status = "Not Known";
                            break;
                        case 1 :
                            status = "Placed";
                            break;
                        case 2 :
                            status = "Shipped";
                            break;
                        case 3 :
                            status = "Delivered";
                            break;
                        case 4 :
                            status = "Cancelled";
                            break;
                        case 5 :
                            status = "Request to return";
                            break;
                        case 6 :
                            status = "Returned";
                            break;
                        case 7 :
                            status = "Return request rejected";
                            break;
                        case 8 :
                            status = "Approve";
                            break;
                        case 9 :
                            status = "Returned";
                            break;
                        case 10 :
                            status = "No return";
                            break;
                    }
                    var check = "<input type='checkbox' class='check' id='check" + data.data[i].sold_product_id + "'>";
                    var st = " <div><select id=" + data.data[i].sold_product_id + " onchange=\"changeStatus(this.value,this.id, 0)\"  > <option value=" + 0 + ">Not Known</option> <option value=" + 1 + ">Placed</option> <option value=" + 2 + ">Shipped</option> <option value=" + 3 + ">Delivered</option> <option value=" + 4 + ">Cancelled</option> <option value=" + 5 + ">Request to return</option> <option value=" + 6 + ">Returned</option> <option value=" + 7 + ">Return request rejected</option> <option value=" + 8 + ">Approve</option> <option value=" + 9 + ">Retunred</option> <option value=" + 10 + ">No return</option> <option selected value=" + 11 + ">--Select--</option> </select> </div>  ";
                    var status = "<label> " + status + "  <label>";
                    var fprice = ((100 - parseFloat(data.data[i].offer_amount, 10)) / 100) * parseFloat(data.data[i].actual_amount, 10);
                    productId = obj.product_id;

                    var $tr = $("<tr>");

                    var $SNO = $("<td>");
                    var $NAME = $("<td>");
                    var $IMAGE = $("<td>");
                    var $ProdDetails = $("<td>");
                    var $PRICE = $("<td>");
                    var $FPRICE = $("<td>");
                    var $COLOR = $("<td>");
                    var $QUANTITY = $("<td>");
                    var $CreatedOn = $("<td>");
                    var $UpdatedOn = $("<td>");
                    var $ORDERID = $("<td>");
                    var $SHIP = $("<td>");
                    var $StatusString = $("<td id='orderStatusLabel" + obj.sold_product_id + "'>");
                    var $TPRICE = $("<td>");
                    var $STATUS = $("<td>");
                    var $GST = $("<td>");
                    var $SPRD_ID = $("<td>");
                    var $WAYBILL = $("<td>");
                    var $PAYSLIP = $("<td>");
                    var $CHECK = $("<td class='check'>");

                    var image = "<img src='" + obj.image + "' width='100' height='100'>"

                    var prodDetailsButton = "<button class='viewDetails' onclick='getdetails(" + productId + ")'>Click to view</button>";

                    var payMethod = 'Online'
                    if (obj.payment_method == 1)
                        payMethod = 'Cash'
                    var download = "<button class='downloadBtn' id='" + obj.waybill + "' onclick='getDelhivery(this.id)'>Download</button>";
                    var shipDetails = "<b>Address:</b> " + obj.address + "<br>" + "<b>Username:</b> " + obj.user_name + "<br>" + "<b>Payment method:</b> " + payMethod;
                    $SNO.append(i + 1);
                    $NAME.append(obj.name);
                    $IMAGE.append(image);
                    $ProdDetails.append("<br>" + prodDetailsButton);
                    $PRICE.append(obj.actual_amount);
                    $FPRICE.append(parseFloat(fprice, 10).toFixed(2));
                    $COLOR.append(obj.color);
                    $QUANTITY.append(obj.quantity);
                    $CreatedOn.append(obj.created_on);
                    $UpdatedOn.append(obj.updated_on);
                    $ORDERID.append(obj.order_id);
                    $SHIP.append(shipDetails);
                    $StatusString.append(status);
                    $STATUS.append(st);
                    $TPRICE.append(parseFloat(obj.trans_amt, 10).toFixed(2));
                    $GST.append(parseFloat(obj.gst_amt, 10).toFixed(2));
                    $SPRD_ID.append(obj.sold_product_id);
                    $WAYBILL.append(obj.waybill);
                    $PAYSLIP.append(download)
                    $CHECK.append(check);

                    $tr.append($SNO);
                    $tr.append($NAME);
                    $tr.append($IMAGE);
                    $tr.append($ProdDetails);
                    $tr.append($PRICE);
                    $tr.append($FPRICE);
                    $tr.append($COLOR);
                    $tr.append($QUANTITY);
                    $tr.append($CreatedOn);
                    $tr.append($UpdatedOn);
                    $tr.append($ORDERID);
                    $tr.append($SHIP);
                    $tr.append($StatusString);
                    $tr.append($STATUS);
                    $tr.append($TPRICE);
                    $tr.append($GST);
                    $tr.append($SPRD_ID);
                    $tr.append($WAYBILL);
                    $tr.append($PAYSLIP);
                    $tr.append($CHECK);

                    $('#tableBody').append($tr);
                }
                // searchPageButtons();

                checkEditAccess();
            })
            .catch(error => {
                console.log("error", error)
            })
}