var getOrderlist = localStorage.getItem("getOrderlist");

console.log("getOrderlist",getOrderlist);

var orders = [];
var pricexoffer = [];
var subtotals = [];
var offeramt = [];
var shipcharge = [];
var bogodiss = [];
//getOrderInfo();

// To get the details of the Orders

//function getOrderInfo() {
var myHeaders = new Headers();
myHeaders.append("userid", "1784");
myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
myHeaders.append("languagetype", "1");
myHeaders.append("usertype", "0");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

var id = localStorage.getItem('Order_Id');
console.log("iiiddd:", id);

fetch(getOrderlist+"order_id=" + id, requestOptions)
        .then(response => response.json())
        .then(result => {
            document.getElementById('invoice').style.visibility='hidden'
            console.log(result);
            console.log("Result Length:-", result.data.length);



            orders = result.data;
            var pay = document.getElementById("pay_method")
            var pay_data = result.data[0].payment_method;
            if (pay_data == 1) {
                pay.innerHTML = "Cash on Delivery"
            }else if (pay_data==3) {
                pay.innerHTML = "Online Payment"
            }else{
                pay.innerHTML = "Not properly mentioned"
            }
            var tabs = document.getElementById("orderInfo")
            tabs.innerHTML = ''
            for (var i = 0; i < orders.length; i++) {
                console.log("Result Amount:-" + i, result.data[i].actual_amount);
                var bogo = orders[i].bogo_discount;
                bogodiss.push(parseFloat(bogo));
                var bgo = 0;
                for (var b = 0; b < bogodiss.length; b++) {
                    bgo += bogodiss[b];
                }
                document.getElementById('bogo').innerHTML = " -" + bgo.toFixed(2);

                var custName = orders[i].user_name;
                document.getElementById('custName').innerHTML = custName;

                var custAdd = orders[i].address;
                document.getElementById('custAdd').innerHTML = custAdd;

                pricexoffer.push(parseFloat(orders[i].actual_amount) * (orders[i].quantity));
                var priceXoff = 0;
                for (var j = 0; j < pricexoffer.length; j++) {
                    priceXoff += pricexoffer[j];
                }
                document.getElementById('priceXOffer').innerHTML = priceXoff.toFixed(2);

                var ptotal = ((100 - orders[i].offer_amount) / 100) * (orders[i].actual_amount) * (orders[i].quantity);

                subtotals.push(parseFloat(ptotal));
                var sub_total = 0;
                for (var l = 0; l < subtotals.length; l++) {
                    sub_total += subtotals[l];
                }
                document.getElementById('subPrice').innerHTML = sub_total.toFixed(2);

                var discountedamt = (parseFloat(priceXoff) - parseFloat(sub_total))
                document.getElementById('dissPrice').innerHTML = " - " + discountedamt.toFixed(2);

                var ship = (parseFloat(orders[i].shipping_charges));
                document.getElementById('shippPrice').innerHTML = ship.toFixed(2);

                var promo = orders[i].promo_code;
                document.getElementById('promoUSed').innerHTML = promo;

                var promoamt = orders[i].promo_amt;
                document.getElementById('promoAmt').innerHTML = " - " + promoamt.toFixed(2);

                var discountAmtt = (parseFloat(discountedamt) + parseFloat(promoamt) + parseFloat(bgo));
                var dissamountsss = parseFloat(discountAmtt);
                document.getElementById('discountAmt').innerHTML = dissamountsss.toFixed(2);

                var inno = orders[i].order_id;
                document.getElementById('invoiceno').innerHTML = inno;

                var datetime = orders[i].updated_on;
                document.getElementById('invoicedate').innerHTML = datetime;

                var grandtotal = localStorage.getItem('Grand_Total')
                var gran = parseFloat(grandtotal);
                document.getElementById('grandTotal').innerHTML = gran.toFixed(2);

                var wallet = localStorage.getItem('Wallet_balance')
                document.getElementById('walletAmt').innerHTML = wallet;

                var wallet = localStorage.getItem('Wallet_balance')
                var wall = parseFloat(wallet);
                document.getElementById('walletAmt').innerHTML = " - " + wall.toFixed(2);

                var zclnme = localStorage.getItem('Store_Name')
                document.getElementById('zclName').innerHTML = zclnme;

                var zcladd = localStorage.getItem('Store_Location')
                document.getElementById('zclAdd').innerHTML = zcladd;

                var zclstate = zcladd.split(" ");
                zclstate = zclstate[zclstate.length - 3];
                document.getElementById("zclState").innerHTML = zclstate;

                var zclcity = zcladd.split(" ");
                zclcity = zclcity[zclcity.length - 4];
                document.getElementById("zclCity").innerHTML = zclcity;

                var zclphone = zcladd.split(" ");
                zclphone = zclphone[zclphone.length - 1];
                document.getElementById("zclPhone").innerHTML = zclphone;

                var custstate = custAdd.split(",");
                custstate = custstate[custstate.length - 2];
                document.getElementById("custstate").innerHTML = custstate;

                var custcity = custAdd.split(",");
                custcity = custcity[custcity.length - 3];
                document.getElementById("custCity").innerHTML = custcity;

                var custpin = custAdd.split(",");
                custpin = custpin[custpin.length - 1];
                document.getElementById("custPin").innerHTML = custpin;

                var custpho = custAdd.split(",")
                var custphone = custpho[1].split(" ")[1];
                document.getElementById("custPhone").innerHTML = custphone;


                

                var sno = i + 1;
                if (orders[i].group_message != null && orders[i].group_message != '' && orders[i].group_message != 'NA'){
                    var nam = orders[i].name +"<br><b>message :"+orders[i].group_message;
                }
                else{
                    var nam = orders[i].name;
                }

                document.getElementById("invoice").style.visibility = 'visible';
                document.getElementById("load").style.visibility='hidden';

                console.log('g_m',orders[i].name);
                var row = "<tr id='" + orders[i].order_id + "'>" +
                        "<td>" + sno + "</td>" +
                        "<td>" + orders[i].sold_product_id + "</td>" +
                        "<td>" + nam+ "</td>" +
                        "<td>" + orders[i].actual_amount + "</td>" +
                        "<td>" + orders[i].quantity + "</td>" +
                        "<td>" + orders[i].offer_amount + "</td>" +
                        "<td>" + ptotal.toFixed(2) + "</td>" +
                        "<tr>";
                tabs.innerHTML += row;
            }

            if (bgo == parseFloat(0.0)) {
                document.getElementById('bogo').style.display = "none";
                document.getElementById('bog').style.display = "none";
            } else {
                document.getElementById('bogo').style.display = "block";
                document.getElementById('bog').style.display = "block";
            }
        })
