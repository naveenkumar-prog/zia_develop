var pastLiveStats = firebase.initializeApp({
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-influencerlive.firebaseapp.com",
    databaseURL: "https://zila-android-influencerlive.firebaseio.com",
    //projectId: "zila-android",
    storageBucket: "zila-android-influencerlive.appspot.com",
    //messagingSenderId: "628597092757",
    //appId: "1:628597092757:android:8b4de02ddb17655c8d869c",
}, 'pastLiveStatistics');

const divObj = document.getElementById("myTable");
/*
 const dbRefObj = firebase.database().ref();//.child('361');
 const dbRefList = dbRefObj.child('name');
 
 dbRefObj.on('value', snap => {
 //var obj =  JSON.parse(JSON.stringify(snap.val()));   
 console.log(snap.val());
 divObj.innerText = JSON.stringify(snap.val(), null, 3);
 });
 /*
 dbRefList.on('value', snap => {
 console.log(snap.val());
 list.innerText = JSON.stringify(snap.val(), null, 3);
 })
 */

var userDataRef = pastLiveStats.database().ref().child("NewStat");//.orderByKey();
var count = 0;
userDataRef.on("value", function (snapshot) {
    divObj.innerHTML = ''
    count = 0
    snapshot.forEach(function (childSnapshot) {

        var rootKey = childSnapshot.key;
        var childData = childSnapshot.val();
        console.log(childData);
        var key = Object.keys(childSnapshot.val());
        for (i in key) {

            count++;
            var sno = count
            var name = childData[key[i]].name;
            // console.log(childData[key[i]]);
            var sellerId = childData[key[i]].seller_id;
            //var thumbnail = "<img src='"+ childData[key[i]].thumbnail +"' class='thumbnail'>";

            var prodId = []
            var length = 0;
            for (j in childData[key[i]].product_id) {
                length++;
                prodId.push(childData[key[i]].product_id[j]);
            }

            var listProd = "<div id='listOfProducts" + key[i] + "'>" + prodId + "</div>"

            var emojiCounts = ''
            var lengthEmojis = 0;
            for (j in childData[key[i]].React) {
                if (j == "ReactBy") {
                    emojiCounts += "<b>" + j + ":</b> \n";
                    continue;
                }
                lengthEmojis++;
                emojiCounts += "<b>" + j + ":</b> " + childData[key[i]].React[j]['total_count'] + "<br>";
                // console.log(Object.keys(childData[key[i]].React[j]))
            }

            var chatMessages = ''
            var lengthChat = 0;
            for (j in childData[key[i]].ChatMessages) {
                lengthChat++;
                chatMessages += "<b>" + j + ":</b> " + childData[key[i]].ChatMessages[j] + "<br>";
            }

            var views = []
            // var lengthViews = 0;
            // for(j in childData[key[i]].ViewCount){
            //     lengthViews++;
            views.push(childData[key[i]].ViewCount['total_count']);
            // console.log(views)
            // }

            var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                    "<td>" + sno + "</td>" +
                    "<td>" + name + "</td>" +
                    "<td>" + sellerId + "</td>" +
                    "<td>" + listProd + "</td>" +
                    "<td>" + emojiCounts + "</td>" +
                    "<td>" + chatMessages + "</td>" +
                    "<td>" + views + "</td>" +
                    "</tr>";

            divObj.innerHTML += row;
        }

        /*
         $('.editbtn').click(function() {
         var $this = $(this);
         //get the row element of the edit button
         var trId = $(this).closest('tr').prop('id');
         var currentRow = document.getElementById(trId);
         
         //get the <td> elements of the selected row that can be edited
         var tds = $this.closest('tr').find('.canEdit').filter(function() {
         return $(this).find('.editbtn').length === 0;
         });
         
         if ($this.html() === 'Edit') {
         $this.html('Save');
         //make <td> elements of that row editable
         tds.prop('contenteditable', true);
         currentRow.classList.add('currRowEdit');  
         } else {
         $this.html('Edit');
         tds.prop('contenteditable', false);
         currentRow.classList.remove('currRowEdit');
         var allotTime = currentRow.cells.item(5).textContent
         updateLiveStream(trId, currentRow.className, allotTime)
         }
         });
         
         $('.delbtn').click(function() {
         var $this = $(this);
         //get the row element of the delete button
         var trId = $(this).closest('tr').prop('id');
         var currentRow = document.getElementById(trId);
         
         var retVal = confirm("Do you want to remove this video?");
         if(retVal == true) {
         deleteVideo(trId, currentRow.className)
         currentRow.style.display = 'none';
         } 
         });
         */
    });
});
/*
 function changeStatus(timeStamp, userId, newStatus){
 var ref = userDataRef.child(userId).child(timeStamp);
 ref.once("value", function(snapshot) {
 var rootKey = snapshot.key;
 var childData = snapshot.val();
 var oldStatus = childData.status;
 //console.log(rootKey) //same as timestamp
 var obj = {"status" : newStatus, "old-status" : oldStatus};
 ref.update(obj);
 })
 }
 
 function updateLiveStream(timeStamp, userId, newAllotTime){
 var ref = userDataRef.child(userId).child(timeStamp);
 ref.once("value", function(snapshot) {
 var rootKey = snapshot.key;
 var childData = snapshot.val();
 //console.log(rootKey) //same as timestamp
 var obj = {"allot_time" : newAllotTime};
 ref.update(obj);
 //console.log(childData.allot_time);
 })
 }
 
 function addProduct(productId, divId){
 var divElem = document.getElementById(divId);
 divElem.innerHTML += ',' + productId;
 }
 
 function updateProductList(timeStamp, userId, productIdList){
 var ref = userDataRef.child(userId).child(timeStamp);
 ref.once("value", function(snapshot) {
 var rootKey = snapshot.key;
 var childData = snapshot.val();
 //console.log(rootKey) //same as timestamp
 var childRef = ref.child("product_id");
 childRef.once("value", function(childSnapshot){
 console.log(productIdList);
 var numberOfProducts = productIdList.length;
 for(var i = 1; i < numberOfProducts+1; i++){
 var product = "product"+i;
 var j;
 if(productIdList[0]==""){
 j = i;
 } else {
 j = i-1;
 }
 var prod = {[product] : productIdList[j]};
 childRef.update(prod);
 }
 })
 alert("Product list updated");
 })
 }
 
 function deleteVideo(timeStamp, userId){
 var ref = userDataRef.child(userId).child(timeStamp);
 ref.remove();
 alert("Video deleted");
 }
 */