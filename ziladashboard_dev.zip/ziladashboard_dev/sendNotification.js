// OnClick Send Now Button   

var sendNotification = localStorage.getItem("sendNotification");

console.log("sendNotification",sendNotification);

function sendNotif() {
    var notif_title = document.getElementById("notifTitle").value;
    var notif_topic = document.getElementById("notifTopic").value;
    var notif_body = document.getElementById("notifBody").value;
    var notif_image = document.getElementById("notifImage").value;
    if (notif_title == "" || notif_topic == "" || notif_body == "" || notif_image == "") {
        alert("Please fill in all the fields");
    } else {
        var myHeaders = new Headers();
        myHeaders.append("userid", "1784");
        myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
        myHeaders.append("languagetype", "1");
        myHeaders.append("usertype", "0");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

        var formdata = new FormData();
        formdata.append("topic", notif_topic);
        formdata.append("body_notification", notif_body);
        formdata.append("title_notification", notif_title);
        formdata.append("image", notif_image);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };

        // const proxyurl = "https://cors-anywhere.herokuapp.com/";

        fetch(sendNotification, requestOptions)   // To fetch the notification to database
                .then(response => response.json())
                .then(result => {
                    console.log(result);
                    alert("Notification sent");
                })
                .catch(error => {
                    console.log('error', error);
                    alert("Could not send notification!");
                });
    }
}