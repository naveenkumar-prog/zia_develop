var getTask = localStorage.getItem("getTask");
var updateTask = localStorage.getItem("updateTask");
var getOrderlist = localStorage.getItem("getOrderlist");

console.log("getOrderlist",getOrderlist);
console.log("updateTask",updateTask);
console.log("getTask:",getTask);

var tasks = []

var pageNum = 0;

// To display page buttons at footer

function pageButtons(numTask, id) {
    var wrapper = document.getElementById('pagination-wrapper')
    wrapper.innerHTML = ''
    var maxLeft = (pageNum - 2)
    var maxRight = (pageNum + 2)
    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = 5
    }
    var numberOfPages = Math.ceil(numTask / 10);
    totalPages = numberOfPages;
    if (maxRight > numberOfPages) {
        maxLeft = numberOfPages - 5
        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = numberOfPages
    }
    var wrapper = document.getElementById("pagination-wrapper");
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += "<button value='" + page + "' class='page btn btn-sm btn-info'>" + page + "</button>"
    }
    if (pageNum != 0) {
        wrapper.innerHTML = "<button value='1' class='page btn btn-sm btn-info'>&#171; First</button>" + wrapper.innerHTML
    }
    $('.page').on('click', function () {
        $('#tableBody').empty()
        pageNum = Number($(this).val()) - 1;
        fetchTasks(numTask);
    })
}

var searchpageNum = 0;

// To display page buttoms according to the search

function searchpageButtons(numTask, tasks) {
    var wrapper = document.getElementById('pagination-wrapper')
    wrapper.innerHTML = ''
    var maxLeft = (searchpageNum - 2)
    var maxRight = (searchpageNum + 2)
    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = 5
    }
    var numberOfPages = Math.ceil(numTask / 10);
    totalPages = numberOfPages;
    if (maxRight > numberOfPages) {
        maxLeft = numberOfPages - 5
        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = numberOfPages
    }
    var wrapper = document.getElementById("pagination-wrapper");
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += "<button value='" + page + "' class='page btn btn-sm btn-info'>" + page + "</button>"
    }
    if (searchpageNum != 0) {
        wrapper.innerHTML = "<button value='1' class='page btn btn-sm btn-info'>&#171; First</button>" + wrapper.innerHTML
    }
    if (searchpageNum != numberOfPages) {
        wrapper.innerHTML += "<button value='" + numberOfPages + "' class='page btn btn-sm btn-info'>Last &#187;</button>"
    }
    $('.page').on('click', function () {
        $('#tableBody').empty()
        searchpageNum = Number($(this).val()) - 1
        fetchData(id, tasks);
    })
}

const getTaskUrl = getTask+"store_id=";

//  Onclick search button

function searchButton() {
    var val = document.getElementById("inputId").value
    fetchData(val)
}

$('#inputId').keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
        var val = document.getElementById("inputId").value
        fetchData(val)
    }
});

// On change the current status
function changeStatus(status, storeTaskId) {
    //console.log(status, storeTaskId)
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    var urlencoded = new URLSearchParams();
    urlencoded.append("status", status);
    urlencoded.append("store_task_id", storeTaskId);
    urlencoded.append("task_date", "2020-05-31 00:00:00");
    urlencoded.append("close_order_time", "2020-05-31 00:00:00");
    urlencoded.append("cancel_reason", "");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };
    fetch(updateTask, requestOptions)
            .then(response => response.text())
            .then(result => {
                console.log(result)
                //$("#tableBody").load(" #tableBody > *");
                searchButton()
            })
            .catch(error => console.log('error', error));
}

// To fetch the details from api

function getdetails(order_id) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };
    fetch(getOrderlist+"order_id=" + order_id, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                displayDetails(result.data);
            })
            .catch(error => console.log('error', error));
}

// To display details

function displayDetails(orders)
{
    document.getElementById('popup').style.display = 'block';
    //var elem = document.getElementById('data');
    var tab = document.getElementById("orderDetailsTable");
    tab.innerHTML = '';

    for (var i = 0; i < orders.length; i++) {
        var sno = i + 1;
        var tr = "<tr>" +
                "<td>" + sno + "</td>" +
                "<td>" + orders[i].name + "</td>" +
                "<td><img src='" + orders[i].image + "' class='orderImage'></td>" +
                "<td>" + orders[i].order_no + "</td>" +
                "<td>" + orders[i].product_id + "</td>" +
                "<td>" + orders[i].actual_amount + "</td>" +
                "<td>" + orders[i].offer_amount + "</td>" +
                "<td>" + orders[i].quantity + "</td>" +
                "</tr>";

        tab.innerHTML += tr;
    }
    document.getElementById('popup').classList.add('stick');
    document.getElementById("tasksContent").classList.add("hideOverflow");
}

fetchTasks();

// To fetch data according to search

function fetchTasks(numTask) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };
    fetch(getTask+"store_id=1959&page=" + pageNum + "&showall=1", requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result);
                tasks = result.data;
                tasks = result.data
                var tab = document.getElementById("tableBody")
                tab.innerHTML = ''
                for (var i = 0; i < tasks.length; i++) {
                    if (tasks[i].payment_method == 1)
                        payMethod = "Cash"
                    else
                        payMethod = "Online"
                    if (tasks[i].mode == 1)
                        modeDel = "Delivery"
                    else
                        modeDel = "Pickup"
                    var status
                    if (tasks[i].status == 1) {
                        status = "Delivered"
                    } else if (tasks[i].status == 2) {
                        status = "In-transit"
                    } else if (tasks[i].status == 3) {
                        status = "Pending"
                    } else if (tasks[i].status == 4) {
                        status = "Cancelled"
                    } else if (tasks[i].status == 5) {
                        status = "To-deliver"
                    }
                    var sno = i + 1
                    var shipDetails = "<b>Address:</b> " + tasks[i].address + "<br><b>Name:</b> " + tasks[i].name + "<br><b>Payment method:</b> " + payMethod + "<br><b>User id:</b> " + tasks[i].user_id;

                    var change = "<select onchange=\"changeStatus(this.value,'" + tasks[i].store_task_id + "')\">" +
                            "<option value='select'>--Select--</option>" +
                            "<option value='1'>Delivered</option>" +
                            "<option value='2'>In-transit</option>" +
                            "<option value='3'>Pending</option>" +
                            "<option value='4'>Cancel</option>" +
                            "<option value='5'>To deliver</option>" +
                            "</select>"
                    var row = "<tr id='" + tasks[i].order_id + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td>" + tasks[i].task_date + "</td>" +
                            "<td><img src='" + tasks[i].image + "' class='taskImage'></td>" +
                            "<td>" + tasks[i].order_id + "</td>" +
                            "<td>" + tasks[i].store_name + "</td>" +
                            "<td>" + tasks[i].store_loc + "</td>" +
                            "<td>" + status + "</td>" +
                            "<td>" + change + "</td>" +
                            "<td>" + tasks[i].verification_code + "</td>" +
                            "<td>" + shipDetails + "</td>" +
                            "<td><button class='viewDetails'><span>View</span></button></td>" +
                            "<td>" + modeDel + "</td>" +
                            "<td>" + tasks[i].total_amount + "<br><b>Final amount: </b>" + tasks[i].final_amount + "<br><b>To pay: </b>" + tasks[i].topay + "<br><b>Wallet bal used: </b>" + tasks[i].wallet_bal_used + "</td>" +
                            "<td>" + tasks[i].commision + "</td>" +
                            "<td>" + tasks[i].close_order_time + "</td>" +
                            "<td>" + tasks[i].cancel_reason + "</td>" +
                            //"<td><button class='btn btn-info downloadBtn' data-topay='"+tasks[i].topay+"' data-wallet='"+tasks[i].wallet_bal_used+"'>Download</button></td>"+
                            "<td><button class='btn btn-info veiwInvoice' data-topay='" + tasks[i].topay + "' data-wallet='" + tasks[i].wallet_bal_used + "'>View Invoice</button></td>" +
                            "</tr>";
                    tab.innerHTML += row;
                }

                // Onclick view

                $('.viewDetails').click(function () {
                    var $this = $(this);
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    getdetails(trId);
                });

                // Onclick View Invoice

                $('.veiwInvoice').click(function () {
                    var $this = $(this);
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    var orderids = currentRow.cells.item(3).innerHTML;
                    var storeName = currentRow.cells.item(4).textContent;
                    var storeLocation = currentRow.cells.item(5).textContent;
                    var wallet_balance_used = $(this).attr("data-wallet");
                    var topay = $(this).attr("data-topay");
                    localStorage.setItem("Order_Id", orderids);
                    localStorage.setItem("Store_Name", storeName);
                    localStorage.setItem("Store_Location", storeLocation);
                    localStorage.setItem("Wallet_balance", wallet_balance_used);
                    localStorage.setItem("Grand_Total", topay);
                    console.log("Order_id " + orderids);
                    console.log("Store_Name " + storeName);
                    console.log("Store_Location " + storeLocation);
                    console.log("Wallet_balance " + wallet_balance_used);
                    console.log("Grand_Total " + topay);
                    getOrderinfos();
                })
                // $('.downloadBtn').click(function(){
                //     var $this = $(this);
                //     var trId = $(this).closest('tr').prop('id');
                //     var currentRow = document.getElementById(trId);
                //     var storeName = currentRow.cells.item(4).textContent;
                //     var storeLocation = currentRow.cells.item(5).textContent;
                //     var wallet_balance_used = $(this).attr("data-wallet");
                //     var topay = $(this).attr("data-topay");
                //     //console.log(wallet_balance_used, topay);
                //     getOrderDetails(trId,storeName,storeLocation, topay, wallet_balance_used);          
                // });
                //checkEditAccess();
                pageButtons(numTask);
            })
            .catch(error => console.log('error1', error));
}

function fetchData(id, tasks) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };
    fetch(getTask+"store_id=" + id + "&page=" + searchpageNum, requestOptions)
            .then(response => response.json())
            .then(result => {
                tasks = result.data
                if (tasks.length == 0) {
                    alert("No tasks!");
                } else {
                    document.getElementById("store-name").innerHTML = "Store name: " + tasks[0].store_name;
                }
                var tab = document.getElementById("tableBody")
                tab.innerHTML = ''
                for (var i = 0; i < tasks.length; i++) {
                    if (tasks[i].payment_method == 1)
                        payMethod = "Cash"
                    else
                        payMethod = "Online"
                    if (tasks[i].mode == 1)
                        modeDel = "Delivery"
                    else
                        modeDel = "Pickup"
                    var status
                    if (tasks[i].status == 1) {
                        status = "Delivered"
                    } else if (tasks[i].status == 2) {
                        status = "In-transit"
                    } else if (tasks[i].status == 3) {
                        status = "Pending"
                    } else if (tasks[i].status == 4) {
                        status = "Cancelled"
                    } else if (tasks[i].status == 5) {
                        status = "To-deliver"
                    }
                    var sno = i + 1
                    var shipDetails = "<b>Address:</b> " + tasks[i].address + "<br><b>Name:</b> " + tasks[i].name + "<br><b>Payment method:</b> " + payMethod + "<br><b>User id:</b> " + tasks[i].user_id;

                    var change = "<select onchange=\"changeStatus(this.value,'" + tasks[i].store_task_id + "')\">" +
                            "<option value='select'>--Select--</option>" +
                            "<option value='1'>Delivered</option>" +
                            "<option value='2'>In-transit</option>" +
                            "<option value='3'>Pending</option>" +
                            "<option value='4'>Cancel</option>" +
                            "<option value='5'>To deliver</option>" +
                            "</select>"
                    var row = "<tr id='" + tasks[i].order_id + "'>" +
                            "<td>" + sno + "</td>" +
                            "<td>" + tasks[i].task_date + "</td>" +
                            "<td><img src='" + tasks[i].image + "' class='taskImage'></td>" +
                            "<td>" + tasks[i].order_id + "</td>" +
                            "<td>" + tasks[i].store_name + "</td>" +
                            "<td>" + tasks[i].store_loc + "</td>" +
                            "<td>" + status + "</td>" +
                            "<td>" + change + "</td>" +
                            "<td>" + tasks[i].verification_code + "</td>" +
                            "<td>" + shipDetails + "</td>" +
                            "<td><button class='viewDetails'><span>View</span></button></td>" +
                            "<td>" + modeDel + "</td>" +
                            "<td>" + tasks[i].total_amount + "<br><b>Final amount: </b>" + tasks[i].final_amount + "<br><b>To pay: </b>" + tasks[i].topay + "<br><b>Wallet bal used: </b>" + tasks[i].wallet_bal_used + "</td>" +
                            "<td>" + tasks[i].commision + "</td>" +
                            "<td>" + tasks[i].close_order_time + "</td>" +
                            "<td>" + tasks[i].cancel_reason + "</td>" +
                            //"<td><button class='btn btn-info downloadBtn' data-topay='"+tasks[i].topay+"' data-wallet='"+tasks[i].wallet_bal_used+"'>Download</button></td>"+
                            "<td><button class='btn btn-info veiwInvoice' data-topay='" + tasks[i].topay + "' data-wallet='" + tasks[i].wallet_bal_used + "'>View Invoice</button></td>" +
                            "</tr>";
                    tab.innerHTML += row;
                }
                $('.viewDetails').click(function () {
                    var $this = $(this);
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    getdetails(trId);
                });
                $('.veiwInvoice').click(function () {
                    var $this = $(this);
                    var trId = $(this).closest('tr').prop('id');
                    var currentRow = document.getElementById(trId);
                    var orderids = currentRow.cells.item(3).innerHTML;
                    var storeName = currentRow.cells.item(4).textContent;
                    var storeLocation = currentRow.cells.item(5).textContent;
                    var wallet_balance_used = $(this).attr("data-wallet");
                    var topay = $(this).attr("data-topay");
                    localStorage.setItem("Order_Id", orderids);
                    localStorage.setItem("Store_Name", storeName);
                    localStorage.setItem("Store_Location", storeLocation);
                    localStorage.setItem("Wallet_balance", wallet_balance_used);
                    localStorage.setItem("Grand_Total", topay);
                    console.log("Order_id " + orderids);
                    console.log("Store_Name " + storeName);
                    console.log("Store_Location " + storeLocation);
                    console.log("Wallet_balance " + wallet_balance_used);
                    console.log("Grand_Total " + topay);
                    getOrderinfos();
                })
                // $('.downloadBtn').click(function(){
                //     var $this = $(this);
                //     var trId = $(this).closest('tr').prop('id');
                //     var currentRow = document.getElementById(trId);
                //     var storeName = currentRow.cells.item(4).textContent;
                //     var storeLocation = currentRow.cells.item(5).textContent;
                //     var wallet_balance_used = $(this).attr("data-wallet");
                //     var topay = $(this).attr("data-topay");
                //     //console.log(wallet_balance_used, topay);
                //     getOrderDetails(trId,storeName,storeLocation, topay, wallet_balance_used);          
                // });
                //checkEditAccess();
            })
            .catch(error => console.log('error1', error));
}

function checkEditAccess() {
    var userId = localStorage.getItem("userId");
    console.log(userId);
    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(17);//.orderByKey();
    userDataRef.on("value", function (snapshot) {
        //console.log(snapshot.val().view);
        var tble = document.getElementById("table");
        var row = tble.rows;
        if (!snapshot.val().edit) {
            for (var j = 0; j < row.length; j++) {
                // Deleting the "change-status" cell of each row. 
                row[j].deleteCell(7);
            }
        }
    })
}

function changeDisplay() {
    document.getElementById('popup').classList.remove('stick');
    document.getElementById("tasksContent").classList.remove('hideOverflow');
    document.getElementById('popup').style.display = 'none';
}

function getOrderinfos() {
    window.open("getOrderInfo.html", "_blank");
}