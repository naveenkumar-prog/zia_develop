function formatList(str) {
    var d = '';
    for (var i = 0; i < str.length; i++) {
        if (str.charAt(i) == '@' && str.charAt(i + 1) == '@') {
            var s = '';
            i += 2;
            for (j = i; j < str.length; j++) {
                if (str.charAt(j) == '@') {
                    if (str.charAt(j + 1) == '@') {
                        i = j + 1;
                        break;
                    } else
                        s += str.charAt(j);
                } else
                    s += str.charAt(j);
            }
            d += "<li>" + s + "</li>";
        } else
            d += str.charAt(i);
    }
    return formatItalics(d);
}

function formatItalics(str) {
    var d = '';
    for (var i = 0; i < str.length; i++) {
        if (str.charAt(i) == '/') {
            if (str.charAt(i + 1) == '/') {
                var s = '';
                i += 2;
                for (j = i; j < str.length; j++) {
                    if (str.charAt(j) == '/') {
                        if (str.charAt(j + 1) == '/') {
                            i = j + 1;
                            break;
                        } else
                            s += str.charAt(j);
                    } else
                        s += str.charAt(j);
                }
                d += s.italics()
            } else
                d += str.charAt(i);
        } else
            d += str.charAt(i);
    }
    return formatItalics(d);
}
console.log("cc")
function formatItalics(str) {
    // console.log(str)
    var d = '';
    for (var i = 0; i < str.length; i++) {
        if (str.charAt(i) == '/') {
            if (str.charAt(i + 1) == '/') {
                var s = '';
                i += 2;
                for (j = i; j < str.length; j++) {
                    if (str.charAt(j) == '/') {
                        if (str.charAt(j + 1) == '/') {
                            i = j + 1;
                            break;
                        } else
                            s += str.charAt(j);
                    } else
                        s += str.charAt(j);
                }
                d += s.italics()
            } else
                d += str.charAt(i);
        } else
            d += str.charAt(i);
    }
    return formatNewLine(d);
}

function formatNewLine(str) {
    var d = '';
    for (var i = 0; i < str.length; i++) {
        if (str.charAt(i) == '&' && str.charAt(i + 1) == '&') {
            d += "<br>";
            i++;
        } else
            d += str.charAt(i);
    }
    return d;
}

function formatDesc(str) {
    var d = '';
    for (var i = 0; i < str.length; i++) {
        if (str.charAt(i) == '*') {
            if (str.charAt(i + 1) == '*') {
                var s = '';
                i += 2;
                for (j = i; j < str.length; j++) {
                    if (str.charAt(j) == '*') {
                        if (str.charAt(j + 1) == '*') {
                            i = j + 1;
                            break;
                        } else
                            s += str.charAt(j);
                    } else
                        s += str.charAt(j);
                }
                d += s.bold()
            } else
                d += str.charAt(i);
        } else
            d += str.charAt(i);
    }
    return formatList(d);
}