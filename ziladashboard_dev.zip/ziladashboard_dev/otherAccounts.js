// Js File to dispally Other account that user have based on Phone number  

var getUsers = localStorage.getItem("getUsers");
var addWalletMoney = localStorage.getItem("addMoney");

var myHeaders = new Headers();
myHeaders.append("userid", "3513");
myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
myHeaders.append("languagetype", "1");
myHeaders.append("usertype", "2");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
// myHeaders.append("Cookie", "ci_session=05hs6nu0kgvknnom0r3gtiu6nm5pd787");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

// const proxyurl = "https://cors-anywhere.herokuapp.com/";
const url = getUsers+"phone=" + sessionStorage.getItem("phone");

fetch(url, requestOptions)
        .then(response => response.json())
        .then(result => {
            var tab = document.getElementById("tableBody");
            var myList = result.data;
            var userType;

            console.log(myList);
            for (var i = 0; i < myList.length; i++) {
                // var sno = i+1
                switch (myList[i].userType) {
                    case "0" :
                        userType = "Admin";
                        break;
                    case "1" :
                        userType = "Seller";
                        break;
                    case "2" :
                        userType = "Vendor";
                        break;
                    case "3" :
                        userType = "User";
                        break;
                    case "4" :
                        userType = "Employee";
                        break;
                    case "5" :
                        userType = "Community Leader";
                        break;

                }
                var row = "<tr id='" + myList[i].userId + "'>" +
                        "<td>" + userType + "</td>" +
                        "<td>" + myList[i].name + "</td>" +
                        "<td>" + myList[i].userId + "</td>" +
                        "<td>" + myList[i].username + "</td>" +
                        "<td>" + myList[i].email + "</td>" +
                        "<td>" + myList[i].wallet_balance + "</td>" +
                        "<td>" + myList[i].primary_address + "</td>" +
                        "<td>" + myList[i].phone + "</td>" +
                        "<td><button class='viewDetails'><span>View</span></button></td>" +
                        "<td>" + myList[i].deviceType + "</td>" +
                        "<td>" + myList[i].createdOn + "</td>" +
                        "<td>" + myList[i].updatedOn + "</td>" +
                        "<td>" + myList[i].lang + "</td>" +
                        "<td>" + myList[i].isactive + "</td>" +
                        "<td><button class='addMoney'><span>Add Money</span></button></td>" +
                        "<td style='display:none'>" + myList[i].sessionKey + "</td>" +
                        "<td style='display:none'>" + myList[i].userType + "</td>" +
                        "</tr>";

                tab.innerHTML += row;
            }
        }).then(result => {
    $('.addMoney').click(function () {
        var $this = $(this);
        //get the row element of the delete button
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);
        var headers = {
            userid: trId,
            user_type: currentRow.cells.item(16).textContent,
            sessionkey: currentRow.cells.item(15).textContent
        }
        // sessionStorage.setItem("mUserId", trId);
        // sessionStorage.setItem("mUserType", currentRow.cells.item(17).textContent);
        // sessionStorage.setItem("mSessionKey", currentRow.cells.item(16).textContent);
        // window.open('addMoney.html');
        // document.getElementById("modal").style.display="block";
        $("#modal").modal();

        document.getElementById("userh3").innerHTML = trId;
        console.log(headers.sessionkey);
        // addMoney(c_amt, d_amt, o_id, headers);
        document.getElementById("addMoneyBtn").onclick = function (event) {
            event.preventDefault();
            console.log(headers);
            var d_amt = document.getElementById("debit_amt").value;
            var c_amt = document.getElementById("credit_amt").value;
            var o_id = document.getElementById("order_id").value;
            console.log(d_amt, c_amt, o_id);
            addMoney(c_amt, d_amt, o_id, headers);

        }
    });
})
        .catch(error => console.log('error', error));


function addMoney(credit_amt, debit_amt, order_id, headers) {
    console.log(headers);
    var myHeaders = new Headers();
    myHeaders.append("userid", headers.userid);
    myHeaders.append("sessionkey", headers.sessionkey);
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", headers.user_type);
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    // myHeaders.append("Cookie", "ci_session=05hs6nu0kgvknnom0r3gtiu6nm5pd787");
    console.log(headers.userid);

    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var urlencoded = new URLSearchParams();
    urlencoded.append("credit_amt", credit_amt);
    urlencoded.append("debit_amt", debit_amt);
    urlencoded.append("transaction_date", dateTime);
    urlencoded.append("description", order_id);

    console.log(urlencoded);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
   // const url = "http://api.myzila.com/AddWalletMoney";

    fetch(addWalletMoney, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                console.log(result.status);
                if (result.status == 200) {
                    alert("Money added successfully!");
                }
            })
            .catch(error => console.log('error', error));
}




