// Firebase Data Connection

var liveVid = firebase.initializeApp({
    apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
    authDomain: "zila-android-influencerlive.firebaseapp.com",
    databaseURL: "https://zila-android-influencerlive.firebaseio.com",
    //projectId: "zila-android",
    storageBucket: "zila-android-influencerlive.appspot.com",
    //messagingSenderId: "628597092757",
    //appId: "1:628597092757:android:8b4de02ddb17655c8d869c",
}, "liveVideos");

const divObj = document.getElementById("myTable");
/*
 const dbRefObj = firebase.database().ref();//.child('361');
 const dbRefList = dbRefObj.child('name');
 
 dbRefObj.on('value', snap => {
 //var obj =  JSON.parse(JSON.stringify(snap.val()));   
 console.log(snap.val());
 divObj.innerText = JSON.stringify(snap.val(), null, 3);
 });
 /*
 dbRefList.on('value', snap => {
 console.log(snap.val());
 list.innerText = JSON.stringify(snap.val(), null, 3);
 })
 */

console.log('xxd');



var userDataRef = liveVid.database().ref().child("Live");//.orderByKey();
var count = 0;
userDataRef.on("value", function (snapshot) {
    divObj.innerHTML = ''
    count = 0
    var rootKey = snapshot.key;
    var childData = snapshot.val();


    var key = Object.keys(snapshot.val());

    for (i in key) {

        count++;
        var sno = count
        var allotTime = childData[key[i]].allot_time;
        var name = childData[key[i]].name;
        var sellerId = childData[key[i]].seller_id;
        var timeStamp = childData[key[i]].time;
        var thumbnail = "<img src='" + childData[key[i]].thumbnail + "' class='thumbnail'>";

        var prodId = []
        var length = 0;
        for (j in childData[key[i]].product_id) {
            length++;
            prodId.push(childData[key[i]].product_id[j]);
        }

        var listProd = "<div id='listOfProducts" + key[i] + "'><b>Product Ids: </b>" + prodId + "</div>"

        var row = "<tr id='" + key[i] + "' class='" + rootKey + "'>" +
                "<td>" + sno + "</td>" +
                "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                "<td>" + thumbnail + "</td>" +
                "<td>" + name + "</td>" +
                "<td>" + sellerId + "</td>" +
                "<td>" + listProd + "</td>" +
                "<td><button class='endbtn' id='" + sno + "/" + timeStamp + "'>End</button></td>" +
                "</tr>";

        divObj.innerHTML += row;
    }

    // on click edit button

    $('.editbtn').click(function () {
        var $this = $(this);
        //get the row element of the edit button
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);

        //get the <td> elements of the selected row that can be edited
        var tds = $this.closest('tr').find('.canEdit').filter(function () {
            return $(this).find('.editbtn').length === 0;
        });

        if ($this.html() === 'Edit') {
            $this.html('Save');
            //make <td> elements of that row editable
            tds.prop('contenteditable', true);
            currentRow.classList.add('currRowEdit');
        } else {
            $this.html('Edit');
            tds.prop('contenteditable', false);
            currentRow.classList.remove('currRowEdit');
            var allotTime = currentRow.cells.item(5).textContent
            updateLiveStream(trId, currentRow.className, allotTime)
        }
    });

    // on click Delete Button to delete the videos

    $('.delbtn').click(function () {
        var $this = $(this);
        //get the row element of the delete button
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);

        var retVal = confirm("Do you want to remove this video?");
        //if 'ok' is clicked on the alert box
        if (retVal == true) {
            deleteVideo(trId, currentRow.className)
            currentRow.style.display = 'none';
        }
    });

    // on click End Button to end the live 


    $('.endbtn').click(function () {
        var $this = $(this);
        var id = $(this).attr('id');
        console.log(id.split('/')[1]);
        //get the row element of the delete button
        var trId = $(this).closest('tr').prop('id');
        var currentRow = document.getElementById(trId);

        var retVal = confirm("Do you want to end this live?");
        //if 'ok' is clicked on the alert box
        if (retVal == true) {
            endLive(trId, id.split('/')[1])
        }
    });
    checkEditAccess();
});

// End Live function

function endLive(userId, timestamp) {
    // console.log(live, userId);
    var userDataRef2 = liveVid.database().ref().child("LiveEnd");
    userDataRef2.once("value").then(function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        // childData[userId].isActive = "0";
        // console.log(live)
        console.log(rootKey)
        console.log(childData[userId].isActive);
        var updates = {};
        updates['/' + userId + '/isActive'] = "0";
        alert("Successfully ended live stream!");
        userDataRef2.update(updates);
        deleteReq(userId, timestamp)
    });
}

function deleteReq(uid, timestamp) {
    console.log(timestamp, uid);
    var reqDataRef = liveVid.database().ref().child("Request");
    var ref = reqDataRef.child(uid).child(timestamp);
    ref.remove();
    alert("Request deleted");
}





function checkEditAccess() {

    var userId = localStorage.getItem("userId");
    console.log(userId);

    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(13);//.orderByKey();

    userDataRef.on("value", function (snapshot) {

        //console.log(snapshot.val().view);

        if ((!snapshot.val().edit) && (!snapshot.val().delete)) {

            var tble = document.getElementById("table");
            var row = tble.rows;

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(1);
            }

        }
        if (!snapshot.val().edit) {

            $(".editBtn").remove();
            $(".prodInputBox").remove();
            $(".doneBtn").remove();
            $(".addBtn").remove();

            for (var j = 0; j < row.length; j++) {

                // Deleting the 10th cell of each row. 
                row[j].deleteCell(8);
            }
        }
        if (!snapshot.val().delete) {
            $(".delBtn").remove();
        }
    })
}

// On change the current Status

function changeStatus(timeStamp, userId, newStatus) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        var oldStatus = childData.status;
        //console.log(rootKey) //same as timestamp
        var obj = {"status": newStatus, "old-status": oldStatus};
        ref.update(obj);
    })
}

// Function to update

function updateLiveStream(timeStamp, userId, newAllotTime) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        //console.log(rootKey) //same as timestamp
        var obj = {"allot_time": newAllotTime};
        ref.update(obj);
        //console.log(childData.allot_time);
    })
}

// To add Product

function addProduct(productId, divId) {
    var divElem = document.getElementById(divId);
    divElem.innerHTML += ',' + productId;
}

// To update Product list

function updateProductList(timeStamp, userId, productIdList) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.once("value", function (snapshot) {
        var rootKey = snapshot.key;
        var childData = snapshot.val();
        //console.log(rootKey) //same as timestamp
        var childRef = ref.child("product_id");
        childRef.once("value", function (childSnapshot) {
            console.log(productIdList);
            var numberOfProducts = productIdList.length;
            for (var i = 1; i < numberOfProducts + 1; i++) {
                var product = "product" + i;
                var j;
                if (productIdList[0] == "") {
                    j = i;
                } else {
                    j = i - 1;
                }
                var prod = {[product]: productIdList[j]};
                childRef.update(prod);
            }
        })
        alert("Product list updated");
    })
}

// To delete videos

function deleteVideo(timeStamp, userId) {
    var ref = userDataRef.child(userId).child(timeStamp);
    ref.remove();
    alert("Video deleted");
}