var getOrderlist = localStorage.getItem("getOrderlist");
console.log("getorderlist in getOrderdetails:",getOrderlist);

function getOrderDetails(orderId, storeName, storeLocation, topay, wallet_balance_used) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(getOrderlist+"order_id=" + orderId, requestOptions)
            .then(response => response.json())
            .then(result => {
                //console.log(result)
                generateInvoice(result.data, storeName, storeLocation, topay, wallet_balance_used);
            })
            .catch(error => console.log('error', error));
}

