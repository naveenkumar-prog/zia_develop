var promocodeurl = localStorage.getItem("promocodeurl");

getPromocodes();


function getPromocodes() {
    var myHeaders = new Headers();
    myHeaders.append("userid", "3513");
    myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("promo_code_id", "0");

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    var tab = document.getElementById("myTable");

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
  //  var url = "http://api.myzila.com/Promocode";

    fetch(promocodeurl, requestOptions)
            .then(response => response.json())
            .then(result => {
                if (result.status == 200) {
                    console.log(result.list);

                    var myList = result.list;
                    for (i = 0; i < myList.length; i++) {
                        var row = "<tr id='" + myList[i].promo_code_id + "'>" +
                                "<td><button class='editbtn'>Edit</button><br><br><button class='delbtn'>Delete</button></td>" +
                                "<td contenteditable='false'>" + myList[i].promo_code_id + "</td>" +
                                "<td contenteditable='false'>" + myList[i].promo_code + "</td>" +
                                "<td contenteditable='false'>" + myList[i].discription + "</td>" +
                                "<td contenteditable='false'>" + myList[i].flat_discount + "</td>" +
                                "<td contenteditable='false'>" + myList[i].percentage_discount + "</td>" +
                                "<td contenteditable='false'><p id='startDateCellP" + myList[i].promo_code_id + "'>" + myList[i].start_date + "</p><input type='text' style='display:none' id='startDatePicker" + myList[i].promo_code_id + "'></td>" +
                                "<td contenteditable='false'><p id='endDateCellP" + myList[i].promo_code_id + "'>" + myList[i].end_date + "</p><input type='text' style='display:none' id='endDatePicker" + myList[i].promo_code_id + "'></td>" +
                                "<td contenteditable='false'>" + myList[i].isactive + "</td>" +
                                "<td contenteditable='false'>" + myList[i].max_avail_time + "</td>" +
                                "<td contenteditable='false'>" + myList[i].min_amount_to_avail_discount + "</td>" +
                                "</tr>";
                        tab.innerHTML += row;
                    }
                    var sDateNew = 0, eDateNew = 0;

                    // on click edit button

                    $('.editbtn').click(function () {
                        var $this = $(this);
                        //get the row element of the edit button
                        var trId = $(this).closest('tr').prop('id');
                        console.log(trId);
                        var currentRow = document.getElementById(trId);

                        //get the <td> elements of the selected row
                        var tds = $this.closest('tr').find('td').filter(function () {
                            return $(this).find('.editbtn').length === 0;
                        });


                        //if the button displays 'edit'
                        if ($this.html() === 'Edit') {
                            //change text displayed in button to 'save' 
                            $this.html('Save');
                            //make <td> elements of that row editable
                            tds.prop('contenteditable', true);
                            // console.log("ok");
                            //add class to apply css
                            currentRow.classList.add('currRowEdit');

                            //Hide existing dates, display input textboxes and handle inputs
                            var startDateCellP = document.getElementById('startDateCellP' + trId);
                            var sDate = startDateCellP.innerHTML;
                            sDateNew = sDate;
                            startDateCellP.innerHTML = '';
                            document.getElementById('startDatePicker' + trId).style.display = "block";
                            $('#startDatePicker' + trId).datepicker({dateFormat: 'yy-mm-dd'});
                            $("#startDatePicker" + trId).val(sDate.split(' ')[0]);
                            sDateNew = sDate;
                            console.log(sDateNew);
                            $("#startDatePicker" + trId).on("change", function () {
                                // sDateNew = $(this).val();
                                if ($(this).val() == "")
                                {
                                    sDateNew = sDate;
                                    $(this).val(sDateNew.split(' ')[0]);
                                } else {
                                    sDateNew = $(this).val() + " 00:00:00";
                                }
                                console.log(sDate)
                                console.log(sDateNew);

                            });

                            var endDateCellP = document.getElementById('endDateCellP' + trId);
                            var eDate = endDateCellP.innerHTML;
                            sDateNew = sDate;
                            console.log(sDateNew);
                            endDateCellP.innerHTML = '';
                            document.getElementById('endDatePicker' + trId).style.display = "block";

                            $('#endDatePicker' + trId).datepicker({dateFormat: 'yy-mm-dd'});
                            $("#endDatePicker" + trId).val(eDate.split(' ')[0]);
                            eDateNew = eDate;
                            $("#endDatePicker" + trId).on("change", function () {
                                // eDateNew = $(this).val() + " 00:00:00";
                                if ($(this).val() == "")
                                {
                                    eDateNew = eDate;
                                    $(this).val(eDateNew.split(' ')[0]);
                                } else {
                                    eDateNew = $(this).val() + " 00:00:00";
                                }

                                console.log(eDate)
                                console.log(eDateNew);

                            });
                        } else {
                            $this.html('Edit');
                            //make <td> elements of that row uneditable
                            tds.prop('contenteditable', false);
                            //remove css of that row
                            currentRow.classList.remove('currRowEdit');
                            console.log(sDateNew, eDateNew);
                            var URLEncoded = {
                                promo_code_id: currentRow.cells.item(1).innerHTML,
                                promo_code: currentRow.cells.item(2).innerHTML,
                                description: currentRow.cells.item(3).innerHTML,
                                percentage_discount: currentRow.cells.item(5).innerHTML,
                                flat_discount: currentRow.cells.item(4).innerHTML,
                                start_date: sDateNew,
                                end_date: eDateNew,
                                isactive: currentRow.cells.item(8).innerHTML,
                                max_avail_time: currentRow.cells.item(9).innerHTML,
                                min_amount_to_avail_discount: currentRow.cells.item(10).innerHTML,
                            }
                            //console.log(URLEncoded); 
                            edit(URLEncoded);
                        }
                    }
                    );

                    //when delete button is clicked
                    $('.delbtn').click(function () {

                        var $this = $(this);
                        //get the row element of the delete button
                        var trId = $(this).closest('tr').prop('id');
                        var currentRow = document.getElementById(trId);
                        console.log(trId);

                        var tds = $this.closest('tr').find('td').filter(function () {
                            return $(this).find('.editbtn').length == 0;
                        });

                        var retVal = confirm("Do you want to continue ?");
                        //if 'ok' is clicked on the alert box
                        if (retVal == true) {
                            var URLEncoded = {
                                promo_code_id: trId
                            };
                            edit(URLEncoded, 1);
                            currentRow.style.display = 'none';
                        }
                    });
                } else {
                    alert("Could not fetch data");
                }

            })
            .catch(error => console.log('error', error));
}

function edit(URLEncoded, flag = 0) {
    var myHeaders = new Headers();
    myHeaders.append("userid", "3513");
    myHeaders.append("sessionkey", "AyvRZMmvXUZpKxyYat3qeiD2MRjD66HM");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("promo_code_id", URLEncoded.promo_code_id);
    if (flag == 0) {
        urlencoded.append("promo_code", URLEncoded.promo_code);
        urlencoded.append("max_avail_time", URLEncoded.max_avail_time);
        urlencoded.append("start_date", URLEncoded.start_date);
        urlencoded.append("end_date", URLEncoded.end_date);
        urlencoded.append("flat_discount", URLEncoded.flat_discount);
        urlencoded.append("percentage_discount", URLEncoded.percentage_discount);
        urlencoded.append("min_amount_to_avail_discount", URLEncoded.min_amount_to_avail_discount);
        urlencoded.append("discription", URLEncoded.description);
        urlencoded.append("isactive", URLEncoded.isactive);
    }

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
  //  var url = "http://api.myzila.com/Promocode";

    fetch(promocodeurl, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                if (result.status == 200) {
                    alert("Changes were successfully updated!");
                    window.location.reload();
                } else {
                    alert("Could not update changes");
                }
            })
            .catch(error => {
                console.log('error', error);
                alert("Error");
            });
}