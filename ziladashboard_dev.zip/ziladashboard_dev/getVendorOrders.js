var getOrderlist = localStorage.getItem("getOrderlist");
var getdetailsbyId = localStorage.getItem("getdetailsbyId");
var updateStatus = localStorage.getItem("updateStatus");

console.log("updateStatus:",updateStatus);
console.log("getOrderlist:",getOrderlist);
console.log("getdetailsbyId:",getdetailsbyId);

var productId;
var prod = [];
var orders = [];
var trasnferamts = [];
var totalPages;
var userId = localStorage.getItem("userId");

var myHeaders = new Headers();
myHeaders.append("userid", localStorage.getItem("userId"));
myHeaders.append("sessionkey", sessionStorage.getItem("sessionKey"));
myHeaders.append("languagetype", "1");
myHeaders.append("usertype", "2");
myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

var requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
};

var pageNum = 0;
// const proxyurl = "https://cors-anywhere.herokuapp.com/";
const url = getOrderlist+"seller_id=0&vendor_id=" + userId + "&page=";
// console.lo
function getdetails(x)
{
    var myHeaders = new Headers();
    myHeaders.append("userid", "1784");
    myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "0");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(getdetailsbyId+"product_id=" + x, requestOptions)
            .then(response => response.json())
            .then(result => {
                // console.log("http://api.myzila.com/GetDetailsById?product_id="+x)
                prod = result.data;
                // console.log(prod);
                // console.log(prod.length);
                //localStorage.setItem('data', prod);
                //console.log(prod[0].name)
                displayDetails(prod);
            })
            .catch(error => console.log('error', error));
}

function displayDetails(prod)
{
    document.getElementById('popup').style.display = 'block';
    //var elem = document.getElementById('data');
    if (prod) {
        // console.log("data");
    }

    var imgProd = "<img src='" + prod[0].image + "' class='product_image'><br>"
    var tr = "<b>Product Id:</b>  " + prod[0].product_id + "<br>" +
            "<b>Name:</b>  " + prod[0].name + "<br>" +
            "<b>Hindi name:</b>  " + prod[0].hindi_name + "<br>" +
            "<b>Tamil name:</b>  " + prod[0].tamil_name + "<br>" +
            "<b>Description:</b>  " + prod[0].description + "<br>" +
            "<b>Hindi desc:</b>  " + prod[0].hindi_desc + "<br>" +
            "<b>Tamil desc:</b>  " + prod[0].tamil_desc + "<br>" +
            "<b>Actual amount:</b>  " + prod[0].actual_amount + "<br>" +
            "<b>Discount:</b>  " + prod[0].discount + "<br>" +
            "<b>Final amount:</b>  " + prod[0].final_amount + "<br>" +
            "<b>Video link:</b>  " + prod[0].video_link + "<br>" +
            "<b>Category:</b>  " + prod[0].category_id + "<br>" +
            "<b>Sub-category:</b>  " + prod[0].sub_category_id + "<br>" +
            "<b>Seller-id:</b>  " + prod[0].seller_id + "<br>" +
            "<b>Old discount:</b>  " + prod[0].old_discount + "<br>" +
            "<b>Product count:</b>  " + prod[0].product_count + "<br>" +
            "<b>Size:</b>  " + prod[0].size + "<br>" +
            "<b>Color:</b>  " + prod[0].color + "<br>" +
            "<b>Hindi color:</b>  " + prod[0].hindi_color + "<br>" +
            "<b>Tamil color:</b>  " + prod[0].tamil_color + "<br>" +
            "<b>Brand:</b>  " + prod[0].brand + "<br>" +
            "<b>Brand Id:</b>  " + prod[0].brand_id + "<br>" +
            "<b>Fabric:</b>  " + prod[0].fabric + "<br>" +
            "<b>Returnable:</b>  " + prod[0].returnable + "<br>" +
            "<b>Max day return:</b>  " + prod[0].max_day_return + "<br>" +
            "<b>Hashtag:</b>  " + prod[0].hashtag;

    var div = document.getElementById("prodImage");
    var tab = document.getElementById("prodInfo");

    document.getElementById('popup').classList.add('stick');

    div.innerHTML = imgProd;
    tab.innerHTML = tr;
}

function changeDisplay() {
    document.getElementById('popup').classList.remove('stick');
    document.getElementById('popup').style.display = 'none';
}

function changeStatus(x, y, f)
{
    if (f == 1) {
        var result = true;
    } else {
        var result = confirm("Change status?");
    }


    if (result == true)
    {
        console.log(y)
        var myHeaders = new Headers();
        myHeaders.append("userid", "1784");
        myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
        myHeaders.append("languagetype", "1");
        myHeaders.append("usertype", "0");
        myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
        myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

        var urlencoded = new URLSearchParams();
        urlencoded.append("orderId", y);
        urlencoded.append("orderStatus", x);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: urlencoded,
            redirect: 'follow'
        };

        const updateUrl = updateStatus;

        fetch(updateUrl, requestOptions)
                .then(response => response.text())
                .then(result => {
                    //location.reload();
                    //console.log(result)  
                    var newStatus;

                    switch (parseInt(x))
                    {
                        case 0 :
                            newStatus = "Not Known";
                            break;
                        case 1 :
                            newStatus = "Placed";
                            break;
                        case 2 :
                            newStatus = "Shipped";
                            break;
                        case 3 :
                            newStatus = "Delivered";
                            break;
                        case 4 :
                            newStatus = "Cancelled";
                            break;
                        case 5 :
                            newStatus = "Request to return";
                            break;
                        case 6 :
                            newStatus = "Returned";
                            break;
                        case 7 :
                            newStatus = "Return request rejected";
                            break;
                        case 8 :
                            newStatus = "Approve";
                            break;
                        case 9 :
                            newStatus = "Returned";
                            break;
                        case 10 :
                            newStatus = "No return";
                            break;
                    }
                    document.getElementById("orderStatusLabel" + y).innerHTML = "<b>" + newStatus + "</b>";
                    // location.reload();
                })
                .catch(error => console.log('error', error));
    }
    //document.getElementById("showData").innerHTML = x + " is your number " + y ;
}

// the json data. (you can change the values for output.)


var numberOfOrders;
buildTable();

function buildTable()
{
    document.getElementById("overlay").style.display = "block";
    document.getElementById("tabledate").style.display = "none";
    document.getElementById("tablemain").style.display = "block";
    // console.log("a"); 
    var displayUrl = url + pageNum;
    //console.log(pageNum)
    fetch(displayUrl, requestOptions)
            .then(response => {
                // console.log(response);
                document.getElementById("overlay").style.display = "none";
                console.log("console",response.json());

            })
            .then(data => {

                console.log("data : ",data)
                // Work with JSON data here
                orders = data.data;
                numberOfOrders = data.totalordertozila;
                for (var i = 0; i < data.data.length; i++) {
                    var obj = data.data[i];
                    //console.log(obj)
                    var status = "";

                    switch (data.data[i].status)
                    {
                        case 0 :
                            status = "Not Known";
                            break;
                        case 1 :
                            status = "Placed";
                            break;
                        case 2 :
                            status = "Shipped";
                            break;
                        case 3 :
                            status = "Delivered";
                            break;
                        case 4 :
                            status = "Cancelled";
                            break;
                        case 5 :
                            status = "Request to return";
                            break;
                        case 6 :
                            status = "Returned";
                            break;
                        case 7 :
                            status = "Return request rejected";
                            break;
                        case 8 :
                            status = "Approve";
                            break;
                        case 9 :
                            status = "Returned";
                            break;
                        case 10 :
                            status = "No return";
                            break;
                    }
                    var fprice = ((100 - parseFloat(data.data[i].offer_amount, 10)) / 100) * parseFloat(data.data[i].actual_amount, 10);
                    var st = " <div><select id=" + data.data[i].sold_product_id + " onchange=\"changeStatus(this.value,this.id, 0)\"  > <option value=" + 0 + ">Not Known</option> <option value=" + 1 + ">Placed</option> <option value=" + 2 + ">Shipped</option> <option value=" + 3 + ">Delivered</option> <option value=" + 4 + ">Cancelled</option> <option value=" + 5 + ">Request to return</option> <option value=" + 6 + ">Returned</option> <option value=" + 7 + ">Return request rejected</option> <option value=" + 8 + ">Approve</option> <option value=" + 9 + ">Retunred</option> <option value=" + 10 + ">No return</option> <option selected value=" + 11 + ">--Select--</option> </select> </div>  ";
                    var status = "<label id='orderStatusLabel" + data.data[i].sold_product_id + "'> " + status + "  <label>";
                    var check = "<input type='checkbox' class='check' id='check" + data.data[i].sold_product_id + "'>";
                    productId = obj.product_id;



                    var $tr = $("<tr>");

                    var $SNO = $("<td>");
                    var $NAME = $("<td>");
                    var $IMAGE = $("<td>");
                    var $ProdDetails = $("<td>");
                    var $PRICE = $("<td>");
                    var $FPRICE = $("<td>");
                    var $COLOR = $("<td>");
                    var $QUANTITY = $("<td>");
                    var $CreatedOn = $("<td>");
                    var $UpdatedOn = $("<td>");
                    var $ORDERID = $("<td>");
                    var $SHIP = $("<td>");
                    var $StatusString = $("<td id='orderStatusLabel" + obj.sold_product_id + "'>");
                    var $STATUS = $("<td>");
                    var $TPRICE = $("<td>");
                    var $GST = $("<td>");
                    var $SPRD_ID = $("<td>");
                    var $WAYBILL = $("<td>");
                    var $PAYSLIP = $("<td>");
                    var $CHECK = $("<td class='check'>");

                    var image = "<img src='" + obj.image + "' width='100' height='100'>"
                    /*
                     var dispProd = "prod";
                     var dispShip = "ship";
                     */
                    var prodDetailsButton = "<button class='viewDetails' onclick='getdetails(" + productId + ")'><span>View</span></button>";
                    /*
                     var shipDetailsButton = "<button onclick='getdetails("+ productId + "," + dispShip +")'>Click to view</button>";
                     */
                    var download = "<button class='downloadBtn' id='" + obj.waybill + "' onclick='getDelhivery(this.id)'>Download</button>";
                    var download1 = "Not generated";


                    var payMethod = 'Online'
                    if (obj.payment_method == 1)
                        payMethod = 'Cash'

                    var shipDetails = "<b>Address:</b> " + obj.address + "<br>" + "<b>Username:</b> " + obj.user_name + "<br>" + "<b>Payment method:</b> " + payMethod;

                    $SNO.append(i + 1);
                    $NAME.append(obj.name);
                    $IMAGE.append(image);
                    $ProdDetails.append("<br>" + prodDetailsButton);
                    $PRICE.append(obj.actual_amount);
                    $FPRICE.append(parseFloat(fprice, 10).toFixed(2));
                    $COLOR.append(obj.color);
                    $QUANTITY.append(obj.quantity);
                    //$SHIP.append("<br>"+shipDetailsButton);
                    $CreatedOn.append(obj.created_on);
                    $UpdatedOn.append(obj.updated_on);
                    $ORDERID.append(obj.order_id);
                    $SHIP.append(shipDetails);
                    $StatusString.append(status);
                    $STATUS.append(st);
                    $TPRICE.append(parseFloat(obj.trans_amt, 10).toFixed(2));
                    $GST.append(parseFloat(obj.gst_amt, 10).toFixed(2));
                    $SPRD_ID.append(obj.sold_product_id);
                    $WAYBILL.append(obj.waybill);
                    if (obj.waybill === '0')
                    {
                        $PAYSLIP.append(download1);
                    } else {
                        $PAYSLIP.append(download);
                    }
                    $CHECK.append(check);

                    $tr.append($SNO);
                    $tr.append($NAME);
                    $tr.append($IMAGE);
                    $tr.append($ProdDetails);
                    $tr.append($PRICE);
                    $tr.append($FPRICE);
                    $tr.append($COLOR);
                    $tr.append($QUANTITY);
                    $tr.append($CreatedOn);
                    $tr.append($UpdatedOn);
                    $tr.append($ORDERID);
                    $tr.append($SHIP);
                    $tr.append($StatusString);
                    $tr.append($STATUS);
                    $tr.append($TPRICE);
                    $tr.append($GST);
                    $tr.append($SPRD_ID);
                    $tr.append($WAYBILL);
                    $tr.append($PAYSLIP);
                    $tr.append($CHECK);

                    $('#tableBody').append($tr);


                }
                //console.log(data)
                pageButtons(numberOfOrders)
                // if(pageNum!=0)
                // var pg = document.getElementsByClassName("pg"+(pageNum+1))[0];
                // else
                var pg = document.getElementsByClassName("pg" + (pageNum + 1))[0]
                // console.log(pg);
                pg.classList.add("activePage");
                // console.log("a");

                //checkEditAccess();

            })
            .catch(err => {
                // Do something for an error here
            //    console.log(err);
            })
}




function pageButtons(numOrders) {
    var wrapper = document.getElementById('pagination-wrapper')

    wrapper.innerHTML = ''
    //console.log('Pages:', pages)

    //var maxLeft = (state.page - Math.floor(state.window / 2))
    //var maxRight = (state.page + Math.floor(state.window / 2))

    var maxLeft = (pageNum - 2)
    var maxRight = (pageNum + 2)

    if (maxLeft < 0) {
        maxLeft = 0
        maxRight = 4
    }

    var numberOfPages = Math.ceil(numOrders / 10);
    totalPages = numberOfPages;
    if (maxRight > numberOfPages) {
        maxLeft = numberOfPages - 5

        if (maxLeft < 1) {
            maxLeft = 0
        }
        maxRight = numberOfPages
    }

    var wrapper = document.getElementById("pagination-wrapper");
    //var page = pageNum + 1;
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += "<button value='" + page + "' class='page btn btn-sm btn-info pg" + (page + 1) + "'>" + (page + 1) + "</button>"
    }

    if (pageNum != 1) {
        wrapper.innerHTML = "<button value='0' class='page btn btn-sm btn-info'>&#171; First</button>" + wrapper.innerHTML
    }

    if (pageNum != numberOfPages) {
        wrapper.innerHTML += "<button value='" + numberOfPages + "' class='page btn btn-sm btn-info'>Last &#187;</button>"
    }

    $('.page').on('click', function () {
        $('#tableBody').empty()
        var pgs = document.getElementsByClassName("page");
        for (i = 0; i < pgs.length; i++) {
            pgs[i].classList.remove("activePage");
            // console.log("c");
        }
        pageNum = Number($(this).val());
        buildTable()
        // $(this).addClass("activePage");
        // console.log("b");

    })
}

var searchPageNum = 0;
var value;
//display table based on search results
$('#searchfunc').click(function () {
    value = document.getElementById("search-input").value;
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
        searchPageNum = 0;
    }
    buildSearchTable(value)
})

//display search results in table 
function buildSearchTable(value) {
    var displayUrl = getOrderlist+"vendor_id=" + userId + "&searchkey=" + value + "&page=" + searchPageNum + "&searchvendor=1";
    // var displayUrl = "http://api.myzila.com/GetOrderList?searchkey="+value+"&page="+searchPageNum;
    // console.log(displayUrl , userId)
    fetch(displayUrl, requestOptions)
            .then(response => {
                return response.json()
                console.log("buildSearchTable response : ",response.json());
            })
            .then(data => {
                // Work with JSON data here
                document.getElementById("tableBody").innerHTML = '';
                for (var i = 0; i < data.data.length; i++) {
                    var obj = data.data[i];
                    var status = "";

                    switch (data.data[i].status)
                    {
                        case 0 :
                            status = "Not Known";
                            break;
                        case 1 :
                            status = "Placed";
                            break;
                        case 2 :
                            status = "Shipped";
                            break;
                        case 3 :
                            status = "Delivered";
                            break;
                        case 4 :
                            status = "Cancelled";
                            break;
                        case 5 :
                            status = "Request to return";
                            break;
                        case 6 :
                            status = "Returned";
                            break;
                        case 7 :
                            status = "Return request rejected";
                            break;
                        case 8 :
                            status = "Approve";
                            break;
                        case 9 :
                            status = "Returned";
                            break;
                        case 10 :
                            status = "No return";
                            break;
                    }
                    var check = "<input type='checkbox' class='check' id='check" + data.data[i].sold_product_id + "'>";
                    var st = " <div><select id=" + data.data[i].sold_product_id + " onchange=\"changeStatus(this.value,this.id, 0)\"  > <option value=" + 0 + ">Not Known</option> <option value=" + 1 + ">Placed</option> <option value=" + 2 + ">Shipped</option> <option value=" + 3 + ">Delivered</option> <option value=" + 4 + ">Cancelled</option> <option value=" + 5 + ">Request to return</option> <option value=" + 6 + ">Returned</option> <option value=" + 7 + ">Return request rejected</option> <option value=" + 8 + ">Approve</option> <option value=" + 9 + ">Retunred</option> <option value=" + 10 + ">No return</option> <option selected value=" + 11 + ">--Select--</option> </select> </div>  ";
                    var status = "<label> " + status + "  <label>";
                    var fprice = ((100 - parseFloat(data.data[i].offer_amount, 10)) / 100) * parseFloat(data.data[i].actual_amount, 10);
                    productId = obj.product_id;

                    var $tr = $("<tr>");

                    var $SNO = $("<td>");
                    var $NAME = $("<td>");
                    var $IMAGE = $("<td>");
                    var $ProdDetails = $("<td>");
                    var $PRICE = $("<td>");
                    var $FPRICE = $("<td>");
                    var $COLOR = $("<td>");
                    var $QUANTITY = $("<td>");
                    var $CreatedOn = $("<td>");
                    var $UpdatedOn = $("<td>");
                    var $ORDERID = $("<td>");
                    var $SHIP = $("<td>");
                    var $StatusString = $("<td id='orderStatusLabel" + obj.sold_product_id + "'>");
                    var $TPRICE = $("<td>");
                    var $STATUS = $("<td>");
                    var $GST = $("<td>");
                    var $SPRD_ID = $("<td>");
                    var $WAYBILL = $("<td>");
                    var $PAYSLIP = $("<td>");
                    var $CHECK = $("<td class='check'>");

                    var image = "<img src='" + obj.image + "' width='100' height='100'>"

                    var prodDetailsButton = "<button onclick='getdetails(" + productId + ")'>Click to view</button>";

                    var payMethod = 'Online'
                    if (obj.payment_method == 1)
                        payMethod = 'Cash'
                    var download = "<button class='downloadBtn' id='" + obj.waybill + "' onclick='getDelhivery(this.id)'>Download</button>";
                    var download1 = "Not generated";
                    var shipDetails = "<b>Address:</b> " + obj.address + "<br>" + "<b>Username:</b> " + obj.user_name + "<br>" + "<b>Payment method:</b> " + payMethod;
                    $SNO.append(i + 1);
                    $NAME.append(obj.name);
                    $IMAGE.append(image);
                    $ProdDetails.append("<br>" + prodDetailsButton);
                    $PRICE.append(obj.actual_amount);
                    $FPRICE.append(parseFloat(fprice, 10).toFixed(2));
                    $COLOR.append(obj.color);
                    $QUANTITY.append(obj.quantity);
                    //$SHIP.append("<br>"+shipDetailsButton);
                    $CreatedOn.append(obj.created_on);
                    $UpdatedOn.append(obj.updated_on);
                    $ORDERID.append(obj.order_id);
                    $SHIP.append(shipDetails);
                    $StatusString.append(status);
                    $STATUS.append(st);
                    $TPRICE.append(parseFloat(obj.trans_amt, 10).toFixed(2));
                    $GST.append(parseFloat(obj.gst_amt, 10).toFixed(2));
                    $SPRD_ID.append(obj.sold_product_id);
                    $WAYBILL.append(obj.waybill);
                    if (obj.waybill === '0')
                    {
                        $PAYSLIP.append(download1);
                    } else {
                        $PAYSLIP.append(download);
                    }
                    $CHECK.append(check);

                    $tr.append($SNO);
                    $tr.append($NAME);
                    $tr.append($IMAGE);
                    $tr.append($ProdDetails);
                    $tr.append($PRICE);
                    $tr.append($FPRICE);
                    $tr.append($COLOR);
                    $tr.append($QUANTITY);
                    $tr.append($CreatedOn);
                    $tr.append($UpdatedOn);
                    $tr.append($ORDERID);
                    $tr.append($SHIP);
                    $tr.append($StatusString);
                    $tr.append($STATUS);
                    $tr.append($TPRICE);
                    $tr.append($GST);
                    $tr.append($SPRD_ID);
                    $tr.append($WAYBILL);
                    $tr.append($PAYSLIP);
                    $tr.append($CHECK);
                    // console.log($CHECK)

                    $('#tableBody').append($tr);
                }
                //console.log(data)
                // searchPageButtons();

                //checkEditAccess();
            })
            .catch(error => {
                // Do something for an error here
                console.log("error", error)
            })
}

function searchPageButtons() {
    var wrapper = document.getElementById('pagination-wrapper')

    wrapper.innerHTML = ''
    //console.log('Pages:', pages)

    //var maxLeft = (state.page - Math.floor(state.window / 2))
    //var maxRight = (state.page + Math.floor(state.window / 2))

    var maxLeft = (pageNum - 2)
    var maxRight = (pageNum + 2)


    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = 5
    }
    var numberOfPages = 6
    //var numberOfPages = Math.ceil(numOrders/10);
    if (maxRight > numberOfPages) {
        maxLeft = numberOfPages - 5

        if (maxLeft < 1) {
            maxLeft = 1
        }
        maxRight = numberOfPages
    }

    var wrapper = document.getElementById("pagination-wrapper");
    //var page = pageNum + 1;
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += "<button value='" + page + "' class='page btn btn-sm btn-info'>" + page + "</button>"
    }

    if (searchPageNum != 1) {
        wrapper.innerHTML = "<button value='1' class='page btn btn-sm btn-info'>&#171; First</button>" + wrapper.innerHTML
    }

    if (searchPageNum != numberOfPages) {
        wrapper.innerHTML += "<button value='" + numberOfPages + "' class='page btn btn-sm btn-info'>Last &#187;</button>"
    }

    $('.page').on('click', function () {
        $('#tableBody').empty()

        searchPageNum = Number($(this).val()) - 1

        buildSearchTable(value)
    })
}
$('#').keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
        alert('You pressed a "enter" key in textbox');
    }
});
var multipleStatusVar;
var check;

function multipleStatus() {
    document.getElementById("changeStatusBtn").style.display = 'none';
    multipleStatusVar = document.getElementsByClassName('multipleStatus');
    check = document.getElementsByClassName('check');
    for (i = 0; i < multipleStatusVar.length; i++) {
        multipleStatusVar[i].style.display = 'table-cell';
    }
    for (i = 0; i < check.length; i++) {
        check[i].style.display = 'table-cell';
        check[i].checked = false;
    }
}

function multipleStatusCancel() {
    document.getElementById("changeStatusBtn").style.display = 'block';
    for (i = 0; i < check.length; i++) {
        check[i].style.display = 'none';
    }
    for (i = 0; i < multipleStatusVar.length; i++) {
        multipleStatusVar[i].style.display = 'none';
    }
}
console.log('cc')
function selectAll() {
    if (document.getElementById('selectAllCheck').checked) {
        for (i = 0; i < check.length; i++) {
            check[i].checked = true;
        }
    } else {
        for (i = 0; i < check.length; i++) {
            check[i].checked = false;
        }
    }

}
// function multiChangeStatus(x, y, n)
// {
//     var result = confirm("Change status?");

//     if(result==true)
//     {
//         var myHeaders = new Headers();
//         myHeaders.append("userid", "1784");
//         myHeaders.append("sessionkey", "rq3fDv7ySfbo3YzZxYBgg5FNjCQjvkRi");
//         myHeaders.append("languagetype", "1");
//         myHeaders.append("user_type", "0");
//         myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");
//         myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

//         var urlencoded = new URLSearchParams();
//         urlencoded.append("orderId", y);
//         urlencoded.append("orderStatus", x);

//         var requestOptions = {
//             method: 'POST',
//             headers: myHeaders,
//             body: urlencoded,
//             redirect: 'follow'
//         };

//         const updateUrl = "http://api.myzila.com/UpdateStatus";

//         fetch(proxyurl+updateUrl, requestOptions)
//             .then(response => response.text())
//             .then(result => {
//                 // location.reload();
//                 //console.log(result)  
//                 var newStatus;

//                 switch (parseInt(x))
//                 {
//                     case 0 : newStatus = "Not Known"; break;
//                     case 1 : newStatus = "Placed"; break;
//                     case 2 : newStatus = "Shipped"; break;
//                     case 3 : newStatus = "Delivered"; break;
//                     case 4 : newStatus = "Cancelled"; break;
//                     case 5 : newStatus = "Request to return"; break;
//                     case 6 : newStatus = "Returned"; break;
//                     case 7 : newStatus = "Return request rejected"; break;
//                     case 8 : newStatus = "Approve"; break;
//                     case 9 : newStatus = "Returned"; break;
//                     case 10 : newStatus = "No return"; break;
//                 }
//                 document.getElementById("orderStatusLabel"+y).innerHTML = "<b>"+newStatus+"</b>";
//             })
//             .catch(error => console.log('error', error));
//     }
//     //document.getElementById("showData").innerHTML = x + " is your number " + y ;
// }

function time() {
    setTimeout(5000);
}
// console.log("xx")
function multiStatusChange() {
    var multiSelect = document.getElementById('multiSelect').value
    if (multiSelect == 11) {
        alert("Please select a status");
        return;
    } else {
        var flag = 0;
        for (i = 0; i < check.length; i++) {
            if (check[i].checked) {
                flag = 1
                var id = check[i].id.split('k', 2)[1];
                // console.log(id, multiSelect);
                changeStatus(multiSelect, id, 1);

            }
        }
        if (!flag) {
            alert("Please Select orders you want to change the status of")
        } else {
            multipleStatusCancel();
        }
    }

}

function checkEditAccess() {
    /*
     var config = {
     apiKey: "AIzaSyC5Wp39Cz2-E4ui5P7Jtl55j2Y3gemm4MU",
     authDomain: "zila-dashboard-access.firebaseapp.com",
     databaseURL: "https://zila-dashboard-access.firebaseio.com",
     storageBucket: "zila-dashboard-access.appspot.com",
     };
     
     firebase.initializeApp(config);
     */
    var userId = localStorage.getItem("userId");
    // console.log(userId);
    var userDataRef = accessDB.database().ref().child("Access").child(userId).child(12);//.orderByKey();
    userDataRef.on("value", function (snapshot) {
        //console.log("Snap" +snapshot.val().view);
        var tble = document.getElementById("tablemain");
        var row = tble.rows;
        if (!snapshot.val().edit) {
            for (var j = 0; j < row.length; j++) {
                row[j].deleteCell(12);
            }
        }
    })
}


function pageButtonsdate() {
    var wrapper = document.getElementById('pagination-wrapper')
    wrapper.innerHTML = ''
    //console.log('Pages:', pages)

    //var maxLeft = (state.page - Math.floor(state.window / 2))
    //var maxRight = (state.page + Math.floor(state.window / 2))

    var maxLeft = (pageNum - 2)
    var maxRight = (pageNum + 2)

    if (maxLeft < 0) {
        maxLeft = 0
        maxRight = 4
    }
    var numberOfPages = 10;
    //var numberOfPages = Math.ceil(numOrders/10);
    totalPages = numberOfPages;
    if (maxRight > numberOfPages) {
        maxLeft = numberOfPages - 5

        if (maxLeft < 1) {
            maxLeft = 0
        }
        maxRight = numberOfPages
    }

    var wrapper = document.getElementById("pagination-wrapper");
    //var page = pageNum + 1;
    for (var page = maxLeft; page <= maxRight; page++) {
        wrapper.innerHTML += "<button value='" + page + "' class='page btn btn-sm btn-info pg" + (page + 1) + "'>" + (page + 1) + "</button>"
    }

    if (pageNum != 1) {
        wrapper.innerHTML = "<button value='0' class='page btn btn-sm btn-info'>&#171; First</button>" + wrapper.innerHTML
    }

    if (pageNum != numberOfPages) {
        wrapper.innerHTML += "<button value='" + numberOfPages + "' class='page btn btn-sm btn-info'>Last &#187;</button>"
    }
    $('.page').on('click', function () {
        $('#tableBodydate').empty()
        var pgs = document.getElementsByClassName("page");
        for (i = 0; i < pgs.length; i++) {
            pgs[i].classList.remove("activePage");
            // console.log("c");
        }
        pageNum = Number($(this).val());
        buildtableviadate();
        // $(this).addClass("activePage");
        // console.log("b");

    })
}


$(document).ready(function () {
    $("#fromdate").datepicker({dateFormat: 'yy-mm-dd'});
    $("#fromdate").on("change", function () {
        date = $(this).val();
        var fromdate = date;
        localStorage.setItem("From_Date", fromdate);
    });
});

$(document).ready(function () {
    $("#todate").datepicker({dateFormat: 'yy-mm-dd'});
    $("#todate").on("change", function () {
        date = $(this).val();
        var todate = date;
        localStorage.setItem("To_Date", todate);
    });
});


function buildtableviadate() {
    $('#tableBodydate').empty();
    $('#tottrans').empty();
    document.getElementById("overlay").style.display = "block";
    document.getElementById("tablemain").style.display = "none";
    document.getElementById("tabledate").style.display = "block";

    var myHeaders = new Headers();
    myHeaders.append("userid", localStorage.getItem("userId"));
    myHeaders.append("sessionkey", sessionStorage.getItem("sessionKey"));
    myHeaders.append("languagetype", "1");
    myHeaders.append("usertype", "2");
    myHeaders.append("Authorization", "Basic dGVjaHppbGE6dGVjaHppbGFAMjAxOSFAI3RlY2g=");

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    var fdate = localStorage.getItem("From_Date");
    //console.log(fdate);
    var tdate = localStorage.getItem("To_Date");
    //console.log(tdate);


    fetch(getOrderlist+"seller_id=0&vendor_id=" + userId + "&daterangeFrom=" + fdate + "&daterangeTo=" + tdate + "&page=" + pageNum, requestOptions)
            .then(response => {
                document.getElementById("overlay").style.display = "none";
                return response.json()
            })
            .then(data => {
                //console.log(data)
                // Work with JSON data here
                trasnferamts = data.totaltransprice;
                document.getElementById('tottrans').innerHTML = " Total transfer amount : " + trasnferamts.toFixed(2);
                orders = data.data;
                numberOfOrders = data.totalordertozila;
                for (var i = 0; i < data.data.length; i++) {
                    var obj = data.data[i];
                    //console.log(obj)
                    var status = "";

                    switch (data.data[i].status)
                    {
                        case 0 :
                            status = "Not Known";
                            break;
                        case 1 :
                            status = "Placed";
                            break;
                        case 2 :
                            status = "Shipped";
                            break;
                        case 3 :
                            status = "Delivered";
                            break;
                        case 4 :
                            status = "Cancelled";
                            break;
                        case 5 :
                            status = "Request to return";
                            break;
                        case 6 :
                            status = "Returned";
                            break;
                        case 7 :
                            status = "Return request rejected";
                            break;
                        case 8 :
                            status = "Approve";
                            break;
                        case 9 :
                            status = "Returned";
                            break;
                        case 10 :
                            status = "No return";
                            break;
                    }
                    var fprice = ((100 - parseFloat(data.data[i].offer_amount, 10)) / 100) * parseFloat(data.data[i].actual_amount, 10);
                    var st = " <div><select id=" + data.data[i].sold_product_id + " onchange=\"changeStatus(this.value,this.id, 0)\"  > <option value=" + 0 + ">Not Known</option> <option value=" + 1 + ">Placed</option> <option value=" + 2 + ">Shipped</option> <option value=" + 3 + ">Delivered</option> <option value=" + 4 + ">Cancelled</option> <option value=" + 5 + ">Request to return</option> <option value=" + 6 + ">Returned</option> <option value=" + 7 + ">Return request rejected</option> <option value=" + 8 + ">Approve</option> <option value=" + 9 + ">Retunred</option> <option value=" + 10 + ">No return</option> <option selected value=" + 11 + ">--Select--</option> </select> </div>  ";
                    var status = "<label id='orderStatusLabel" + data.data[i].sold_product_id + "'> " + status + "  <label>";
                    var check = "<input type='checkbox' class='check' id='check" + data.data[i].sold_product_id + "'>";
                    productId = obj.product_id;



                    var $tr = $("<tr>");

                    var $SNO = $("<td>");
                    var $NAME = $("<td>");
                    var $IMAGE = $("<td>");
                    var $ProdDetails = $("<td>");
                    var $PRICE = $("<td>");
                    var $FPRICE = $("<td>");
                    var $COLOR = $("<td>");
                    var $QUANTITY = $("<td>");
                    var $CreatedOn = $("<td>");
                    var $UpdatedOn = $("<td>");
                    var $ORDERID = $("<td>");
                    var $SHIP = $("<td>");
                    var $StatusString = $("<td id='orderStatusLabel" + obj.sold_product_id + "'>");
                    var $STATUS = $("<td>");
                    var $TPRICE = $("<td>");
                    var $GST = $("<td>");
                    var $SPRD_ID = $("<td>");
                    var $WAYBILL = $("<td>");
                    var $PAYSLIP = $("<td>");
                    var $CHECK = $("<td class='check'>");

                    var image = "<img src='" + obj.image + "' width='100' height='100'>"
                    /*
                     var dispProd = "prod";
                     var dispShip = "ship";
                     */
                    var prodDetailsButton = "<button class='viewDetails' onclick='getdetails(" + productId + ")'><span>View</span></button>";
                    /*
                     var shipDetailsButton = "<button onclick='getdetails("+ productId + "," + dispShip +")'>Click to view</button>";
                     */
                    var download = "<button class='downloadBtn' id='" + obj.waybill + "' onclick='getDelhivery(this.id)'>Download</button>";
                    var download1 = "Not generated";

                    var payMethod = 'Online'
                    if (obj.payment_method == 1)
                        payMethod = 'Cash'

                    var shipDetails = "<b>Address:</b> " + obj.address + "<br>" + "<b>Username:</b> " + obj.user_name + "<br>" + "<b>Payment method:</b> " + payMethod;
                    $SNO.append(i + 1);
                    $NAME.append(obj.name);
                    $IMAGE.append(image);
                    $ProdDetails.append("<br>" + prodDetailsButton);
                    $PRICE.append(obj.actual_amount);
                    $FPRICE.append(parseFloat(fprice, 10).toFixed(2));
                    $COLOR.append(obj.color);
                    $QUANTITY.append(obj.quantity);
                    //$SHIP.append("<br>"+shipDetailsButton);
                    $CreatedOn.append(obj.created_on);
                    $UpdatedOn.append(obj.updated_on);
                    $ORDERID.append(obj.order_id);
                    $SHIP.append(shipDetails);
                    $StatusString.append(status);
                    $STATUS.append(st);
                    $TPRICE.append(parseFloat(obj.trans_amt, 10).toFixed(2));
                    $GST.append(parseFloat(obj.gst_amt, 10).toFixed(2));
                    $SPRD_ID.append(obj.sold_product_id);
                    if (obj.waybill === '0')
                    {
                        $PAYSLIP.append(download1);
                    } else {
                        $PAYSLIP.append(download);
                    }
                    $CHECK.append(check);

                    $tr.append($SNO);
                    $tr.append($NAME);
                    $tr.append($IMAGE);
                    $tr.append($ProdDetails);
                    $tr.append($PRICE);
                    $tr.append($FPRICE);
                    $tr.append($COLOR);
                    $tr.append($QUANTITY);
                    $tr.append($CreatedOn);
                    $tr.append($UpdatedOn);
                    $tr.append($ORDERID);
                    $tr.append($SHIP);
                    $tr.append($StatusString);
                    $tr.append($STATUS);
                    $tr.append($TPRICE);
                    $tr.append($GST);
                    $tr.append($SPRD_ID);
                    $tr.append($WAYBILL);
                    $tr.append($PAYSLIP);
                    $tr.append($CHECK);

                    $('#tableBodydate').append($tr);

                    // for(var j = 0; j < data.data.length; j++){
                    //     var obs = data.data[j];
                    //     var tot_transfer = obs.trans_amt;
                    //     console.log("transfer "+tot_transfer);
                    //     trasnferamts.push(parseInt(tot_transfer));
                    //     console.log("Total Transfer " +trasnferamts);
                    //     var tot_trans = parseFloat(trasnferamts);
                    //     document.getElementById('tottrans').innerHTML = " Total transfer amount : " +tot_trans.toFixed(2);
                    // }

                    // trasnferamts.push(parseFloat(obj.trans_amt));
                    // console.log("Transfer " +trasnferamts);
                    // var tot_trans = 0;
                    // for(var l = 1; l < trasnferamts.length; l++){
                    //     tot_trans +=trasnferamts[l];
                    //     console.log("Trans " +tot_trans)
                    //     document.getElementById('tottrans').innerHTML = " Total transfer amount : " +tot_trans.toFixed(2);
                    // }
                }
                //console.log(data)
                pageButtonsdate();
                if (pageNum != 0)
                    var pg = document.getElementsByClassName("pg" + (pageNum + 1))[0];
                else
                    var pg = document.getElementsByClassName("pg" + (pageNum + 1))[0]
                // console.log(pg);
                pg.classList.add("activePage");
                // console.log("a");
                //checkEditAccess();
            })
            .catch(err => {
                // Do something for an error here
                console.log(err);
            })
}